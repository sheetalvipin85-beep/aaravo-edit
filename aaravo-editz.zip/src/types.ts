export interface Video {
  id: string;
  title: string;
  type: 'latest' | 'trending';
  duration: string;
  thumbnail: string;
  views: string;
  likes: string;
  releaseDate: string;
  styleTag: string;
  description: string;
  transitionGuide: string;
  audioTrack: string;
  colorLUT: string;
  youtubeUrl: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  time: string;
  isRead: boolean;
  type: 'upload' | 'template' | 'announcement';
  link: string;
}

export interface EditRecipe {
  title: string;
  audioPlan: {
    track: string;
    sfx: string;
  };
  storyboard: Array<{
    timestamp: string;
    visual: string;
    technique: string;
  }>;
  viralTips: string[];
}

export type ActiveTab = 'home' | 'videos' | 'about' | 'game';
