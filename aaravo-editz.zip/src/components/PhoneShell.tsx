import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wifi, 
  Battery, 
  Signal, 
  Bell, 
  Sparkles, 
  Home, 
  Film, 
  BarChart2, 
  User, 
  ExternalLink,
  ChevronRight,
  Tv,
  Gamepad2
} from 'lucide-react';
import { ActiveTab, NotificationItem } from '../types';

interface PhoneShellProps {
  children: React.ReactNode;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
  toggleNotificationsOpen: () => void;
  logoUrl: string;
}

export default function PhoneShell({
  children,
  activeTab,
  setActiveTab,
  notifications,
  toggleNotificationsOpen,
  logoUrl,
}: PhoneShellProps) {
  const [time, setTime] = useState('');
  
  // Real-time ticking Clock for mobile status bar
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      setTime(`${hours}:${minutes} ${ampm}`);
    };
    
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const tabs: Array<{ id: ActiveTab; label: string; icon: React.ComponentType<any> }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'videos', label: 'Videos', icon: Film },
    { id: 'game', label: 'Arena', icon: Gamepad2 },
    { id: 'about', label: 'About', icon: User },
  ];

  return (
    <div id="app-container" className="min-h-screen flex items-center justify-center bg-[#010102] py-4 px-2 select-none relative overflow-hidden">
      {/* Cinematic Ambient Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-purple/10 rounded-full blur-[130px] pointer-events-none animate-pulse duration-10000" />
      <div className="absolute top-1/4 left-1/3 w-[300px] h-[300px] bg-brand-red/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Desktop Physical Frame & Shadow */}
      <div className="relative w-full max-w-[390px] h-[844px] bg-[#000000] rounded-[50px] p-[10px] shadow-[0_0_50px_rgba(168,85,247,0.25)] border-4 border-zinc-900 flex flex-col md:scale-100 origin-center transition-all">
        {/* Physical Side Buttons (Aesthetics) */}
        <div className="absolute left-[-6px] top-[140px] w-[3px] h-[40px] bg-zinc-700 rounded-l" />
        <div className="absolute left-[-6px] top-[195px] w-[3px] h-[60px] bg-zinc-700 rounded-l" />
        <div className="absolute left-[-6px] top-[265px] w-[3px] h-[60px] bg-zinc-700 rounded-l" />
        <div className="absolute right-[-6px] top-[195px] w-[3px] h-[80px] bg-zinc-700 rounded-r" />

        {/* Screen Bezel (Internal Container) */}
        <div className="relative flex-1 flex flex-col bg-black rounded-[42px] overflow-hidden border border-zinc-950">
          
          {/* Top Status Bar */}
          <div className="h-[44px] flex items-center justify-between px-6 z-40 bg-black select-none text-xs font-medium text-zinc-400">
            {/* Clock */}
            <span id="phone-clock" className="font-mono text-[11px] font-semibold text-zinc-300">{time}</span>
            
            {/* Dynamic Island Notch */}
            <div className="absolute top-[10px] left-1/2 -translate-x-1/2 w-[110px] h-[25px] bg-[#000000] rounded-full flex items-center justify-center border border-white/5">
              <div className="w-[10px] h-[10px] bg-zinc-900 rounded-full ml-auto mr-4 flex items-center justify-center">
                <div className="w-[4px] h-[4px] bg-blue-900 rounded-full" />
              </div>
            </div>

            {/* Signal & Icons */}
            <div className="flex items-center gap-1.5 text-zinc-300">
              <Signal className="w-3.5 h-3.5" />
              <span className="text-[10px] font-mono leading-none text-zinc-400">5G</span>
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4 ml-0.5 text-zinc-400" />
            </div>
          </div>

          {/* Premium Visual Branding Top Navigation bar */}
          <div className="h-[48px] flex items-center justify-between px-4 border-b border-white/5 bg-black/95 backdrop-blur-md z-40">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full overflow-hidden border border-brand-purple/30 flex-shrink-0 bg-zinc-950">
                <img src={logoUrl} alt="Aaravo Editz Official Logo" className="w-full h-full object-cover" />
              </div>
              <span className="font-display text-[14px] font-black italic tracking-tighter text-white uppercase flex items-center">
                AARAVO <span className="text-brand-purple ml-1 font-extrabold glow-text-purple">EDITZ</span>
              </span>
            </div>

            {/* Actions: Notifications bell */}
            <div className="flex items-center gap-2">
              <button 
                id="bell-notification-toggle"
                onClick={toggleNotificationsOpen}
                className="relative p-1.5 rounded-full hover:bg-white/5 active:scale-95 transition-all cursor-pointer text-zinc-300 hover:text-brand-purple"
              >
                <Bell className="w-4.5 h-4.5" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-brand-red rounded-full flex items-center justify-center text-[9px] font-bold text-white border border-black animate-bounce">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Mobile Screen Body Content */}
          <div className="flex-1 overflow-y-auto no-scrollbar bg-black relative flex flex-col">
            {children}
          </div>

          {/* Bottom Persistent Navigation Bar */}
          <div className="h-[68px] border-t border-white/5 bg-[#04020a]/95 backdrop-blur-lg px-2 pb-2 flex items-center justify-around z-40 select-none">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  id={`tab-${tab.id}`}
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="flex flex-col items-center justify-center flex-1 h-full py-1 text-center cursor-pointer transition-all duration-300 relative"
                >
                  <div className={`p-1.5 rounded-full transition-all duration-300 ${
                    isActive 
                      ? 'text-brand-purple scale-110' 
                      : 'text-zinc-500 hover:text-zinc-300'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`text-[9px] tracking-wide transition-all duration-300 font-semibold uppercase ${
                    isActive ? 'text-white font-black italic' : 'text-zinc-500'
                  }`}>
                    {tab.label}
                  </span>
                  
                  {/* Glowing line indicator for active tab */}
                  {isActive && (
                    <motion.div 
                      layoutId="activeTabGlow"
                      className="absolute bottom-0 w-8 h-[2px] bg-brand-purple glow-purple rounded-full shadow-ae-logo"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Virtual Home Bar Indicator (iOS style) */}
          <div className="h-[14px] bg-zinc-950/95 flex items-center justify-center pb-1">
            <div className="w-[110px] h-[4px] bg-zinc-800 rounded-full" />
          </div>

        </div>
      </div>
    </div>
  );
}
