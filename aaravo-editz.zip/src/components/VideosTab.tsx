import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Heart, 
  Youtube, 
  ExternalLink, 
  Flame, 
  Sparkles, 
  RefreshCw,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Facebook,
  Instagram
} from 'lucide-react';
import { Video } from '../types';
import { SAMPLE_VIDEOS } from '../data';

interface VideosTabProps {
  logoUrl?: string;
}

export default function VideosTab({ logoUrl = "https://yt3.googleusercontent.com/vz3yGgm23APspUhDRBYfsEJ2_HhP9kDATIERxLi6SvcLStrVHAKjIgxcVYY_vWvfAgK1W2WkZQ=s900-c-k-c0x00ffffff-no-rj" }: VideosTabProps) {
  const [likedVideoIds, setLikedVideoIds] = useState<Record<string, boolean>>({});
  const [videos, setVideos] = useState<Video[]>(SAMPLE_VIDEOS);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(SAMPLE_VIDEOS[0]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeShareVideo, setActiveShareVideo] = useState<Video | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'latest' | 'shorts'>('all');

  const filteredVideos = videos.filter(v => {
    if (activeFilter === 'all') return true;
    return v.type === activeFilter;
  });

  const copyToClipboard = (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      }
    } catch (err) {
      console.warn("Clipboard copy failed, displaying text for manual copying", err);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const fetchLiveVideos = async () => {
      try {
        const response = await fetch('/api/youtube-videos');
        if (!response.ok) {
          throw new Error('Local API response was not ok');
        }
        const data = await response.json();
        if (data.videos && data.videos.length > 0 && isMounted) {
          setVideos(data.videos);
          setSelectedVideo(data.videos[0]);
        }
      } catch (err) {
        console.warn('Failed to load live uploads from local API, trying rss2json proxy fallback...', err);
        try {
          const rss2jsonUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent('https://www.youtube.com/feeds/videos.xml?channel_id=UCF4m_R68jG6fH4hP7B636tQ')}`;
          const response = await fetch(rss2jsonUrl);
          if (!response.ok) {
            throw new Error('rss2json proxy response was not ok');
          }
          const data = await response.json();
          if (data.status === 'ok' && data.items && data.items.length > 0 && isMounted) {
            const mappedVideos: Video[] = data.items.map((item: any) => {
              const videoId = item.guid.replace('yt:video:', '');
              return {
                id: videoId,
                title: item.title,
                type: 'latest',
                duration: '0:30',
                thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
                views: 'Live view',
                likes: 'Live likes',
                releaseDate: item.pubDate ? new Date(item.pubDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recently',
                styleTag: 'Velocity Ramp',
                description: 'A premium, dynamic edit from the official Aaravo Editz live channel feed. High-intensity audio sync and cinematic grading.',
                transitionGuide: 'Custom velocity flow mapped frame-by-frame with precise screen shakes.',
                audioTrack: 'Original synchronized background audio',
                colorLUT: 'Aaravo Custom Grade',
                youtubeUrl: `https://www.youtube.com/shorts/${videoId}`
              };
            });
            setVideos(mappedVideos);
            setSelectedVideo(mappedVideos[0]);
          }
        } catch (rssErr) {
          console.warn('Failed to load live uploads from rss2json fallback, using local optimized video list:', rssErr);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchLiveVideos();
    return () => {
      isMounted = false;
    };
  }, []);

  const toggleVideoLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent selecting the video
    setLikedVideoIds(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleVideoCardClick = (video: Video) => {
    setSelectedVideo(video);
    setIsPlaying(true);
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-black space-y-4">
        <motion.div 
          animate={{ scale: [0.95, 1.05, 0.95] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          className="w-16 h-16 rounded-full overflow-hidden border-2 border-brand-purple/30 shadow-[0_0_20px_rgba(168,85,247,0.35)] bg-zinc-950 flex-shrink-0"
        >
          <img src={logoUrl} alt="Aaravo Editz Logo" className="w-full h-full object-cover" />
        </motion.div>
        <div className="flex items-center gap-2 text-[10px] font-display font-black tracking-widest text-zinc-400 uppercase italic">
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-brand-purple" /> FETCHING LIVE CREATIONS...
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="flex-1 flex flex-col p-4 space-y-5 pb-24 overflow-y-auto no-scrollbar"
    >
      {/* Promotion Callout */}
      <div className="bg-red-950/20 border border-red-500/20 rounded-2xl p-4 space-y-2 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-20 h-20 bg-red-600/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Complete YouTube Logo Badge */}
            <div className="flex items-center justify-center bg-white rounded p-1 shadow-md">
              <div className="w-5 h-3 bg-red-600 rounded flex items-center justify-center">
                <div className="w-0 h-0 border-t-[2.5px] border-t-transparent border-b-[2.5px] border-b-transparent border-l-[4px] border-l-white ml-0.5" />
              </div>
            </div>
            <h3 className="text-xs font-display font-black tracking-widest text-white uppercase italic">
              Aaravo YouTube Channel
            </h3>
          </div>
          {isLoading && (
            <span className="flex items-center gap-1.5 text-[9px] font-bold text-red-500 uppercase tracking-wider animate-pulse">
              <RefreshCw className="w-3 h-3 animate-spin" /> LIVE
            </span>
          )}
        </div>
        <p className="text-[11px] text-zinc-300 leading-normal font-sans">
          These are official high-fidelity anime creations. Help me grow by smashing the Like and Subscribe buttons!
        </p>
      </div>

      {/* Featured/Selected Video Player mockup */}
      {selectedVideo && (
        <div 
          onClick={() => {
            if (!isPlaying) {
              setIsPlaying(true);
            }
          }}
          className="bg-[#0b0b0b] border border-white/5 rounded-2xl overflow-hidden shadow-2xl space-y-3 pb-3 cursor-pointer group hover:border-red-500/20 transition-all"
        >
          {/* Fake screen aspect ratio container */}
          <div className="relative aspect-video w-full bg-black border-b border-white/5 overflow-hidden">
            {isPlaying ? (
              <iframe
                src={`https://www.youtube.com/embed/${selectedVideo.id}?autoplay=1&rel=0`}
                title={selectedVideo.title}
                className="w-full h-full absolute inset-0 z-20 border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <>
                <img 
                  src={selectedVideo.thumbnail} 
                  alt={selectedVideo.title}
                  className="w-full h-full object-cover opacity-85 group-hover:scale-102 transition-all duration-700"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.includes('maxresdefault.jpg')) {
                      target.src = target.src.replace('maxresdefault.jpg', 'hqdefault.jpg');
                    } else if (target.src.includes('hqdefault.jpg')) {
                      target.src = target.src.replace('hqdefault.jpg', '0.jpg');
                    }
                  }}
                />
                {/* Absolute Play Backdrop */}
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center transition-colors group-hover:bg-black/10">
                  <div className="w-14 h-14 bg-red-600 group-hover:bg-red-700 text-white rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.6)] hover:scale-110 active:scale-95 transition-all">
                    <Play className="w-6 h-6 fill-white ml-1 text-white" />
                  </div>
                </div>
              </>
            )}

            {/* Duration and style badge */}
            {!isPlaying && (
              <span className="absolute bottom-2 right-2 bg-black/85 text-white font-mono text-[10px] font-bold py-0.5 px-2 rounded-md border border-white/10">
                {selectedVideo.duration}
              </span>
            )}

            <span className="absolute top-2 left-2 bg-red-600 text-white font-sans text-[9px] font-black tracking-wider uppercase py-0.5 px-2 rounded-md shadow-md z-30">
              {selectedVideo.styleTag}
            </span>
          </div>

          {/* Details below video preview */}
          <div className="px-3.5 space-y-2" onClick={(e) => e.stopPropagation()}>
            <div className="space-y-1">
              <h3 
                onClick={() => window.open(selectedVideo.youtubeUrl, '_blank')}
                className="text-xs font-black text-white leading-snug uppercase tracking-tight italic hover:text-red-500 cursor-pointer transition-colors"
              >
                {selectedVideo.title}
              </h3>
              <p className="text-[11px] text-zinc-400 font-sans leading-normal">
                {selectedVideo.description}
              </p>
            </div>

            {/* Video Specific Promos: Big Subscribe, Like & Share row */}
            <div className="flex gap-2 pt-1">
              {/* Watch and Subscribe CTA with complete YouTube Logo */}
              <a 
                href={selectedVideo.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  fetch('/api/subscribe-click', { method: 'POST' }).catch(() => {});
                }}
                className="flex-1 flex items-center justify-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-display font-black text-[10.5px] tracking-wider py-2.5 px-3 rounded-lg border border-red-500/20 hover:scale-[1.02] active:scale-95 transition-all text-center uppercase"
              >
                <div className="flex items-center justify-center bg-white rounded px-1 flex-shrink-0">
                  <div className="w-4 h-2.5 bg-red-600 rounded flex items-center justify-center">
                    <div className="w-0 h-0 border-t-[2px] border-t-transparent border-b-[2px] border-b-transparent border-l-[3.5px] border-l-white ml-[0.2px]" />
                  </div>
                </div>
                <span>SUB</span>
              </a>

              {/* Attractive Like toggle button */}
              <button 
                onClick={(e) => toggleVideoLike(selectedVideo.id, e)}
                className={`flex-1 py-2.5 rounded-lg border flex items-center justify-center gap-1 font-display font-bold text-[10.5px] tracking-wider transition-all cursor-pointer ${
                  likedVideoIds[selectedVideo.id]
                    ? 'bg-pink-600 border-pink-400 text-white shadow-[0_0_15px_rgba(219,39,119,0.4)]'
                    : 'bg-zinc-900 border-white/5 text-zinc-300 hover:border-pink-500/25'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${likedVideoIds[selectedVideo.id] ? 'fill-white text-white' : 'text-pink-500'}`} />
                <span>{likedVideoIds[selectedVideo.id] ? "LIKED" : "LIKE"}</span>
              </button>

              {/* Attractive Share button */}
              <button 
                onClick={() => setActiveShareVideo(selectedVideo)}
                className="px-3 py-2.5 rounded-lg border bg-zinc-900 border-white/5 text-zinc-300 hover:text-white hover:border-brand-purple/30 transition-all cursor-pointer flex items-center justify-center gap-1 flex-1 font-display font-bold text-[10.5px] tracking-wider"
              >
                <Share2 className="w-3.5 h-3.5 text-brand-purple" />
                <span>SHARE</span>
              </button>
            </div>

            {/* Guide stats and technical edits attributes */}
            <div className="bg-[#111111] rounded-xl p-2.5 border border-white/5 space-y-1.5 text-[10px]">
              <div className="flex justify-between border-b border-white/5 pb-1">
                <span className="text-zinc-500">Color LUT Curve:</span>
                <span className="text-red-400 font-mono font-medium">{selectedVideo.colorLUT}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-1">
                <span className="text-zinc-500">Audio Sync:</span>
                <span className="text-zinc-300 font-sans font-medium">{selectedVideo.audioTrack}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Editing Technique:</span>
                <span className="text-zinc-300 font-sans font-medium">{selectedVideo.transitionGuide}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Segmented Filter Control */}
      <div className="flex gap-1.5 p-1 bg-zinc-950 border border-white/5 rounded-xl">
        {(['all', 'latest', 'shorts'] as const).map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`flex-1 py-2 text-[10px] font-display font-black tracking-widest uppercase rounded-lg transition-all cursor-pointer ${
              activeFilter === filter
                ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.35)] font-black'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {filter === 'all' ? 'All Feed' : filter === 'latest' ? 'Videos' : 'Shorts'}
          </button>
        ))}
      </div>

      {/* Grid List of all other official channel videos */}
      <div className="space-y-3">
        <h3 className="text-[10px] font-display font-black tracking-widest uppercase text-gray-500 px-1">
          CHANNELS UPLOADS FEED ({filteredVideos.length})
        </h3>

        <div className="space-y-2.5">
          {filteredVideos.map((video) => {
            const isLiked = !!likedVideoIds[video.id];
            const isSelected = selectedVideo?.id === video.id;

            return (
              <div
                id={`video-card-${video.id}`}
                key={video.id}
                onClick={() => handleVideoCardClick(video)}
                className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex gap-3 group relative ${
                  isSelected 
                    ? 'bg-white/5 border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.05)]' 
                    : 'bg-[#0b0b0b] border-white/5 hover:border-white/10'
                }`}
              >
                {/* Left image container */}
                <div className="w-24 h-16 rounded-xl overflow-hidden relative bg-zinc-950 border border-white/5 flex-shrink-0">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (target.src.includes('maxresdefault.jpg')) {
                        target.src = target.src.replace('maxresdefault.jpg', 'hqdefault.jpg');
                      } else if (target.src.includes('hqdefault.jpg')) {
                        target.src = target.src.replace('hqdefault.jpg', '0.jpg');
                      }
                    }}
                  />
                  {/* Miniature Play circle */}
                  <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
                    <div className="w-7 h-7 bg-red-600 rounded-full flex items-center justify-center shadow-md">
                      <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                  {/* Duration pill */}
                  <span className="absolute bottom-1 right-1 bg-black/85 text-white font-mono text-[8px] font-black px-1 rounded-sm leading-none">
                    {video.duration}
                  </span>
                </div>

                {/* Right metadata description */}
                <div className="flex-1 flex flex-col justify-center space-y-1.5 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] bg-red-950 text-red-400 font-bold px-1.5 py-0.5 rounded-md leading-none uppercase">
                      {video.styleTag}
                    </span>
                    <span className="text-[8px] text-zinc-500 font-mono">{video.releaseDate}</span>
                  </div>
                  <h4 className="text-[11px] font-black text-white leading-tight uppercase tracking-tight line-clamp-1 group-hover:text-red-500 transition-colors">
                    {video.title}
                  </h4>
                  
                  {/* Compact Actions row inside card */}
                  <div className="flex items-center gap-1.5 pt-1" onClick={(e) => e.stopPropagation()}>
                    {/* Like button */}
                    <button
                      onClick={(e) => toggleVideoLike(video.id, e)}
                      className={`flex items-center gap-1 px-2 py-1 rounded border text-[9px] font-bold tracking-tight transition-all cursor-pointer ${
                        isLiked 
                          ? 'bg-pink-600/20 border-pink-500/40 text-pink-400' 
                          : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-pink-500/20'
                      }`}
                    >
                      <Heart className={`w-3 h-3 ${isLiked ? 'fill-pink-500 text-pink-400' : ''}`} />
                      <span>{isLiked ? 'LIKED' : 'LIKE'}</span>
                    </button>

                    {/* Subscribe button */}
                    <a
                      href="https://www.youtube.com/@sheetalsharma9569?sub_confirmation=1"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        fetch('/api/subscribe-click', { method: 'POST' }).catch(() => {});
                      }}
                      className="flex items-center gap-1 px-2 py-1 bg-red-600/10 border border-red-600/25 hover:bg-red-600/20 text-red-400 rounded text-[9px] font-bold tracking-tight transition-all uppercase"
                    >
                      <Youtube className="w-3 h-3 text-red-500" />
                      <span>SUB</span>
                    </a>

                    {/* Share button */}
                    <button
                      onClick={() => setActiveShareVideo(video)}
                      className="flex items-center gap-1 px-2 py-1 bg-zinc-950 border border-white/5 text-zinc-400 hover:text-white hover:border-brand-purple/35 rounded text-[9px] font-bold tracking-tight transition-all uppercase cursor-pointer"
                    >
                      <Share2 className="w-3 h-3 text-brand-purple" />
                      <span>SHARE</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Premium Share Modal Overlay */}
      <AnimatePresence>
        {activeShareVideo && (
          <>
            {/* Modal Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveShareVideo(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center px-4 rounded-[42px] cursor-pointer"
            >
              {/* Modal Card */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0, y: 15 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 15 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-[#0c071a] border border-brand-purple/25 rounded-2xl p-5 w-full max-w-xs space-y-4 shadow-[0_0_35px_rgba(168,85,247,0.3)] relative cursor-default"
              >
                {/* Header */}
                <div className="text-center space-y-1">
                  <span className="text-[9px] bg-brand-purple/20 text-brand-purple-light font-display font-black px-2.5 py-0.5 rounded-full uppercase tracking-widest leading-none">
                    SHARE VIDEO
                  </span>
                  <h4 className="font-display font-black text-xs text-white uppercase tracking-tight italic line-clamp-1 mt-1">
                    {activeShareVideo.title}
                  </h4>
                  <p className="text-[9px] text-zinc-500 font-sans">
                    Pick your preferred social platform below
                  </p>
                </div>

                {/* Social Buttons Grid */}
                <div className="grid grid-cols-2 gap-2">
                  {/* WhatsApp */}
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent("Check out this sick anime edit by Aaravo Editz! 🔥 " + activeShareVideo.youtubeUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-[#091e13] border border-emerald-500/15 hover:border-emerald-500/40 text-emerald-400 hover:text-emerald-300 transition-all cursor-pointer group"
                  >
                    <MessageCircle className="w-5 h-5 text-emerald-500 group-hover:scale-110 transition-transform" />
                    <span className="text-[9px] font-sans font-bold uppercase tracking-wider">WhatsApp</span>
                  </a>

                  {/* Facebook */}
                  <a
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(activeShareVideo.youtubeUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-[#081224] border border-blue-500/15 hover:border-blue-500/40 text-blue-400 hover:text-blue-300 transition-all cursor-pointer group"
                  >
                    <Facebook className="w-5 h-5 text-blue-500 group-hover:scale-110 transition-transform" />
                    <span className="text-[9px] font-sans font-bold uppercase tracking-wider">Facebook</span>
                  </a>

                  {/* Instagram */}
                  <button
                    onClick={() => {
                      copyToClipboard(activeShareVideo.youtubeUrl);
                    }}
                    className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-[#1c0817] border border-pink-500/15 hover:border-pink-500/40 text-pink-400 hover:text-pink-300 transition-all cursor-pointer group text-center"
                  >
                    <Instagram className="w-5 h-5 text-pink-500 group-hover:scale-110 transition-transform" />
                    <span className="text-[9px] font-sans font-bold uppercase tracking-wider">Instagram</span>
                  </button>

                  {/* Copy Link */}
                  <button
                    onClick={() => copyToClipboard(activeShareVideo.youtubeUrl)}
                    className={`flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border transition-all cursor-pointer group text-center ${
                      isCopied 
                        ? 'bg-[#101c0c] border-emerald-500/40 text-emerald-400'
                        : 'bg-[#0f0a1c] border-brand-purple/15 hover:border-brand-purple/40 text-brand-purple-light hover:text-white'
                    }`}
                  >
                    {isCopied ? (
                      <Check className="w-5 h-5 text-emerald-500 animate-bounce" />
                    ) : (
                      <Copy className="w-5 h-5 text-brand-purple group-hover:scale-110 transition-transform" />
                    )}
                    <span className="text-[9px] font-sans font-bold uppercase tracking-wider">
                      {isCopied ? "Copied!" : "Copy Link"}
                    </span>
                  </button>
                </div>

                {/* Inline feedback if Copied */}
                {isCopied && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-emerald-950/40 border border-emerald-500/20 rounded-xl p-2.5 text-center"
                  >
                    <p className="text-[10px] text-emerald-400 font-bold uppercase leading-none flex items-center justify-center gap-1">
                      <Check className="w-3.5 h-3.5" /> LINK COPIED SUCCESSFULLY!
                    </p>
                  </motion.div>
                )}

                {/* Footer and Close */}
                <div className="flex flex-col gap-2 pt-1 border-t border-white/5">
                  <button
                    onClick={() => setActiveShareVideo(null)}
                    className="w-full py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white font-display font-bold text-[9px] rounded-lg uppercase tracking-wider transition-colors cursor-pointer text-center"
                  >
                    Dismiss Share
                  </button>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </motion.div>
  );
}
