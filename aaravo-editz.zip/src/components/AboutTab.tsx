import React from 'react';
import { motion } from 'motion/react';
import { 
  Info, 
  Tv, 
  Youtube, 
  Award, 
  ShieldCheck,
  Flame,
  Heart,
  Target
} from 'lucide-react';

export default function AboutTab() {
  const socials = [
    { name: 'YouTube Channel', handle: '@sheetalsharma9569', icon: Youtube, color: 'hover:text-brand-purple hover:border-brand-purple/50', link: 'https://www.youtube.com/@sheetalsharma9569' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="flex-1 flex flex-col p-4 space-y-4 pb-24 overflow-y-auto no-scrollbar bg-black"
    >
      {/* Intro section */}
      <div className="space-y-1">
        <span className="inline-flex items-center gap-1.5 bg-brand-purple/10 text-brand-purple-light text-[9px] font-bold px-2.5 py-1 rounded-full tracking-wider uppercase border border-brand-purple/20">
          <Info className="w-3.5 h-3.5" /> SOLO CREATOR PROFILE
        </span>
        <h2 className="font-display text-xl font-bold text-white uppercase tracking-tight italic">
          About Aaravo <span className="text-brand-purple glow-text-purple">Editz</span>
        </h2>
      </div>

      {/* Brand narrative card */}
      <div className="bg-[#0c071a]/60 border border-brand-purple/20 rounded-2xl p-4 space-y-3.5 shadow-md relative">
        <div className="absolute top-0 right-0 w-16 h-16 bg-brand-red/5 rounded-full blur-2xl pointer-events-none" />
        <div className="w-10 h-10 bg-brand-purple/10 rounded-lg flex items-center justify-center border border-brand-purple/30 shadow-ae-logo">
          <Tv className="w-5 h-5 text-brand-purple" />
        </div>
        
        <p className="text-[12px] text-zinc-200 leading-relaxed font-sans">
          Welcome to <strong className="text-white font-black italic uppercase">Aaravo Editz</strong> — a dedicated solo platform showcasing next-level cinematic anime edits and high-energy video creations.
        </p>

        <p className="text-[11.5px] text-zinc-400 leading-relaxed font-sans">
          This channel is built on a passion for anime storytelling. Every edit is carefully timed frame-by-frame, combining intense synchronization, deep basslines, and meticulous color grading to create highly attractive and immersive video content.
        </p>

        {/* Highlight milestones badges */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div className="flex items-center gap-2 bg-white/[0.02] p-2 rounded-xl border border-white/5">
            <Flame className="w-4 h-4 text-brand-red flex-shrink-0 animate-pulse" />
            <span className="text-[10px] text-zinc-300 font-medium font-sans">Solo Passion Project</span>
          </div>
          <div className="flex items-center gap-2 bg-white/[0.02] p-2 rounded-xl border border-white/5">
            <Award className="w-4 h-4 text-brand-purple flex-shrink-0" />
            <span className="text-[10px] text-zinc-300 font-medium font-sans">High-Fidelity Audio Sync</span>
          </div>
        </div>
      </div>

      {/* My Goal Section */}
      <div className="bg-[#12080a] border-2 border-brand-red p-5.5 space-y-4 rounded-2xl relative shadow-[0_0_25px_rgba(239,68,68,0.35)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-red/20 border border-brand-red flex items-center justify-center shadow-[0_0_15px_rgba(239,68,68,0.4)]">
            <Target className="w-6 h-6 text-brand-red animate-pulse" />
          </div>
          <h3 className="font-display text-sm font-black text-white uppercase tracking-widest italic">
            My <span className="text-brand-red">Goal</span>
          </h3>
        </div>
        <div className="pt-2">
          <p className="text-[14px] md:text-[15px] text-zinc-100 font-sans font-bold leading-relaxed tracking-wide select-text">
            My goal is to reach <span className="text-brand-purple font-black">100K subscribers</span>, reveal my face to my audience, achieve the <span className="text-yellow-400 font-black">Silver Play Button</span>, and build a strong <span className="text-brand-red font-black">Aaravo Editz community</span>.
          </p>
        </div>
      </div>

      {/* Community Links cards */}
      <div className="space-y-2">
        <h3 className="text-xs font-display font-bold uppercase tracking-wider text-zinc-500 px-1">
          Official Visual Channels
        </h3>

        <div className="grid grid-cols-2 gap-2">
          {socials.map((soc) => {
            const Icon = soc.icon;
            return (
              <a
                id={`social-link-${soc.name.toLowerCase().replace(/\s+/g, '-')}`}
                key={soc.name}
                href={soc.link}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  fetch('/api/subscribe-click', { method: 'POST' }).catch(() => {});
                }}
                className={`bg-[#07040f] border border-brand-purple/10 p-3 rounded-xl flex flex-col gap-1.5 transition-all cursor-pointer hover:border-brand-purple/40 hover:shadow-ae-logo ${soc.color}`}
              >
                <div className="flex items-center justify-between">
                  <Icon className="w-5 h-5 text-brand-red animate-pulse" />
                </div>
                <div className="space-y-0.5 mt-1">
                  <span className="text-[10.5px] font-bold text-white block">{soc.name}</span>
                  <span className="text-[8.5px] text-zinc-400 font-mono block leading-none">{soc.handle}</span>
                </div>
              </a>
            );
          })}
        </div>
      </div>

      {/* Artistic Integrity Commitment */}
      <div className="bg-[#0c071a]/40 border border-brand-purple/10 p-4 rounded-2xl flex gap-3 items-start">
        <Heart className="w-5 h-5 text-brand-red flex-shrink-0 mt-0.5 animate-pulse" />
        <div className="space-y-1">
          <h4 className="text-[11px] font-display font-bold text-white uppercase tracking-wider">
            100% Original Edits
          </h4>
          <p className="text-[10px] text-zinc-400 leading-relaxed font-sans">
            Every piece of video content is uniquely produced, graded, and edited by me. Supporting Aaravo Editz means supporting independent creator effort and cinematic anime craftsmanship.
          </p>
        </div>
      </div>

    </motion.div>
  );
}

