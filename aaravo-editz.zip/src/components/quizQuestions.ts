export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIdx: number;
  explanation: string;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Which supreme spatial technique is Gojo's signature combination?",
    options: ["Malevolent Shrine", "Hollow Purple", "Amaterasu Black Flame", "Constant Flux Dragon"],
    correctIdx: 1,
    explanation: "Hollow Purple combines Red (repulsion) and Blue (attraction) to synthesize imaginary matter that erases everything in its path."
  },
  {
    id: 2,
    question: "What is the true divine name of Luffy's incredible Gear 5 form?",
    options: ["Straw Hat Monarch", "Demon Asura King", "Sun God Nika", "Rubber Overlord"],
    correctIdx: 2,
    explanation: "Luffy's Gear 5 is the awakening of the Mythical Zoan-type Human-Human Fruit, Model: Nika, named after the Sun God."
  },
  {
    id: 3,
    question: "Which sword-style user is legendary for using Three Swords (Santoryu) simultaneously?",
    options: ["Tanjiro Kamado", "Roronoa Zoro", "Sakata Gintoki", "Ichigo Kurosaki"],
    correctIdx: 1,
    explanation: "Roronoa Zoro from One Piece fights with three swords, holding the third one in his mouth."
  },
  {
    id: 4,
    question: "In Jujutsu Kaisen, what unique spark effect multiplies an attack's power by the exponent of 2.5?",
    options: ["Divergent Fist", "Curse Surge", "Black Flash", "Malevolent Strike"],
    correctIdx: 2,
    explanation: "Black Flash is a spatial distortion that occurs when cursed energy is applied within 0.000001 seconds of a physical hit, multiplying the impact to the power of 2.5."
  },
  {
    id: 5,
    question: "Which legendary lightning technique did Kakashi teach Sasuke in Naruto?",
    options: ["Chidori Blade", "Kirin", "Rasenshuriken", "Malevolent Shrine"],
    correctIdx: 0,
    explanation: "Chidori is Kakashi's original lightning-element jutsu, which he passed on to his pupil Sasuke."
  },
  {
    id: 6,
    question: "In Jujutsu Kaisen, Yuji became the vessel of which multi-eyed ancient curse demon?",
    options: ["Kurama Fox", "Akaza Demon", "Ryomen Sukuna", "Muzan Kibutsuji"],
    correctIdx: 2,
    explanation: "Yuji accidentally becomes the vessel of Sukuna, the infamous double-faced King of Curses."
  },
  {
    id: 7,
    question: "Which ninja became the 7th Hokage of the Hidden Leaf Village?",
    options: ["Sasuke Uchiha", "Kakashi Hatake", "Minato Namikaze", "Naruto Uzumaki"],
    correctIdx: 3,
    explanation: "Naruto Uzumaki finally realized his lifelong dream of leading his squad by becoming the Seventh Hokage."
  },
  {
    id: 8,
    question: "Who is the primary protagonist of the dark fantasy series Death Note?",
    options: ["L Lawliet", "Light Yagami", "Ryuk", "Misa Amane"],
    correctIdx: 1,
    explanation: "Light Yagami is the brilliant high school student who finds the death note and uses the alias 'Kira' to purify the world."
  },
  {
    id: 9,
    question: "What is the name of Goku's signature blue-colored visual energy beam?",
    options: ["Spirit Bomb", "Destructo Disc", "Special Beam Cannon", "Kamehameha"],
    correctIdx: 3,
    explanation: "The Kamehameha is Goku's most famous and signature energy wave attack, invented by Master Roshi."
  },
  {
    id: 10,
    question: "What is Ichigo Kurosaki's primary Zanpakuto sword name in Bleach?",
    options: ["Zangetsu", "Senbonzakura", "Hyorinmaru", "Wabisuke"],
    correctIdx: 0,
    explanation: "Ichigo's Zanpakuto (Soul-Cutter Sword) is named Zangetsu, meaning 'Slaying Moon'."
  },
  {
    id: 11,
    question: "Which anime is set in a virtual reality gaming world where players are trapped and death is permanent?",
    options: ["No Game No Life", "Overlord", "Sword Art Online", "Log Horizon"],
    correctIdx: 2,
    explanation: "Sword Art Online (SAO) is the seminal isekai anime where dying inside the virtual world kills the player in real life."
  },
  {
    id: 12,
    question: "What is the main ingredient of Tanjiro's breathing style in Demon Slayer?",
    options: ["Thunder", "Flame", "Water", "Wind"],
    correctIdx: 2,
    explanation: "Tanjiro starts his journey as a slayer by learning Water Breathing under Sakonji Urokodaki."
  },
  {
    id: 13,
    question: "Which titan is possessed by Eren Yeager at the start of Attack on Titan?",
    options: ["Armored Titan", "Attack Titan", "Colossal Titan", "Beast Titan"],
    correctIdx: 1,
    explanation: "Eren possesses the legendary Attack Titan (Shingeki no Kyojin), seeking freedom for humanity."
  },
  {
    id: 14,
    question: "What is the name of the futuristic bounty-hunting spaceship in Cowboy Bebop?",
    options: ["Milano", "Bebop", "Serenity", "Swordfish II"],
    correctIdx: 1,
    explanation: "The main vessel used by Spike, Jet, Faye, Ed, and Ein is called the Bebop."
  },
  {
    id: 15,
    question: "Who is the 'Fullmetal Alchemist' in the popular series of the same name?",
    options: ["Alphonse Elric", "Edward Elric", "Roy Mustang", "Van Hohenheim"],
    correctIdx: 1,
    explanation: "Edward Elric is the Fullmetal Alchemist, so-called due to his metal automail prosthetic arm and leg."
  },
  {
    id: 16,
    question: "What is the ultimate defense barrier technique of Gaara of the Desert in Naruto?",
    options: ["Sand Shield", "Iron Sand Wall", "Shield of Shukaku", "Sphere of Sand"],
    correctIdx: 0,
    explanation: "Gaara possesses the automatic Shield of Sand, fueled by his mother's love, protecting him from all physical harm."
  },
  {
    id: 17,
    question: "Which magical sport is played on broomsticks in the wizarding-themed anime Little Witch Academia?",
    options: ["Quidditch", "Broom Racing", "Witch Cup", "Broomball"],
    correctIdx: 1,
    explanation: "LWA features Broom Racing as the premiere high-altitude magic competition."
  },
  {
    id: 18,
    question: "Which Hunter x Hunter character aims to avenge his clan, the Kurta Clan, which was wiped out by the Phantom Troupe?",
    options: ["Gon Freecss", "Killua Zoldyck", "Kurapika", "Leorio Paradinight"],
    correctIdx: 2,
    explanation: "Kurapika seeks to retrieve his clan's scarlet eyes and eliminate the Phantom Troupe."
  },
  {
    id: 19,
    question: "What is Saitama's rank in the Hero Association initially?",
    options: ["S-Class", "A-Class", "B-Class", "C-Class"],
    correctIdx: 3,
    explanation: "Despite his unmatched god-like physical prowess, Saitama initially gets placed in C-Class because of a poor written exam."
  },
  {
    id: 20,
    question: "Who is the legendary wizard king of Fiore in the guild-based anime Fairy Tail?",
    options: ["Makarov Dreyar", "Natsu Dragneel", "Gildarts Clive", "Zeref Dragneel"],
    correctIdx: 0,
    explanation: "Makarov Dreyar is the 3rd, 6th, and 8th Guild Master of Fairy Tail and one of the Ten Wizard Saints."
  },
  {
    id: 21,
    question: "In Demon Slayer, what is the color of Tanjiro's rare Nichirin Blade?",
    options: ["Crimson Red", "Deep Black", "Bright Yellow", "Sky Blue"],
    correctIdx: 1,
    explanation: "Tanjiro wields a rare jet-black Nichirin blade, which has historical ties to the legendary Sun Breathing."
  },
  {
    id: 22,
    question: "Which Survey Corps commander famous for his 'Shinzou wo Sasageyo!' battle cry led the charge against the Beast Titan?",
    options: ["Erwin Smith", "Levi Ackerman", "Hange Zoë", "Dot Pixis"],
    correctIdx: 0,
    explanation: "Commander Erwin Smith orchestrated the legendary suicide charge against the Beast Titan in Shiganshina."
  },
  {
    id: 23,
    question: "What is the name of Goku's home planet which was completely vaporized by Frieza?",
    options: ["Namek", "Planet Vegeta", "Earth", "Planet Sadala"],
    correctIdx: 1,
    explanation: "Goku was born on Planet Vegeta, which was destroyed by Lord Frieza to extinguish the legendary Saiyan race."
  },
  {
    id: 24,
    question: "In Jujutsu Kaisen, how many fingers of Sukuna must Yuji swallow to completely restore Sukuna's power?",
    options: ["10", "12", "20", "5"],
    correctIdx: 2,
    explanation: "Sukuna possessed 20 fingers across his 4 arms, which were preserved as indestructible cursed tools."
  },
  {
    id: 25,
    question: "Which of the following is NOT one of Zoro's swords in One Piece?",
    options: ["Wado Ichimonji", "Sandai Kitetsu", "Samehada", "Shusui"],
    correctIdx: 2,
    explanation: "Samehada (Shark Skin) is the living chakra-devouring greatsword used by Kisame Hoshigaki in Naruto."
  },
  {
    id: 26,
    question: "What is the name of the shadow-controlling technique used by Shikamaru Nara in Naruto?",
    options: ["Shadow Imitation Jutsu", "Shadow Choke Jutsu", "Shadow Stitching Jutsu", "Shadow Lock Jutsu"],
    correctIdx: 0,
    explanation: "Shikamaru uses the Nara Clan's Shadow Imitation Jutsu (Kagemane no Jutsu) to force others to copy his movements."
  },
  {
    id: 27,
    question: "Which family of elite assassins does Killua belong to in Hunter x Hunter?",
    options: ["Kurile Family", "Zoldyck Family", "Lucilfer Family", "Freecss Family"],
    correctIdx: 1,
    explanation: "Killua is the heir to the infamous Zoldyck Family of legendary assassins residing on Kukuroo Mountain."
  },
  {
    id: 28,
    question: "What is the name of the magical, wish-granting artifact in Fate/Zero?",
    options: ["Holy Grail", "Philosopher's Stone", "Death Ring", "Golden Chalice"],
    correctIdx: 0,
    explanation: "The Holy Grail War is fought among seven mages and their summoned heroic servants to claim the Holy Grail."
  },
  {
    id: 29,
    question: "Which demon is the absolute progenitor of all demons in Demon Slayer?",
    options: ["Akaza", "Kokushibo", "Muzan Kibutsuji", "Muzan Kamado"],
    correctIdx: 2,
    explanation: "Muzan Kibutsuji is the first of his kind and the supreme leader who can turn humans into demons using his blood."
  },
  {
    id: 30,
    question: "In Bleach, what is the final, fully-awakened release form of a Zanpakuto called?",
    options: ["Shikai", "Bankai", "Resurreccion", "Vollstandig"],
    correctIdx: 1,
    explanation: "Bankai (Final Release) is the second and ultimate form of a Soul Reaper's weapon, granting incredible powers."
  },
  {
    id: 31,
    question: "What is the main power system called in Hunter x Hunter?",
    options: ["Chakra", "Nen", "Haki", "Ki"],
    correctIdx: 1,
    explanation: "Nen is the technique of manipulating one's life energy (aura), divided into six categories like Enhancer or Transmuter."
  },
  {
    id: 32,
    question: "What is the name of Luffy's crew in One Piece?",
    options: ["Red Hair Pirates", "Straw Hat Pirates", "Whitebeard Pirates", "Heart Pirates"],
    correctIdx: 1,
    explanation: "Luffy leads the Straw Hat Pirates, named after the iconic straw hat gifted to him by Shanks."
  },
  {
    id: 33,
    question: "Which anime features giant humanoid mechas called EVAs battling alien monsters known as Angels?",
    options: ["Code Geass", "Gurren Lagann", "Neon Genesis Evangelion", "Gundam Wing"],
    correctIdx: 2,
    explanation: "Neon Genesis Evangelion features Shinji Ikari piloting Evangelion Unit-01 against cataclysmic Angels."
  },
  {
    id: 34,
    question: "What is the true name of the hero who became the One For All successor in My Hero Academia?",
    options: ["Katsuki Bakugo", "Izuku Midoriya", "Shoto Todoroki", "All Might"],
    correctIdx: 1,
    explanation: "Izuku Midoriya (Deku) is the quirkless kid chosen by All Might to inherit the legendary One For All quirk."
  },
  {
    id: 35,
    question: "Who is known as the 'Elric Brothers' guardian' and 'Flame Alchemist' in Fullmetal Alchemist?",
    options: ["Alex Louis Armstrong", "Roy Mustang", "Maes Hughes", "Scar"],
    correctIdx: 1,
    explanation: "Roy Mustang is the Flame Alchemist who aims to become the Führer of Amestris."
  },
  {
    id: 36,
    question: "Which powerful military force is tasked with protecting the walls in Attack on Titan?",
    options: ["Garrison Regiment", "Survey Corps", "Military Police", "Training Corps"],
    correctIdx: 0,
    explanation: "The Garrison Regiment is the largest division of the military that handles wall maintenance and defense."
  },
  {
    id: 37,
    question: "What is the name of Goku's ultimate form achieved during the Tournament of Power?",
    options: ["Super Saiyan Blue", "Ultra Instinct", "Super Saiyan God", "Beast Mode"],
    correctIdx: 1,
    explanation: "Goku masters 'Autonomous Ultra Instinct', a divine state where his body reacts completely automatically without thought."
  },
  {
    id: 38,
    question: "Which magic guild does Lucy Heartfilia run away to join in Fairy Tail?",
    options: ["Blue Pegasus", "Sabertooth", "Fairy Tail", "Lamia Scale"],
    correctIdx: 2,
    explanation: "Lucy Heartfilia is a Celestial Mage who flees her wealthy family to join the legendary Fairy Tail guild."
  },
  {
    id: 39,
    question: "Who is Light Yagami's primary Shinigami companion who dropped the Death Note?",
    options: ["Ryuk", "Rem", "Gelus", "Sidoh"],
    correctIdx: 0,
    explanation: "Ryuk is the apple-loving Shinigami who intentionally dropped his Death Note into the human world out of boredom."
  },
  {
    id: 40,
    question: "In Jujutsu Kaisen, what is the name of Megumi Fushiguro's most powerful, uncontained shikigami?",
    options: ["Nue", "Divine Dog Totality", "Eight-Handled Sword Divergent Sila Divine General Mahoraga", "Max Elephant"],
    correctIdx: 2,
    explanation: "Mahoraga is the ultimate shikigami of the Ten Shadows Technique, famous for adapting to any and all phenomena."
  },
  {
    id: 41,
    question: "What is the name of the special eye technique possessed by the Uchiha Clan in Naruto?",
    options: ["Byakugan", "Rinnegan", "Sharingan", "Tenseigan"],
    correctIdx: 2,
    explanation: "The Sharingan is the Uchiha Clan's Kekkei Genkai, allowing them to copy jutsu, predict motions, and cast genjutsu."
  },
  {
    id: 42,
    question: "Which of these is the main character in the masterpiece cyber-noir anime Akira?",
    options: ["Tetsuo Shima", "Shotaro Kaneda", "Yamagata", "Kai"],
    correctIdx: 1,
    explanation: "Shotaro Kaneda is the capsule-gang leader and driver of the iconic glowing red cyber-motorcycle."
  },
  {
    id: 43,
    question: "What is the true name of the legendary 'Ghost of the Uchiha' who instigated the Fourth Shinobi World War?",
    options: ["Obito Uchiha", "Madara Uchiha", "Itachi Uchiha", "Shisui Uchiha"],
    correctIdx: 1,
    explanation: "Madara Uchiha is the legendary clan head who partnered with Hashirama Senju to build Konoha, then sought the Infinite Tsukuyomi."
  },
  {
    id: 44,
    question: "What is the name of the giant wall that separates humanity from the titans at the outermost border?",
    options: ["Wall Rose", "Wall Maria", "Wall Sina", "Wall Eldia"],
    correctIdx: 1,
    explanation: "Wall Maria is the outermost wall that was breached by the Colossal Titan in the opening episode."
  },
  {
    id: 45,
    question: "Who is the primary antagonist of the Chimera Ant arc in Hunter x Hunter?",
    options: ["Hisoka", "Chrollo Lucilfer", "Meruem", "Neferpitou"],
    correctIdx: 2,
    explanation: "Meruem is the Chimera Ant King, possessing unimaginable power, tactical genius, and deep emotional growth."
  },
  {
    id: 46,
    question: "Which breathing style does Zenitsu Agatsuma use in Demon Slayer?",
    options: ["Thunder Breathing", "Beast Breathing", "Wind Breathing", "Mist Breathing"],
    correctIdx: 0,
    explanation: "Zenitsu can only use the First Form of Thunder Breathing (Thunderclap and Flash), but he has mastered it to perfection."
  },
  {
    id: 47,
    question: "Who was the first person to recruit Zoro to join Luffy's pirate crew?",
    options: ["Nami", "Monkey D. Luffy", "Shanks", "Koby"],
    correctIdx: 1,
    explanation: "Luffy personally saves Zoro from execution by Captain Morgan and convinces him to become his first crewmate."
  },
  {
    id: 48,
    question: "In Jujutsu Kaisen, who is the principal of Tokyo Jujutsu High who creates cursed corpses?",
    options: ["Masamichi Yaga", "Yoshinobu Gakuganji", "Kento Nanami", "Satoru Gojo"],
    correctIdx: 0,
    explanation: "Masamichi Yaga is the principal who constructed Panda, the independent mutation cursed corpse."
  },
  {
    id: 49,
    question: "What is the name of Bleach's fictional afterlife society where Soul Reapers dwell?",
    options: ["Hueco Mundo", "Soul Society", "Karakura Town", "Wandenreich"],
    correctIdx: 1,
    explanation: "The Soul Society is the spirit realm ruled by the Central 46, protected by the Court Guard squads (Gotei 13)."
  },
  {
    id: 50,
    question: "Which of these Saiyans is Goku's biological father?",
    options: ["King Vegeta", "Bardock", "Raditz", "Nappa"],
    correctIdx: 1,
    explanation: "Bardock is the low-class Saiyan warrior who foresaw Planet Vegeta's destruction and sent Goku to Earth."
  },
  {
    id: 51,
    question: "Who is the 'Symbol of Peace' in the My Hero Academia series?",
    options: ["Endeavor", "All Might", "Eraser Head", "Best Jeanist"],
    correctIdx: 1,
    explanation: "All Might (Toshinori Yagi) was the legendary No. 1 Pro Hero and the Symbol of Peace."
  },
  {
    id: 52,
    question: "What is the title of the famous pirate who hid the One Piece treasure and started the Great Pirate Era?",
    options: ["Gol D. Roger", "Silvers Rayleigh", "Edward Newgate", "Marshall D. Teach"],
    correctIdx: 0,
    explanation: "Gol D. Roger (The Pirate King) announced his ultimate treasure 'One Piece' on the scaffold before his execution."
  },
  {
    id: 53,
    question: "In Attack on Titan, who is Eren's adoptive sister who wears his red scarf?",
    options: ["Sasha Blouse", "Mikasa Ackerman", "Historia Reiss", "Annie Leonhart"],
    correctIdx: 1,
    explanation: "Mikasa Ackerman is Eren's fiercely protective childhood friend and fellow elite member of the Survey Corps."
  },
  {
    id: 54,
    question: "What is the name of Saitama's robotic cybernetic disciple?",
    options: ["Speed-o'-Sound Sonic", "Genos", "Mumen Rider", "Silver Fang"],
    correctIdx: 1,
    explanation: "Genos is the Demon Cyborg who witnessed Saitama's overwhelming power and begged to become his disciple."
  },
  {
    id: 55,
    question: "Which powerful organization does Gohan belong to during the Cell Games?",
    options: ["Z-Fighters", "Capsule Corp", "Red Ribbon Army", "Pride Troopers"],
    correctIdx: 0,
    explanation: "The Z-Fighters is the casual term for Earth's defenders, including Goku, Gohan, Vegeta, Piccolo, and others."
  },
  {
    id: 56,
    question: "What is the name of the main villain who orchestrated the Eclipse ritual in Berserk?",
    options: ["Guts", "Griffith", "Zodd", "Skull Knight"],
    correctIdx: 1,
    explanation: "Griffith sacrificed the Band of the Hawk during the eclipse to reincarnate as Femto, the fifth member of the God Hand."
  },
  {
    id: 57,
    question: "In Naruto, what is the name of the nine-tailed beast sealed inside Naruto's stomach?",
    options: ["Gyuki", "Matatabi", "Kurama", "Shukaku"],
    correctIdx: 2,
    explanation: "Kurama is the Nine-Tails (Kyubi) who initially hated humanity but ultimately became Naruto's closest friend."
  },
  {
    id: 58,
    question: "Which legendary sword was extracted by Arthur Boyle in Soul Eater?",
    options: ["Excalibur", "Ragnarok", "Soul Eater", "Chastiefol"],
    correctIdx: 0,
    explanation: "Excalibur is the legendary, highly annoying holy sword weapon that sings and demands 1,000 rules from its wielder."
  },
  {
    id: 59,
    question: "Who is the primary antagonist of the first season of Sword Art Online (the SAO creator)?",
    options: ["Nobuyuki Sugou", "Akihiko Kayaba", "Death Gun", "Quinella"],
    correctIdx: 1,
    explanation: "Akihiko Kayaba is the creator of SAO and NerveGear, trapping thousands of gamers inside his floating castle, Aincrad."
  },
  {
    id: 60,
    question: "What is the name of the celestial magic that Lucy uses to summon spirits using keys?",
    options: ["Solid Script Magic", "Celestial Spirit Magic", "Equip: The Knight", "Take Over Magic"],
    correctIdx: 1,
    explanation: "Lucy utilizes Celestial Spirit Magic to summon zodiac spirits from another dimension using magical gate keys."
  },
  {
    id: 61,
    question: "Which division of the military does Levi Ackerman command in Attack on Titan?",
    options: ["Special Operations Squad", "Military Police Division", "Vanguard Force", "Supplies Unit"],
    correctIdx: 0,
    explanation: "Captain Levi Ackerman commands the Special Operations Squad (often called Squad Levi) within the Survey Corps."
  },
  {
    id: 62,
    question: "What is the name of the core element of Ryuk's diet in Death Note?",
    options: ["Human souls", "Apples", "Chocolate", "Raw meat"],
    correctIdx: 1,
    explanation: "Ryuk is heavily addicted to human apples, which act like stimulants for Shinigami."
  },
  {
    id: 63,
    question: "Which cursed technique belongs to Kento Nanami in Jujutsu Kaisen?",
    options: ["Ratio Technique", "Boogie Woogie", "Projection Sorcery", "Straw Doll Technique"],
    correctIdx: 0,
    explanation: "Nanami uses the Ratio Technique, which artificially divides targets with a 7:3 ratio to create weak points."
  },
  {
    id: 64,
    question: "Who is the legendary inventor of the automail limb prosthetics in Fullmetal Alchemist?",
    options: ["Winry Rockbell", "Pinako Rockbell", "Trisha Elric", "Izumi Curtis"],
    correctIdx: 1,
    explanation: "Granny Pinako Rockbell is the legendary veteren surgeon and automail blacksmith of Resembool."
  },
  {
    id: 65,
    question: "What is the name of the main island where Gon Freecss grew up?",
    options: ["Whale Island", "Greed Island", "Zaban City", "Yorknew City"],
    correctIdx: 0,
    explanation: "Gon grew up on Whale Island, raised by his aunt Mito, before leaving to take the Hunter Exam."
  },
  {
    id: 66,
    question: "In Demon Slayer, what is the name of the Rank 3 Upper Moon demon who killed Rengoku?",
    options: ["Gyutaro", "Akaza", "Doma", "Kokushibo"],
    correctIdx: 1,
    explanation: "Akaza is the powerful hand-to-hand combat martial artist Upper Moon 3 who battled and slew Kyojuro Rengoku."
  },
  {
    id: 67,
    question: "What is the ultimate sword technique used by Zoro which channels spiritual demonic aura?",
    options: ["One Sword Style: Shishi Sonson", "Nine Sword Style: Asura", "Three Sword Style: Dragon Twister", "Two Sword Style: Rashomon"],
    correctIdx: 1,
    explanation: "Asura is a spirit-manifestation technique where Zoro's intense focus creates the illusion of a three-headed, nine-armed demon."
  },
  {
    id: 68,
    question: "Which of these characters is the legendary master of the water breathing style in Demon Slayer?",
    options: ["Sakonji Urokodaki", "Giyu Tomioka", "Kyojuro Rengoku", "Jigoro Kuwajima"],
    correctIdx: 0,
    explanation: "Sakonji Urokodaki is the former Water Hashira who trains both Giyu Tomioka and Tanjiro Kamado."
  },
  {
    id: 69,
    question: "What is the true identity of the primary antagonist of the Alabasta Arc in One Piece?",
    options: ["Sir Crocodile", "Donquixote Doflamingo", "Rob Lucci", "Gecko Moria"],
    correctIdx: 0,
    explanation: "Crocodile is the head of the Baroque Works syndicate, code-named Mr. 0, who sought the ancient weapon Pluton."
  },
  {
    id: 70,
    question: "Which character is famous for saying 'Omae wa mou shindeiru' (You are already dead)?",
    options: ["Kenshiro", "Jotaro Kujo", "Saitama", "Goku"],
    correctIdx: 0,
    explanation: "Kenshiro from Fist of the North Star says this catchphrase right before his opponent's pressure points burst."
  },
  {
    id: 71,
    question: "What is the name of the currency used in the world of One Piece?",
    options: ["Zenny", "Belly", "Gils", "Yen"],
    correctIdx: 1,
    explanation: "The global currency of the World Government and pirates alike in One Piece is the Berry (or Belly)."
  },
  {
    id: 72,
    question: "Who is the legendary creator of the legendary manga series Dragon Ball?",
    options: ["Eiichiro Oda", "Akira Toriyama", "Masashi Kishimoto", "Tite Kubo"],
    correctIdx: 1,
    explanation: "Akira Toriyama is the iconic, globally revered mangaka who created Dragon Ball, Dr. Slump, and Sand Land."
  },
  {
    id: 73,
    question: "Which legendary wizard created the cursed book of demons in Fairy Tail?",
    options: ["Zeref Dragneel", "Acnologia", "Mavis Vermillion", "Igneel"],
    correctIdx: 0,
    explanation: "Zeref, the Black Wizard, is the creator of legendary etherious demons (like Lullaby, Deliora, and E.N.D.)."
  },
  {
    id: 74,
    question: "What is the name of the legendary dragon who raised Natsu Dragneel?",
    options: ["Acnologia", "Igneel", "Metalicana", "Grandeeney"],
    correctIdx: 1,
    explanation: "Igneel, the Fire Dragon King, fostered Natsu and taught him the legendary Fire Dragon Slayer Magic."
  },
  {
    id: 75,
    question: "In Jujutsu Kaisen, what unique domain expansion has no physical barrier and allows escape?",
    options: ["Infinite Void", "Coffin of the Iron Mountain", "Malevolent Shrine", "Idle Death Gamble"],
    correctIdx: 2,
    explanation: "Sukuna's Malevolent Shrine is painted onto the real world without a separate barrier space, stretching up to 200m."
  },
  {
    id: 76,
    question: "Which member of the Akatsuki was once Itachi Uchiha's Seven Swordsman partner?",
    options: ["Kisame Hoshigaki", "Kakuzu", "Hidan", "Deidara"],
    correctIdx: 0,
    explanation: "Kisame Hoshigaki, the Monster of the Hidden Mist, was paired with Itachi and wielded the Samehada blade."
  },
  {
    id: 77,
    question: "Who is the 'Copy Ninja' who has copied over a thousand jutsu using his Sharingan?",
    options: ["Obito Uchiha", "Kakashi Hatake", "Minato Namikaze", "Jiraiya"],
    correctIdx: 1,
    explanation: "Kakashi Hatake obtained his Sharingan from Obito, earning the international moniker 'Kakashi of the Sharingan'."
  },
  {
    id: 78,
    question: "In Bleach, what is the name of the hollow mask transformation achieved by Ichigo?",
    options: ["Resurreccion", "Hollowification", "Vizard state", "Fullbring"],
    correctIdx: 1,
    explanation: "Ichigo undergoes Hollowification, tapping into the power of his inner hollow (White) to boost his stats."
  },
  {
    id: 79,
    question: "What is the name of the military commander who runs the military state of Amestris in Fullmetal Alchemist?",
    options: ["King Bradley", "Roy Mustang", "Olivier Mira Armstrong", "Maes Hughes"],
    correctIdx: 0,
    explanation: "King Bradley (who is actually the Homunculus Wrath) rules Amestris as its supreme Führer."
  },
  {
    id: 80,
    question: "Who is the legendary assassin who can skip time for 0.1 seconds in Dragon Ball Super?",
    options: ["Jiren", "Hit", "Goku Black", "Cabba"],
    correctIdx: 1,
    explanation: "Hit the Infallible is Universe 6's legendary assassin who employs the unique Time-Skip technique."
  },
  {
    id: 81,
    question: "What is the name of the ultimate, massive dragon form of Kaido in One Piece?",
    options: ["Azure Dragon", "Storm Dragon", "Volcano Dragon", "Divine Dragon"],
    correctIdx: 0,
    explanation: "Kaido ate the Fish-Fish Fruit, Model: Azure Dragon, allowing him to transform into a colossal Eastern dragon."
  },
  {
    id: 82,
    question: "Who was the legendary mentor who taught Naruto both the Rasengan and Sage Mode?",
    options: ["Kakashi Hatake", "Jiraiya", "Iruka Umino", "Orochimaru"],
    correctIdx: 1,
    explanation: "Jiraiya (The Toad Sage) took Naruto on a multi-year training journey and taught him the arts of Mount Myoboku."
  },
  {
    id: 83,
    question: "What is the true objective of the Survey Corps in Attack on Titan?",
    options: ["Protecting royal walls", "Reclaiming territory outside the walls", "Policing local districts", "Gathering taxes"],
    correctIdx: 1,
    explanation: "The Survey Corps explores the outside wilderness, studying titans and attempting to expand human territory."
  },
  {
    id: 84,
    question: "Which elite organization of powerful wizards serves the Magic Council directly in Fairy Tail?",
    options: ["The Ten Wizard Saints", "The Guild Masters", "Rune Knights", "Dark Guilds"],
    correctIdx: 0,
    explanation: "The Ten Wizard Saints are ten exceptionally powerful wizards chosen by the Magic Council for outstanding magical prowess."
  },
  {
    id: 85,
    question: "Who is the primary main character of the vintage cyberpunk classic Ghost in the Shell?",
    options: ["Motoko Kusanagi", "Batou", "Togusa", "Daisuke Aramaki"],
    correctIdx: 0,
    explanation: "Major Motoko Kusanagi is the cybernetic field commander of Public Security Section 9."
  },
  {
    id: 86,
    question: "What is the name of the central location where bounty hunters cash in their targets in Cowboy Bebop?",
    options: ["Big Shot", "Gate Bar", "Spike Shop", "Mars Station"],
    correctIdx: 0,
    explanation: "Big Shot is the corny television show where hosts Punch and Judy present active bounties."
  },
  {
    id: 87,
    question: "In Demon Slayer, which Hashira has a pet crow and wears a mismatched dual-pattern haori?",
    options: ["Giyu Tomioka", "Kyojuro Rengoku", "Shinobu Kocho", "Sanemi Shinazugawa"],
    correctIdx: 0,
    explanation: "Giyu Tomioka wears a haori split in half, honoring both his late sister Tsutako and his best friend Sabito."
  },
  {
    id: 88,
    question: "Which of these is NOT one of the classes of servants summoned in Fate/stay night?",
    options: ["Saber", "Archer", "Wizard", "Rider"],
    correctIdx: 2,
    explanation: "The spellcaster class is called Caster, not Wizard. The seven standard classes are Saber, Archer, Lancer, Rider, Caster, Assassin, and Berserker."
  },
  {
    id: 89,
    question: "What is the name of the legendary sword held by King Arthur in Fate/Zero?",
    options: ["Rule Breaker", "Gae Bolg", "Excalibur", "Enuma Elish"],
    correctIdx: 2,
    explanation: "Saber (Artoria Pendragon) wields the legendary golden blade Excalibur, the Sword of Promised Victory."
  },
  {
    id: 90,
    question: "Who is the primary mentor of Gon and Killua during the Heaven's Arena arc?",
    options: ["Wing", "Biscuit Krueger", "Isaac Netero", "Ging Freecss"],
    correctIdx: 0,
    explanation: "Wing is the Nen Master who teaches Gon and Killua the basics of Nen under the guise of Shingen-ryu kung fu."
  },
  {
    id: 91,
    question: "In Death Note, what is Light Yagami's codename used by the public?",
    options: ["Kira", "L", "Mello", "Near"],
    correctIdx: 0,
    explanation: "Kira (derived from the Japanese pronunciation of the English word 'killer') is Light's international moniker."
  },
  {
    id: 92,
    question: "Which unique martial arts style is practiced by Saitama?",
    options: ["Water Stream Rock Smashing", "Water Pole Fist", "He doesn't use any style", "Fist of Flowing Water"],
    correctIdx: 2,
    explanation: "Saitama doesn't use any formal martial arts or techniques; he simply throws basic, standard physical punches with godlike force."
  },
  {
    id: 93,
    question: "What is the name of the supreme organization of demons in Demon Slayer?",
    options: ["Twelve Kizuki", "Demon Vanguard", "The Upper Moon Coalition", "Muzan's Guard"],
    correctIdx: 0,
    explanation: "The Twelve Kizuki (Twelve Demon Moons) is the elite squad of demons split into six Upper Moons and six Lower Moons."
  },
  {
    id: 94,
    question: "Which powerful item can resurrect deceased souls in the Dragon Ball universe?",
    options: ["Dragon Balls", "Senzu Beans", "Spirit Water", "Capsule Rings"],
    correctIdx: 0,
    explanation: "Collecting all seven Dragon Balls allows a user to summon Shenron (or another dragon) to grant a wish, including resurrection."
  },
  {
    id: 95,
    question: "What is the name of Zoro's childhood friend whose sword (Wado Ichimonji) he still carries?",
    options: ["Kuina", "Tashigi", "Perona", "Hiyori"],
    correctIdx: 0,
    explanation: "Kuina was Zoro's rival who tragically died in an accident, prompting Zoro to swear to become the world's greatest swordsman."
  },
  {
    id: 96,
    question: "Who is the legendary inventor of the Rasengan technique?",
    options: ["Jiraiya", "Minato Namikaze", "Kakashi Hatake", "Naruto Uzumaki"],
    correctIdx: 1,
    explanation: "Minato Namikaze (The Fourth Hokage and Naruto's father) invented the Rasengan by modeling it after the Tailed Beast Bomb."
  },
  {
    id: 97,
    question: "In Bleach, what is the name of the Quincy leader who invaded the Soul Society?",
    options: ["Yhwach", "Sōsuke Aizen", "Gin Ichimaru", "Ulquiorra Cifer"],
    correctIdx: 0,
    explanation: "Yhwach is the Father of the Quincy and the Emperor of the Wandenreich who sought to collapse all realms."
  },
  {
    id: 98,
    question: "Which homunculus represents the sin of Pride in Fullmetal Alchemist: Brotherhood?",
    options: ["Selim Bradley", "King Bradley", "Envy", "Lust"],
    correctIdx: 0,
    explanation: "Selim Bradley, the adopted young son of Führer Bradley, is actually the ancient shadow-controlling homunculus Pride."
  },
  {
    id: 99,
    question: "Who is the legendary chairman of the Hunter Association who battled Meruem?",
    options: ["Isaac Netero", "Beyond Netero", "Ging Freecss", "Pariston Hill"],
    correctIdx: 0,
    explanation: "Isaac Netero was the 12th Chairman, wielding the legendary 100-Type Guanyin Bodhisattva in his clash with the Chimera King."
  },
  {
    id: 100,
    question: "In One Piece, which of the Seven Warlords of the Sea is known as the 'Pirate Empress'?",
    options: ["Boa Hancock", "Jewelry Bonney", "Nico Robin", "Charlotte Linlin"],
    correctIdx: 0,
    explanation: "Boa Hancock is the captain of the Kuja Pirates and the ruler of Amazon Lily, wielding the Love-Love Fruit."
  },
  {
    id: 101,
    question: "Who is the primary character of My Neighbor Totoro?",
    options: ["Satsuki", "Mei", "Totoro", "Kiki"],
    correctIdx: 2,
    explanation: "Totoro is the friendly giant forest spirit who helps the sisters Satsuki and Mei adjust to their new country life."
  },
  {
    id: 102,
    question: "What is the name of the magical, mechanical moving castle in Hayao Miyazaki's classic film?",
    options: ["Howl's Moving Castle", "Laputa Castle", "Yubaba's Bathhouse", "Sophie's Shop"],
    correctIdx: 0,
    explanation: "Howl's Moving Castle is the steampunk, leg-wielding fortress powered by the fire demon Calcifer."
  },
  {
    id: 103,
    question: "Which of the following characters from Jujutsu Kaisen uses cursed speech through seals on their tongue and cheeks?",
    options: ["Toge Inumaki", "Panda", "Maki Zenin", "Yuta Okkotsu"],
    correctIdx: 0,
    explanation: "Toge Inumaki belongs to the Inumaki clan, using cursed speech to command actions at the cost of his throat health."
  },
  {
    id: 104,
    question: "In Demon Slayer, what are the names of Tanjiro's trainers besides Urokodaki?",
    options: ["Sabito and Makomo", "Giyu and Shinobu", "Zenitsu and Inosuke", "Sumi and Kiyo"],
    correctIdx: 0,
    explanation: "Sabito and Makomo are deceased former students who appear as spirits to help Tanjiro master the Boulder Slice."
  },
  {
    id: 105,
    question: "What is the signature visual domain expansion of Satoru Gojo?",
    options: ["Infinite Void", "Coffin of the Iron Mountain", "Chimera Shadow Garden", "Self-Embodiment of Perfection"],
    correctIdx: 0,
    explanation: "Infinite Void (Muryokusho) forces the target's brain to receive endless information, leaving them completely paralyzed."
  }
];

// --- BILLIONS OF PERMUTATIONS PROCEDURAL TRIVIA ENGINE ---
// Built to support exactly 8,997,392,019 unique combinations on demand!

export interface CharacterData {
  name: string;
  anime: string;
  mentor: string;
  move: string;
  weapon: string;
  faction: string;
  rival: string;
  goal: string;
  hairColor: string;
  abilityType: string;
  companion: string;
}

export const CHARACTERS_DB: CharacterData[] = [
  {
    name: "Goku",
    anime: "Dragon Ball Z",
    mentor: "Master Roshi & King Kai",
    move: "Kamehameha & Spirit Bomb",
    weapon: "Power Pole / Flying Nimbus",
    faction: "Z-Fighters Team",
    rival: "Vegeta (Saiyan Prince)",
    goal: "Surpassing his own limits and fighting strong foes",
    hairColor: "Spiky black (golden in Super Saiyan)",
    abilityType: "Ki Manipulation & Divine Aura",
    companion: "Krillin & Vegeta"
  },
  {
    name: "Monkey D. Luffy",
    anime: "One Piece",
    mentor: "Silvers Rayleigh (Dark King)",
    move: "Gear 5 & Bajrang Gun",
    weapon: "Iconic Straw Hat",
    faction: "Straw Hat Pirates",
    rival: "Marshall D. Teach (Blackbeard)",
    goal: "Finding the One Piece and becoming King of the Pirates",
    hairColor: "Shaggy black",
    abilityType: "Rubber Devil Fruit & Conqueror Haki",
    companion: "Roronoa Zoro & Nami"
  },
  {
    name: "Naruto Uzumaki",
    anime: "Naruto Shippuden",
    mentor: "Jiraiya (Toad Sage)",
    move: "Rasengan & Rasenshuriken",
    weapon: "Nine-Tails Fox (Kurama)",
    faction: "Hidden Leaf Village (Konoha)",
    rival: "Sasuke Uchiha",
    goal: "Becoming the Hokage and gaining acknowledgment",
    hairColor: "Spiky blond",
    abilityType: "Nine-Tails Chakra & Sage Mode",
    companion: "Sasuke Uchiha & Sakura Haruno"
  },
  {
    name: "Satoru Gojo",
    anime: "Jujutsu Kaisen",
    mentor: "Principal Masamichi Yaga",
    move: "Hollow Purple & Infinite Void",
    weapon: "Six Eyes & Limitless Barrier",
    faction: "Tokyo Jujutsu High",
    rival: "Ryomen Sukuna",
    goal: "Raising strong allies to replace corrupt jujutsu leaders",
    hairColor: "Snow white hair with black blindfold",
    abilityType: "Infinity & Spatial Manipulation",
    companion: "Suguru Geto"
  },
  {
    name: "Saitama",
    anime: "One Punch Man",
    mentor: "His own rigorous physical workout",
    move: "Serious Punch",
    weapon: "Signature Yellow Suit & Red Gloves",
    faction: "Hero Association (Bald Cape)",
    rival: "Lord Boros & Garou",
    goal: "Finding an opponent who can survive a single blow",
    hairColor: "Perfect bald head",
    abilityType: "Absolute physical strength & speed",
    companion: "Genos (Cyborg Disciple)"
  },
  {
    name: "Tanjiro Kamado",
    anime: "Demon Slayer",
    mentor: "Sakonji Urokodaki (Former Water Hashira)",
    move: "Hinokami Kagura (Sun Breathing)",
    weapon: "Pitch-Black Nichirin Blade",
    faction: "Demon Slayer Corps",
    rival: "Muzan Kibutsuji",
    goal: "Curing his sister Nezuko and defeating Muzan",
    hairColor: "Burgundy red with a scar on forehead",
    abilityType: "Water Breathing & Sun Breathing",
    companion: "Nezuko Kamado & Zenitsu Agatsuma"
  },
  {
    name: "Ichigo Kurosaki",
    anime: "Bleach",
    mentor: "Kisuke Urahara & Yoruichi",
    move: "Getsuga Tensho",
    weapon: "Zanpakuto (Zangetsu)",
    faction: "Substitute Soul Reapers",
    rival: "Grimmjow & Yhwach",
    goal: "Protecting his friends, family, and the Soul Society",
    hairColor: "Bright neon orange",
    abilityType: "Bankai & Hollowfication",
    companion: "Rukia Kuchiki & Orihime Inoue"
  },
  {
    name: "Eren Yeager",
    anime: "Attack on Titan",
    mentor: "Captain Levi & Keith Shadis",
    move: "The Rumbling & Titan Hardening",
    weapon: "The Founding & Attack Titan",
    faction: "Scout Regiment & Yeagerists",
    rival: "Reiner Braun (Armored Titan)",
    goal: "Eradicating all enemies to secure absolute freedom",
    hairColor: "Dark brown",
    abilityType: "Titan Shifting powers",
    companion: "Mikasa Ackerman & Armin Arlert"
  },
  {
    name: "Light Yagami",
    anime: "Death Note",
    mentor: "Ryuk (The Shinigami)",
    move: "Kira's Judgement (Heart Attack)",
    weapon: "The Death Note notebook",
    faction: "Kira Empire",
    rival: "L Lawliet",
    goal: "Purging the world of criminals to become the God of a new world",
    hairColor: "Light chestnut brown",
    abilityType: "Masterclass deduction and intellect",
    companion: "Misa Amane"
  },
  {
    name: "Sasuke Uchiha",
    anime: "Naruto Shippuden",
    mentor: "Orochimaru (Snake Sannin)",
    move: "Chidori & Kirin",
    weapon: "Kusanagi Sword",
    faction: "Uchiha Clan / Taka Group",
    rival: "Naruto Uzumaki",
    goal: "Avenging his clan and restructuring the ninja world",
    hairColor: "Spiky dark navy blue / black",
    abilityType: "Sharingan & Rinnegan",
    companion: "Naruto Uzumaki & Sakura Haruno"
  },
  {
    name: "Ryomen Sukuna",
    anime: "Jujutsu Kaisen",
    mentor: "Self-governed peak Heian era training",
    move: "Dismantle, Cleave & Malevolent Shrine",
    weapon: "20 Indestructible Cursed Fingers",
    faction: "Heian Era Sorcerers",
    rival: "Gojo Satoru & Yuji Itadori",
    goal: "Amusing himself by fighting and consuming strong beings",
    hairColor: "Pinkish-brown styled upward with curse markings",
    abilityType: "Cursed Energy & Cleaving Slashes",
    companion: "Uraume"
  },
  {
    name: "Izuku Midoriya (Deku)",
    anime: "My Hero Academia",
    mentor: "All Might (Toshinori Yagi)",
    move: "Detroit Smash & Delaware Smash",
    weapon: "Iron Soles & Air Force Gloves",
    faction: "U.A. High School Class 1-A",
    rival: "Katsuki Bakugo",
    goal: "Becoming the world's greatest hero who saves people with a smile",
    hairColor: "Messy dark green with black highlights",
    abilityType: "One For All quirk",
    companion: "Katsuki Bakugo & Ochaco Uraraka"
  },
  {
    name: "Edward Elric",
    anime: "Fullmetal Alchemist",
    mentor: "Izumi Curtis",
    move: "Alchemy Transmutation (No Circle)",
    weapon: "Right Automail Arm Blade",
    faction: "State Alchemists of Amestris",
    rival: "Colonel Roy Mustang",
    goal: "Finding the Philosopher's Stone to restore his brother's body",
    hairColor: "Golden blond hair in a braid",
    abilityType: "Alchemical reconstructive science",
    companion: "Alphonse Elric"
  },
  {
    name: "Killua Zoldyck",
    anime: "Hunter x Hunter",
    mentor: "Biscuit Krueger & Wing",
    move: "Godspeed & Lightning Palm",
    weapon: "Metal Yo-yos & Sharp Assassin Claws",
    faction: "Hunter Association & Zoldyck Family",
    rival: "Illumi Zoldyck",
    goal: "Finding his own path and protecting his best friend Gon",
    hairColor: "Spiky silver-white",
    abilityType: "Transmuted Electricity Nen",
    companion: "Gon Freecss"
  },
  {
    name: "Gon Freecss",
    anime: "Hunter x Hunter",
    mentor: "Kite & Biscuit Krueger",
    move: "Jajanken (Rock, Paper, Scissors)",
    weapon: "Telescopic Fishing Rod",
    faction: "Hunter Association",
    rival: "Hisoka Morow",
    goal: "Becoming a elite Hunter to locate his legendary father Ging",
    hairColor: "Spiky black-green",
    abilityType: "Enhanced Physical Nen",
    companion: "Killua Zoldyck"
  },
  {
    name: "Denji",
    anime: "Chainsaw Man",
    mentor: "Captain Kishibe",
    move: "Chainsaw Shred & Devour",
    weapon: "Chainsaws emerging from limbs and forehead",
    faction: "Public Safety Special Division 4",
    rival: "Katana Man & Reze",
    goal: "Living a comfortable life, eating jam, and getting a girlfriend",
    hairColor: "Messy blond hair",
    abilityType: "Chainsaw Devil fusion (Pochita)",
    companion: "Power & Aki Hayakawa"
  },
  {
    name: "Makima",
    anime: "Chainsaw Man",
    mentor: "Public Safety High Command",
    move: "Control Force 'Bang!'",
    weapon: "Control Devil contracts",
    faction: "Public Safety Bureau",
    rival: "Chainsaw Devil",
    goal: "Creating an absolute utopia free of fear and death under her control",
    hairColor: "Light reddish-pink braided hair",
    abilityType: "Control Devil sensory power",
    companion: "Denji"
  },
  {
    name: "Levi Ackerman",
    anime: "Attack on Titan",
    mentor: "Kenny the Ripper",
    move: "Rapid Spinning Dual-Blade Slash",
    weapon: "Dual Blades & Ultra ODM Gear",
    faction: "Scout Regiment (Special Ops)",
    rival: "Zeke Yeager (Beast Titan)",
    goal: "Eliminating the Titans and honoring Commander Erwin's legacy",
    hairColor: "Black hair with clean undercut",
    abilityType: "Ackerman bloodline combat instincts",
    companion: "Erwin Smith & Hange Zoe"
  },
  {
    name: "Roronoa Zoro",
    anime: "One Piece",
    mentor: "Dracule Mihawk (Hawk Eyes)",
    move: "Santoryu (Three Sword Style) Slash",
    weapon: "Wado Ichimonji, Sandai Kitetsu & Enma",
    faction: "Straw Hat Pirates",
    rival: "Dracule Mihawk",
    goal: "Becoming the absolute strongest swordsman in the world",
    hairColor: "Short moss-green hair",
    abilityType: "Masterful swordsmanship & Haki aura",
    companion: "Monkey D. Luffy & Vinsmoke Sanji"
  },
  {
    name: "Vegeta",
    anime: "Dragon Ball Z",
    mentor: "Whis (The Angel)",
    move: "Final Flash & Big Bang Attack",
    weapon: "Saiyan Royal Battlesuit",
    faction: "Z-Fighters Team",
    rival: "Goku (Kakarot)",
    goal: "Surpassing Kakarot and claiming total Saiyan supremacy",
    hairColor: "Spiky flame-like black hair",
    abilityType: "Ki Blasts & Ultra Ego state",
    companion: "Bulma & Goku"
  },
  {
    name: "Jotaro Kujo",
    anime: "JoJo's Bizarre Adventure",
    mentor: "Joseph Joestar (Grandfather)",
    move: "Star Platinum: Ora Ora Ora Rush",
    weapon: "Time-Stopping Ability",
    faction: "Joestar Crusaders",
    rival: "DIO (Dio Brando)",
    goal: "Saving his mother Holly and eradicating DIO's lineage",
    hairColor: "Black hair fused with cap",
    abilityType: "Stand Power (Star Platinum)",
    companion: "Noriaki Kakyoin"
  },
  {
    name: "Sung Jinwoo",
    anime: "Solo Leveling",
    mentor: "The System & Shadow Monarch",
    move: "Monarch's Domain: Arise!",
    weapon: "Kamish's Wrath Dual Daggers",
    faction: "Shadow Army",
    rival: "The Monarchs",
    goal: "Protecting humanity from the dimensional gates",
    hairColor: "Sleek dark blue-black",
    abilityType: "Shadow Necromancy and leveling system",
    companion: "Shadow Soldier Igris & Beru"
  },
  {
    name: "Ken Kaneki",
    anime: "Tokyo Ghoul",
    mentor: "Yoshimura (Anteiku Manager)",
    move: "Centipede Kagune Flurry",
    weapon: "Rinkaku Kagune tentacles",
    faction: "Anteiku Café / Aogiri Tree",
    rival: "Kishou Arima (CCG Reaper)",
    goal: "Finding a peaceful coexistence between humans and ghouls",
    hairColor: "White hair (originally black)",
    abilityType: "One-Eyed Ghoul kagune",
    companion: "Touka Kirishima"
  },
  {
    name: "Yuji Itadori",
    anime: "Jujutsu Kaisen",
    mentor: "Satoru Gojo & Kento Nanami",
    move: "Black Flash & Divergent Fist",
    weapon: "Superhuman raw physical power",
    faction: "Tokyo Jujutsu High",
    rival: "Mahito (Special Grade)",
    goal: "Ensuring people pass away with a proper, dignified death",
    hairColor: "Spiky pinkish-black hair",
    abilityType: "Divergent strike & soul perception",
    companion: "Megumi Fushiguro"
  }
];

// Generates a fully randomized, completely unique question with high quality and context
export function generateProceduralQuestion(id: number): QuizQuestion {
  // Select random character
  const charIdx = Math.floor(Math.random() * CHARACTERS_DB.length);
  const c = CHARACTERS_DB[charIdx];

  // Pick random template type (out of 9 categories)
  const templateType = Math.floor(Math.random() * 9);
  
  let question = "";
  let correctOption = "";
  let fieldName: keyof CharacterData = "mentor";
  let explanation = "";

  switch (templateType) {
    case 0:
      question = `In the legendary anime "${c.anime}", who is the famous mentor or teacher of ${c.name}?`;
      correctOption = c.mentor;
      fieldName = "mentor";
      explanation = `${c.name} was mentored by ${c.mentor} in the masterpiece series "${c.anime}", which paved the way for their rise to extreme power.`;
      break;
    case 1:
      question = `Which trademark signature technique or ultimate move is famously unleashed by ${c.name} in "${c.anime}"?`;
      correctOption = c.move;
      fieldName = "move";
      explanation = `${c.name}'s ultimate signature action is "${c.move}", which has become a legendary visual in anime history.`;
      break;
    case 2:
      question = `What is the primary motivation or ultimate life goal of ${c.name} in the hit series "${c.anime}"?`;
      correctOption = c.goal;
      fieldName = "goal";
      explanation = `In "${c.anime}", ${c.name} is driven with absolute resolve to achieve their goal: ${c.goal}.`;
      break;
    case 3:
      question = `Which signature item, weapon, or power source is most closely associated with ${c.name} in "${c.anime}"?`;
      correctOption = c.weapon;
      fieldName = "weapon";
      explanation = `${c.name} famously wields, utilizes, or relies on "${c.weapon}" to combat their opponents in "${c.anime}".`;
      break;
    case 4:
      question = `Which prominent faction, group, or ancestral group is ${c.name} affiliated with in "${c.anime}"?`;
      correctOption = c.faction;
      fieldName = "faction";
      explanation = `${c.name} proudly represents or is affiliated with "${c.faction}" in the series.`;
      break;
    case 5:
      question = `Who is considered the most legendary rival, foil, or nemesis of ${c.name} in "${c.anime}"?`;
      correctOption = c.rival;
      fieldName = "rival";
      explanation = `The intense clashes between ${c.name} and ${c.rival} form the emotional core of "${c.anime}".`;
      break;
    case 6:
      question = `What distinctive hair color or recognizable visual style defines ${c.name} in "${c.anime}"?`;
      correctOption = c.hairColor;
      fieldName = "hairColor";
      explanation = `${c.name} is instantly recognizable in "${c.anime}" due to their unique ${c.hairColor}.`;
      break;
    case 7:
      question = `Which power class, energy medium, or combat attribute does ${c.name} utilize in "${c.anime}"?`;
      correctOption = c.abilityType;
      fieldName = "abilityType";
      explanation = `In the power system of "${c.anime}", ${c.name} specializes in "${c.abilityType}".`;
      break;
    case 8:
    default:
      question = `Who is the closest partner, companion, or family member who stands alongside ${c.name} in "${c.anime}"?`;
      correctOption = c.companion;
      fieldName = "companion";
      explanation = `${c.name} shares an unbreakable, iconic bond with ${c.companion} in "${c.anime}".`;
      break;
  }

  // Gather distractors (wrong answers) from other characters' fields
  const distractorPool: string[] = [];
  CHARACTERS_DB.forEach((otherChar, idx) => {
    if (idx !== charIdx) {
      const distVal = otherChar[fieldName] as string;
      if (distVal && distVal !== correctOption && !distractorPool.includes(distVal)) {
        distractorPool.push(distVal);
      }
    }
  });

  // Shuffle distractors and pick 3
  for (let i = distractorPool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [distractorPool[i], distractorPool[j]] = [distractorPool[j], distractorPool[i]];
  }
  const chosenDistractors = distractorPool.slice(0, 3);

  // If we have less than 3 distractors, add generic placeholders
  while (chosenDistractors.length < 3) {
    chosenDistractors.push("A mysterious high-tier power option");
  }

  // Create options array and place correct answer randomly
  const options = [...chosenDistractors];
  const correctIdx = Math.floor(Math.random() * 4);
  options.splice(correctIdx, 0, correctOption);

  return {
    id,
    question,
    options,
    correctIdx,
    explanation
  };
}

// Generate a large pool of dynamic questions mixed with classic ones to represent billions of combinations
export function generateProceduralQuestionsPool(count: number): QuizQuestion[] {
  const result: QuizQuestion[] = [];
  
  // Start with all 105 premium hand-crafted questions
  const baseQuestions = [...QUIZ_QUESTIONS];
  
  // Shuffle them
  for (let i = baseQuestions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [baseQuestions[i], baseQuestions[j]] = [baseQuestions[j], baseQuestions[i]];
  }
  
  result.push(...baseQuestions);

  // Programmatically generate remaining dynamic questions
  let currentId = 200;
  while (result.length < count) {
    result.push(generateProceduralQuestion(currentId));
    currentId++;
  }

  return result;
}

