import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Flame, Sparkles, Film, ArrowRight, Gamepad2 } from 'lucide-react';

interface HomeTabProps {
  onLearnMore: () => void;
  onGoToVideos: () => void;
  onPlayGame: () => void;
  logoUrl: string;
}

export default function HomeTab({ onLearnMore, onGoToVideos, onPlayGame, logoUrl }: HomeTabProps) {
  const [localLikes, setLocalLikes] = useState<number>(0);
  const [showHeartBurst, setShowHeartBurst] = useState<boolean>(false);
  const bannerPath = "/src/assets/images/cinematic_banner_1782284210001.jpg";

  const handleLikeClick = () => {
    setLocalLikes(prev => prev + 1);
    setShowHeartBurst(true);
    setTimeout(() => {
      setShowHeartBurst(false);
    }, 1000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="flex-1 flex flex-col p-4 space-y-5 pb-24 overflow-y-auto no-scrollbar bg-black"
    >
      {/* Cinematic Anime Banner Section */}
      <div id="cinematic-banner" className="relative h-[190px] rounded-2xl overflow-hidden border border-brand-purple/20 shadow-[0_0_25px_rgba(168,85,247,0.15)] group">
        {/* Dynamic visual overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
        <div className="absolute inset-0 bg-brand-purple/10 mix-blend-overlay z-10" />
        
        {/* Banner image */}
        <img 
          src={bannerPath} 
          alt="Aaravo Editz Cinematic Anime Edit" 
          className="w-full h-full object-cover transform scale-100 group-hover:scale-105 transition-transform duration-700"
          referrerPolicy="no-referrer"
          onError={(e) => {
            // High contrast anime style fallback
            e.currentTarget.src = "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=800";
          }}
        />

        {/* Text over Banner */}
        <div className="absolute bottom-4 left-4 z-20 space-y-1">
          <span className="inline-flex items-center gap-1 bg-brand-purple text-white text-[9px] font-black px-2.5 py-0.5 rounded-full tracking-widest uppercase shadow-md shadow-brand-purple/20">
            <Flame className="w-3 h-3 fill-white" /> 100% CINEMATIC VISUALS
          </span>
          <h2 className="font-display text-xl font-black tracking-tight text-white leading-tight uppercase italic glow-text-white">
            Elite Speed & Sound
          </h2>
          <p className="text-[10px] text-zinc-400 font-sans">
            Bespoke anime edits by Aaravo Editz
          </p>
        </div>
      </div>

      {/* Brand Title Branding */}
      <div className="flex flex-col items-center text-center space-y-2.5 px-1">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-16 h-16 rounded-full overflow-hidden border-2 border-brand-purple/30 shadow-ae-logo bg-zinc-950 flex-shrink-0"
        >
          <img src={logoUrl} alt="Aaravo Editz Logo" className="w-full h-full object-cover" />
        </motion.div>

        <motion.h1 
          className="font-display text-3xl font-black italic tracking-tighter text-white leading-none uppercase"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          AARAVO <span className="text-brand-purple glow-text-purple">EDITZ</span>
        </motion.h1>
        
        <p className="text-[10px] text-zinc-400 tracking-widest uppercase font-bold font-sans">
          Cinematic Anime Masterpieces • Precision Frame Sync
        </p>
      </div>

      {/* PROMOTION AND ACTION CENTER (Highly attractive, attention-grabbing) */}
      <div className="bg-[#0c071a]/50 border border-brand-purple/15 rounded-2xl p-4.5 space-y-4 shadow-xl">
        <div className="text-center space-y-1">
          <h3 className="text-xs font-display font-black tracking-wider text-brand-purple uppercase italic glow-text-purple">
            SUPPORT THE CREATOR
          </h3>
          <p className="text-[11px] text-zinc-300 font-sans">
            Slam the buttons below to support original anime visual craftsmanship!
          </p>
        </div>

        {/* Complete Redesigned CTA Button Set */}
        <div className="flex flex-col gap-3">
          
          {/* 1. EXTRA-LARGE, HIGHLY VISIBLE SUBSCRIBE BUTTON */}
          <motion.a 
            id="btn-subscribe-cta"
            href="https://www.youtube.com/@sheetalsharma9569?sub_confirmation=1"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              fetch('/api/subscribe-click', { method: 'POST' }).catch(() => {});
            }}
            whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(168, 85, 247, 0.5)" }}
            whileTap={{ scale: 0.98 }}
            className="relative flex items-center justify-center gap-3 bg-brand-purple hover:bg-brand-purple-light text-white font-display font-black text-sm tracking-widest py-4.5 px-6 rounded-xl border border-brand-purple/40 cursor-pointer text-center group transition-all shadow-[0_0_20px_rgba(168,85,247,0.3)]"
          >
            {/* YouTube Play Icon Style */}
            <div className="flex items-center justify-center bg-white rounded-lg p-1 group-hover:scale-110 transition-transform flex-shrink-0">
              <div className="w-5 h-3.5 bg-brand-red rounded flex items-center justify-center relative">
                <div className="w-0 h-0 border-t-[2.5px] border-t-transparent border-b-[2.5px] border-b-transparent border-l-[4.5px] border-l-white ml-0.5" />
              </div>
            </div>

            <span className="flex flex-col items-start leading-none">
              <span className="text-xs font-black italic uppercase tracking-wider">SUBSCRIBE ON YOUTUBE</span>
              <span className="text-[9px] opacity-80 font-medium font-sans mt-0.5">@AaravoEditz • Click to Subscribe</span>
            </span>

            {/* Floating indicator */}
            <span className="absolute right-4 top-1/2 -translate-y-1/2 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
          </motion.a>

          {/* 2. EXTRA-LARGE, HIGHLY ATTRACTIVE LIKE BUTTON WITH INTERACTIVE FEEDBACK */}
          <motion.button 
            id="btn-like-cta"
            onClick={handleLikeClick}
            whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(239, 68, 68, 0.4)" }}
            whileTap={{ scale: 0.95 }}
            className="relative flex items-center justify-center gap-3 bg-zinc-950 hover:bg-zinc-900 text-white font-display font-black text-xs tracking-widest py-3.5 px-6 rounded-xl border border-brand-red/25 cursor-pointer text-center group transition-all shadow-ae-btn"
          >
            {/* Pulsing heart icon */}
            <div className="p-1.5 bg-brand-red/10 rounded-lg border border-brand-red/30 group-hover:bg-brand-red/20 transition-all flex-shrink-0">
              <Heart className={`w-4 h-4 text-brand-red ${localLikes > 0 ? 'fill-brand-red animate-bounce' : 'group-hover:fill-brand-red/40 animate-pulse'}`} />
            </div>

            <span className="flex flex-col items-start leading-none text-left flex-1">
              <span className="text-xs font-black italic uppercase tracking-wider text-zinc-100">LIKE THE EDITS</span>
              <span className="text-[9px] text-zinc-400 font-medium font-sans mt-0.5">
                {localLikes === 0 ? "Click to leave a local squad like" : `You left ${localLikes} squad likes! Smash more!`}
              </span>
            </span>

            <AnimatePresence>
              {localLikes > 0 && (
                <motion.span 
                  initial={{ opacity: 0, scale: 0.7 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-brand-red text-white font-mono text-[9px] font-bold px-2 py-0.5 rounded-full shadow-md"
                >
                  +{localLikes}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>

        {/* Gratitude/Explosion Prompt on Like */}
        <AnimatePresence>
          {showHeartBurst && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-center bg-brand-red/10 border border-brand-red/20 rounded-lg p-2.5"
            >
              <p className="text-[10.5px] text-brand-red-light font-sans font-bold flex items-center justify-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400 animate-spin" />
                Awesome! Smash the real Like buttons on our YouTube videos next!
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* GAMING SECTION PROMOTIONAL CARD */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-display font-black tracking-widest uppercase text-zinc-500">
            MINIGAME ARENA
          </h3>
          <button 
            onClick={onPlayGame}
            className="text-[10px] text-brand-purple font-bold uppercase tracking-wider flex items-center gap-1 hover:text-brand-purple-light transition-colors"
          >
            Play Game <ArrowRight className="w-3 h-3 text-brand-purple" />
          </button>
        </div>

        <div 
          onClick={onPlayGame}
          className="relative bg-gradient-to-r from-[#0c071a] to-black border border-brand-purple/20 rounded-2xl p-4 flex flex-col gap-3.5 cursor-pointer hover:border-brand-purple/40 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)] transition-all overflow-hidden group"
        >
          {/* Animated glow effect */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-brand-purple/5 rounded-full blur-xl pointer-events-none group-hover:bg-brand-purple/15 transition-all duration-500" />
          
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-purple/10 rounded-xl border border-brand-purple/25 flex items-center justify-center text-brand-purple flex-shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.25)] group-hover:scale-115 transition-transform">
              <Gamepad2 className="w-6 h-6 animate-pulse" />
            </div>
            <div className="space-y-0.5 flex-1">
              <h4 className="text-xs font-black italic uppercase text-white tracking-wide flex items-center gap-1.5">
                Anime Battle Arena <span className="text-[8px] bg-brand-red text-white font-mono px-1.5 py-0.2 rounded-full font-bold shadow-[0_0_10px_rgba(239,68,68,0.4)]">HOT</span>
              </h4>
              <p className="text-[11px] text-zinc-300 font-sans leading-tight">
                Pick your chibi champion, battle rivals, and prove your power! Try Anime Quiz & Battle modes!
              </p>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-[#0a0515] hover:bg-brand-purple text-white hover:text-white border border-brand-purple/35 font-display font-black text-xs tracking-wider py-2.5 px-4 rounded-xl text-center shadow-[0_0_15px_rgba(168,85,247,0.15)] transition-all uppercase cursor-pointer"
          >
            PLAY GAME
          </motion.button>
        </div>
      </div>

      {/* QUICK VIEW VIDEO SHORTCUT SECTION */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-display font-black tracking-widest uppercase text-zinc-500">
            OFFICIAL VIDEOS
          </h3>
          <button 
            onClick={onGoToVideos}
            className="text-[10px] text-brand-purple font-bold uppercase tracking-wider flex items-center gap-1 hover:text-brand-purple-light transition-colors"
          >
            Open Section <ArrowRight className="w-3 h-3 text-brand-purple" />
          </button>
        </div>

        {/* Feature pitch card detailing singular video content */}
        <div 
          onClick={onGoToVideos}
          className="bg-gradient-to-r from-[#07040f] to-black border border-brand-purple/10 rounded-2xl p-4 flex items-center gap-4 cursor-pointer hover:border-brand-purple/25 hover:shadow-ae-logo transition-all"
        >
          <div className="w-12 h-12 bg-brand-purple/10 rounded-xl border border-brand-purple/20 flex items-center justify-center text-brand-purple flex-shrink-0 animate-pulse">
            <Film className="w-6 h-6" />
          </div>
          <div className="space-y-0.5 flex-1">
            <h4 className="text-xs font-black italic uppercase text-white tracking-wide">
              Official Video Section
            </h4>
            <p className="text-[11px] text-zinc-400 font-sans leading-tight">
              Watch the latest cinematic edits from Aaravo Editz here.
            </p>
          </div>
        </div>
      </div>

      {/* Support Message */}
      <div className="bg-[#0c071a]/30 border border-brand-purple/10 rounded-2xl p-4 text-center space-y-2 shadow-md">
        <h4 className="text-[10px] font-display font-black uppercase text-zinc-500 tracking-widest">
          AARAVO SQUAD CREATOR PLEDGE
        </h4>
        <p className="text-[11px] text-zinc-400 leading-relaxed px-2 font-sans">
          This channel is driven entirely by visual art and elite editing. Every like and subscription directly helps push independent anime cinematography and viral edit releases to feeds across the globe!
        </p>
      </div>

    </motion.div>
  );
}
