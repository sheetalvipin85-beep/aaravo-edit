import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Swords, 
  Zap, 
  RotateCcw, 
  Trophy, 
  Sparkles, 
  ExternalLink, 
  ShieldAlert, 
  Flame, 
  Gamepad2,
  ChevronRight,
  ShieldCheck,
  HelpCircle,
  Sparkle,
  Lock,
  Youtube,
  RefreshCw
} from 'lucide-react';
import { QUIZ_QUESTIONS as ALL_QUIZ_QUESTIONS, QuizQuestion, generateProceduralQuestionsPool } from './quizQuestions';

import { 
  Attack, 
  Fighter, 
  DuelMatchup, 
  FIGHTERS, 
  MATCHUPS, 
  VALID_CUSTOM_ATTACKS 
} from '../battleData';

interface IntensityOption {
  level: 'low' | 'medium' | 'high';
  name: string;
  mult: number;
  accuracy: number;
  color: string;
  hoverColor: string;
  description: string;
}

const INTENSITY_OPTIONS: IntensityOption[] = [
  { 
    level: 'low', 
    name: 'LOW - Precision Hit', 
    mult: 0.8, 
    accuracy: 95, 
    color: 'text-emerald-400 border-emerald-500/25 bg-emerald-500/5', 
    hoverColor: 'hover:border-emerald-500/50 hover:bg-emerald-500/10',
    description: '95% Hit Rate, deals 80% damage safely.' 
  },
  { 
    level: 'medium', 
    name: 'MEDIUM - Standard Strike', 
    mult: 1.2, 
    accuracy: 85, 
    color: 'text-brand-purple border-brand-purple/25 bg-brand-purple/5', 
    hoverColor: 'hover:border-brand-purple/50 hover:bg-brand-purple/10',
    description: '85% Hit Rate, standard combat power (120% DMG).' 
  },
  { 
    level: 'high', 
    name: 'HIGH - Overdrive Burst', 
    mult: 2.0, 
    accuracy: 60, 
    color: 'text-brand-red border-brand-red/25 bg-brand-red/5', 
    hoverColor: 'hover:border-brand-red/50 hover:bg-brand-red/10',
    description: '60% Hit Rate. High risk, colossal 200% DMG!' 
  }
];

// Premium, vector anime-inspired non-copyright avatars helper
const renderFighterAvatar = (f: Fighter, sizeClass: string = "w-8 h-8", grayscale: boolean = false) => {
  const isLarge = sizeClass.includes('w-12') || sizeClass.includes('w-16') || sizeClass.includes('w-20');
  const textSize = isLarge ? "text-[12px] md:text-[14px] font-black" : "text-[8px] font-black";
  const badgeSize = isLarge ? "w-4 h-4 bottom-1 right-1" : "w-3 h-3 bottom-0.5 right-0.5";
  const symbolSize = isLarge ? "text-[9px]" : "text-[6.5px]";

  return (
    <div className={`relative ${sizeClass} bg-gradient-to-br ${f.color} flex flex-col items-center justify-center overflow-hidden border-2 ${f.borderColor} rounded-xl shadow-[inset_0_1.5px_4px_rgba(255,255,255,0.25)] group-hover:scale-105 transition-transform duration-300 ${grayscale ? 'filter grayscale contrast-125' : ''}`}>
      {/* Stripe scanline overlay pattern */}
      <div className="absolute inset-0 bg-repeat bg-[linear-gradient(45deg,rgba(0,0,0,0.15)_25%,transparent_25%,transparent_50%,rgba(0,0,0,0.15)_50%,rgba(0,0,0,0.15)_75%,transparent_75%,transparent)] bg-[size:6px_6px] pointer-events-none" />
      
      {/* Shiny reflection */}
      <div className="absolute top-0 inset-x-0 h-[25%] bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
      
      {/* Short Name initials */}
      <span className={`font-display ${textSize} text-white select-none relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.85)] leading-none mt-0.5 tracking-tight uppercase`}>
        {f.name.split(' ')[0]}
      </span>
      
      {/* Energy symbol badge */}
      <div className={`absolute ${badgeSize} bg-black/75 rounded flex items-center justify-center border border-white/10 z-10 shadow-md`}>
        <span className={`${symbolSize} leading-none`}>{f.energySymbol}</span>
      </div>
    </div>
  );
};

interface GameTabProps {
  logoUrl?: string;
}

export default function GameTab({ logoUrl = "https://yt3.googleusercontent.com/vz3yGgm23APspUhDRBYfsEJ2_HhP9kDATIERxLi6SvcLStrVHAKjIgxcVYY_vWvfAgK1W2WkZQ=s900-c-k-c0x00ffffff-no-rj" }: GameTabProps) {
  // Game state mode selector: 'arena' or 'quiz'
  const [activeGameMode, setActiveGameMode] = useState<'arena' | 'quiz'>('arena');
  
  // Gate Lock State
  const [hasSubscribed, setHasSubscribed] = useState<boolean>(() => {
    return localStorage.getItem('aaravo_editz_subscribed_verified_v2') === 'true';
  });
  
  // Subscription verification state
  const [isVerifyingSubscription, setIsVerifyingSubscription] = useState<boolean>(false);
  const [subscribeCountdown, setSubscribeCountdown] = useState<number>(15);

  useEffect(() => {
    if (!isVerifyingSubscription) return;

    const interval = setInterval(() => {
      setSubscribeCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setHasSubscribed(true);
          localStorage.setItem('aaravo_editz_subscribed_verified_v2', 'true');
          setIsVerifyingSubscription(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isVerifyingSubscription]);

  // Active Shuffled Quiz Questions (initialized from a pool of 8,997,392,019 potential combinations)
  const [activeQuestions, setActiveQuestions] = useState<QuizQuestion[]>(() => {
    return generateProceduralQuestionsPool(2000);
  });

  // Premium Battle VFX State
  const [activeVfx, setActiveVfx] = useState<{
    type: 'slash' | 'blast' | 'impact' | 'glow' | 'none';
    side: 'player' | 'enemy';
    color: string;
  }>({ type: 'none', side: 'player', color: 'bg-brand-purple' });

  // Custom Attack Error State
  const [customAttackError, setCustomAttackError] = useState<string | null>(null);

  // Arena Game States
  // 'selection' -> 'char-selection' -> 'battle' -> 'ended'
  const [gameState, setGameState] = useState<'selection' | 'char-selection' | 'battle' | 'ended'>('selection');
  const [selectedMatchup, setSelectedMatchup] = useState<DuelMatchup | null>(null);
  
  const [playerFighter, setPlayerFighter] = useState<Fighter | null>(null);
  const [enemyFighter, setEnemyFighter] = useState<Fighter | null>(null);
  
  // Battle step state: 'choose-attack' | 'choose-intensity'
  const [battleStep, setBattleStep] = useState<'choose-attack' | 'choose-intensity'>('choose-attack');
  const [selectedAttack, setSelectedAttack] = useState<Attack | null>(null);
  
  // Custom Attack Input State
  const [customAttackText, setCustomAttackText] = useState<string>('');
  
  // Stats
  const [playerHp, setPlayerHp] = useState<number>(120);
  const [enemyHp, setEnemyHp] = useState<number>(120);
  const [playerMaxHp, setPlayerMaxHp] = useState<number>(120);
  const [enemyMaxHp, setEnemyMaxHp] = useState<number>(120);
  
  const [winner, setWinner] = useState<'player' | 'enemy' | null>(null);
  const [isPlayerAttacking, setIsPlayerAttacking] = useState<boolean>(false);
  const [isEnemyAttacking, setIsEnemyAttacking] = useState<boolean>(false);
  const [screenShake, setScreenShake] = useState<boolean>(false);
  
  // Action status message shown directly on the visual stage container!
  const [battleNarratorMessage, setBattleNarratorMessage] = useState<string>('Select your fighter\'s opening move below!');
  
  // Floating Damage Indicators
  const [damageIndicators, setDamageIndicators] = useState<Array<{ id: number; damage: number | string; isCritical: boolean; isPlayer: boolean }>>([]);

  // Anime Quiz States
  const [currentQuizIdx, setCurrentQuizIdx] = useState<number>(0);
  const [selectedQuizAnswerIdx, setSelectedQuizAnswerIdx] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [showQuizExplanation, setShowQuizExplanation] = useState<boolean>(false);

  // Handle Subscribe Action to enter
  const handleSubscribeToEnter = () => {
    window.open('https://www.youtube.com/@sheetalsharma9569', '_blank');
    setSubscribeCountdown(15);
    setIsVerifyingSubscription(true);

    // Record the website click count dynamically
    fetch('/api/subscribe-click', { method: 'POST' })
      .catch(err => console.warn("Failed to record website subscribe click:", err));
  };

  const selectMatchup = (matchup: DuelMatchup) => {
    setSelectedMatchup(matchup);
    setGameState('char-selection');
  };

  const selectCharacter = (fighterId: string) => {
    if (!selectedMatchup) return;
    
    const isA = selectedMatchup.fighterAId === fighterId;
    const pId = isA ? selectedMatchup.fighterAId : selectedMatchup.fighterBId;
    const eId = isA ? selectedMatchup.fighterBId : selectedMatchup.fighterAId;
    
    // Deep clone to allow adding custom attacks locally
    const pFighter = JSON.parse(JSON.stringify(FIGHTERS[pId])) as Fighter;
    const eFighter = JSON.parse(JSON.stringify(FIGHTERS[eId])) as Fighter;
    
    setPlayerFighter(pFighter);
    setEnemyFighter(eFighter);
    
    setPlayerHp(120);
    setPlayerMaxHp(120);
    setEnemyHp(120);
    setEnemyMaxHp(120);
    
    setSelectedAttack(null);
    setBattleStep('choose-attack');
    setBattleNarratorMessage(`LET'S CLASH! ${pFighter.name} vs ${eFighter.name}! Select an attack command.`);
    setGameState('battle');
  };

  const spawnDamageIndicator = (damage: number | string, isCritical: boolean, isPlayer: boolean) => {
    const id = Math.random();
    setDamageIndicators(prev => [...prev, { id, damage, isCritical, isPlayer }]);
    setTimeout(() => {
      setDamageIndicators(prev => prev.filter(ind => ind.id !== id));
    }, 1100);
  };

  const chooseAttackStep = (attack: Attack) => {
    setSelectedAttack(attack);
    setBattleStep('choose-intensity');
    setBattleNarratorMessage(`Loaded ${attack.name.toUpperCase()}! Select impact intensity to engage...`);
  };

  // LOAD CUSTOM ATTACK
  const handleLoadCustomAttack = () => {
    setCustomAttackError(null);
    const input = customAttackText.trim().toUpperCase();
    if (!input || !playerFighter) return;

    // Fetch the list of valid attacks for this specific fighter
    const validList = VALID_CUSTOM_ATTACKS[playerFighter.id] || [];
    const isValid = validList.includes(input);

    if (!isValid) {
      setCustomAttackError("Invalid attack. You damaged yourself.");
      
      const selfDmg = 15;
      setPlayerHp(prev => {
        const next = Math.max(0, prev - selfDmg);
        if (next === 0) {
          setTimeout(() => triggerVictory('enemy'), 1200);
        }
        return next;
      });

      spawnDamageIndicator("15 SELF DMG", false, true);
      setBattleNarratorMessage(`⚠️ Invalid attack! ${playerFighter.name} misfired and damaged themselves for ${selfDmg} HP!`);
      setCustomAttackText('');

      // Opponent retaliates as penalty
      setTimeout(() => {
        setPlayerHp(currentPlayerHp => {
          if (currentPlayerHp > 0) {
            triggerEnemyCounter();
          }
          return currentPlayerHp;
        });
      }, 1500);
      return;
    }

    const customAtk: Attack = {
      name: input,
      baseDmg: 25,
      description: "Custom personal technique of sheer visual impact!"
    };

    // Add directly to current player fighter's attacks temporarily
    setPlayerFighter(prev => {
      if (!prev) return null;
      // Filter out existing custom attacks to avoid duplicate cluttering
      const originalAttacks = prev.attacks.filter(a => a.name !== customAtk.name);
      return {
        ...prev,
        attacks: [customAtk, ...originalAttacks]
      };
    });

    setCustomAttackText('');
    chooseAttackStep(customAtk);
  };

  // AUTOMATIC ENGAGE ATTACK UPON SELECTING INTENSITY
  const chooseIntensityAndEngage = (intensity: IntensityOption) => {
    if (isPlayerAttacking || isEnemyAttacking || !selectedAttack || !playerFighter || !enemyFighter) return;

    setIsPlayerAttacking(true);
    setScreenShake(true);
    setBattleNarratorMessage(`💥 ${playerFighter.name} launches ${selectedAttack.name} [${intensity.level.toUpperCase()}]!`);

    // Trigger Player's premium battle VFX
    const nameUpper = selectedAttack.name.toUpperCase();
    let vfxType: 'slash' | 'blast' | 'impact' | 'glow' = 'impact';
    let vfxColor = 'bg-brand-purple shadow-[0_0_20px_rgba(168,85,247,0.85)]';

    if (nameUpper.includes("SLASH") || nameUpper.includes("CLEAVE") || nameUpper.includes("CUT") || nameUpper.includes("SWORD") || nameUpper.includes("WHEEL") || nameUpper.includes("WIP") || nameUpper.includes("CLAW")) {
      vfxType = 'slash';
      vfxColor = 'bg-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.95)]';
    } else if (nameUpper.includes("KAMEHAMEHA") || nameUpper.includes("BEAST") || nameUpper.includes("BLAST") || nameUpper.includes("PURPLE") || nameUpper.includes("ENERGY") || nameUpper.includes("FIRE") || nameUpper.includes("FLARE") || nameUpper.includes("RASENGAN") || nameUpper.includes("CHIDORI") || nameUpper.includes("AMATERASU") || nameUpper.includes("KIRIN")) {
      vfxType = 'blast';
      vfxColor = nameUpper.includes("KAMEHAMEHA") || nameUpper.includes("BLUE") || nameUpper.includes("CHIDORI") || nameUpper.includes("KIRIN") 
        ? 'bg-blue-400 shadow-[0_0_25px_rgba(56,189,248,0.95)]' 
        : 'bg-brand-purple shadow-[0_0_25px_rgba(168,85,247,0.95)]';
    } else if (nameUpper.includes("ULTRA") || nameUpper.includes("DOMAIN") || nameUpper.includes("SPECIAL") || nameUpper.includes("SHRINE") || nameUpper.includes("VOID") || nameUpper.includes("MAHORAGA")) {
      vfxType = 'glow';
      vfxColor = 'bg-amber-400 shadow-[0_0_30px_rgba(245,158,11,1)]';
    }

    setActiveVfx({ type: vfxType, side: 'player', color: vfxColor });

    const accuracyRoll = Math.random() * 100;
    const isHit = accuracyRoll <= intensity.accuracy;
    
    setTimeout(() => {
      setScreenShake(false);
      setActiveVfx({ type: 'none', side: 'player', color: '' });
      
      if (isHit) {
        const isCrit = Math.random() < 0.25 || intensity.level === 'high';
        const rawDmg = selectedAttack.baseDmg * intensity.mult;
        const variance = Math.floor(Math.random() * 5) - 2;
        const damageDealt = Math.max(5, Math.round(rawDmg * (isCrit ? 1.4 : 1) + variance));

        setEnemyHp(prev => {
          const next = Math.max(0, prev - damageDealt);
          if (next === 0) {
            setTimeout(() => triggerVictory('player'), 1200);
          }
          return next;
        });

        spawnDamageIndicator(damageDealt, isCrit, false);
        setBattleNarratorMessage(`🔥 HIT! ${playerFighter.name} dealt ${damageDealt} DMG with ${selectedAttack.name}!`);
      } else {
        spawnDamageIndicator("EVADED", false, false);
        setBattleNarratorMessage(`💨 MISS! ${enemyFighter.name} gracefully dodged the strike!`);
      }

      setIsPlayerAttacking(false);

      // AI retaliates if still alive
      setTimeout(() => {
        setEnemyHp(currentEnemyHp => {
          if (currentEnemyHp > 0) {
            triggerEnemyCounter();
          }
          return currentEnemyHp;
        });
      }, 1000);

    }, 850);
  };

  const triggerEnemyCounter = () => {
    if (!enemyFighter || !playerFighter || gameState !== 'battle') return;

    setIsEnemyAttacking(true);
    setScreenShake(true);

    // AI selects an attack and intensity randomly
    const randomAttack = enemyFighter.attacks[Math.floor(Math.random() * enemyFighter.attacks.length)];
    const randomIntensity = INTENSITY_OPTIONS[Math.floor(Math.random() * INTENSITY_OPTIONS.length)];

    setBattleNarratorMessage(`🚨 WARNING! ${enemyFighter.name} retaliates with ${randomAttack.name.toUpperCase()}!`);

    // Trigger Enemy's premium battle VFX
    const nameUpper = randomAttack.name.toUpperCase();
    let vfxType: 'slash' | 'blast' | 'impact' | 'glow' = 'impact';
    let vfxColor = 'bg-brand-red shadow-[0_0_20px_rgba(239,68,68,0.85)]';

    if (nameUpper.includes("SLASH") || nameUpper.includes("CLEAVE") || nameUpper.includes("CUT") || nameUpper.includes("SWORD") || nameUpper.includes("WHEEL") || nameUpper.includes("WIP") || nameUpper.includes("CLAW")) {
      vfxType = 'slash';
      vfxColor = 'bg-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.95)]';
    } else if (nameUpper.includes("KAMEHAMEHA") || nameUpper.includes("BEAST") || nameUpper.includes("BLAST") || nameUpper.includes("PURPLE") || nameUpper.includes("ENERGY") || nameUpper.includes("FIRE") || nameUpper.includes("FLARE") || nameUpper.includes("RASENGAN") || nameUpper.includes("CHIDORI") || nameUpper.includes("AMATERASU") || nameUpper.includes("KIRIN")) {
      vfxType = 'blast';
      vfxColor = 'bg-red-500 shadow-[0_0_25px_rgba(239,68,68,0.95)]';
    } else if (nameUpper.includes("ULTRA") || nameUpper.includes("DOMAIN") || nameUpper.includes("SPECIAL") || nameUpper.includes("SHRINE") || nameUpper.includes("VOID") || nameUpper.includes("MAHORAGA")) {
      vfxType = 'glow';
      vfxColor = 'bg-red-700 shadow-[0_0_30px_rgba(185,28,28,1)]';
    }

    setActiveVfx({ type: vfxType, side: 'enemy', color: vfxColor });

    const accuracyRoll = Math.random() * 100;
    const isHit = accuracyRoll <= randomIntensity.accuracy;

    setTimeout(() => {
      setScreenShake(false);
      setActiveVfx({ type: 'none', side: 'enemy', color: '' });

      if (isHit) {
        const isCrit = Math.random() < 0.2;
        const rawDmg = randomAttack.baseDmg * randomIntensity.mult;
        const damageDealt = Math.max(4, Math.round(rawDmg * (isCrit ? 1.3 : 1) + Math.floor(Math.random() * 4)));

        setPlayerHp(prev => {
          const next = Math.max(0, prev - damageDealt);
          if (next === 0) {
            setTimeout(() => triggerVictory('enemy'), 1200);
          }
          return next;
        });

        spawnDamageIndicator(damageDealt, isCrit, true);
        setBattleNarratorMessage(`💥 OUCH! ${enemyFighter.name} slammed you with ${randomAttack.name} for ${damageDealt} DMG!`);
      } else {
        spawnDamageIndicator("BLOCKED", false, true);
        setBattleNarratorMessage(`🛡️ NICE! You successfully blocked ${enemyFighter.name}'s counter!`);
      }

      // Return control to player deck
      setSelectedAttack(null);
      setBattleStep('choose-attack');
      setIsEnemyAttacking(false);

    }, 1000);
  };

  const triggerVictory = (winnerSide: 'player' | 'enemy') => {
    setWinner(winnerSide);
    setGameState('ended');
  };

  const restartGame = () => {
    setPlayerFighter(null);
    setEnemyFighter(null);
    setSelectedMatchup(null);
    setSelectedAttack(null);
    setWinner(null);
    setGameState('selection');
  };

  // Anime Quiz Handlers
  const handleQuizAnswerSubmit = (idx: number) => {
    if (selectedQuizAnswerIdx !== null) return; // Prevent double clicks
    setSelectedQuizAnswerIdx(idx);
    setShowQuizExplanation(true);
    const currentQuestion = activeQuestions[currentQuizIdx] || ALL_QUIZ_QUESTIONS[0];
    if (idx === currentQuestion.correctIdx) {
      setQuizScore(prev => prev + 10);
    }
  };

  const handleNextQuizQuestion = () => {
    setSelectedQuizAnswerIdx(null);
    setShowQuizExplanation(false);
    setCurrentQuizIdx(prev => (prev + 1) % activeQuestions.length);
  };

  const shuffleQuestions = (questionsList: QuizQuestion[]) => {
    const shuffled = [...questionsList];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const restartQuiz = () => {
    setSelectedQuizAnswerIdx(null);
    setShowQuizExplanation(false);
    setCurrentQuizIdx(0);
    setQuizScore(0);
    setActiveQuestions(generateProceduralQuestionsPool(2000));
  };

  return (
    <div className="flex-1 flex flex-col p-4 space-y-3.5 bg-black h-full overflow-hidden relative">
      
      {/* Redesigned Premium Header */}
      <div className="flex items-center gap-3 pb-3 border-b border-brand-purple/10 justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full overflow-hidden border border-brand-purple/30 shadow-ae-logo flex-shrink-0 bg-zinc-950">
            <img src={logoUrl} alt="Aaravo Editz Logo" className="w-full h-full object-cover" />
          </div>
          <div className="text-left">
            <h2 className="font-display text-base font-black italic text-white uppercase tracking-tighter leading-none flex items-center gap-1.5">
              ANIME GAME <span className="text-brand-purple glow-text-purple">PORTAL</span>
            </h2>
            <p className="text-[9px] text-zinc-500 font-sans tracking-wide uppercase font-bold mt-0.5">
              Aaravo Editz Interactive Studio
            </p>
          </div>
        </div>
        
        {/* Test Lock Mode for the user */}
        {hasSubscribed && (
          <button
            onClick={() => {
              localStorage.removeItem('aaravo_editz_subscribed_verified_v2');
              setHasSubscribed(false);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-[8px] font-sans font-black bg-brand-purple/20 border border-brand-purple/30 hover:border-brand-purple/50 text-brand-purple-light hover:bg-brand-purple/40 rounded-lg transition-all uppercase tracking-wider cursor-pointer"
            title="Lock Arena for Testing"
          >
            <Lock className="w-2.5 h-2.5 text-brand-purple animate-pulse" /> Re-Lock
          </button>
        )}
      </div>

      {/* GAME MODE SWITCHER TAB BAR */}
      <div className="flex bg-[#0c071a]/50 border border-brand-purple/10 p-1 rounded-xl">
        <button
          onClick={() => {
            if (hasSubscribed) {
              setActiveGameMode('arena');
            }
          }}
          disabled={!hasSubscribed}
          className={`flex-1 py-1.5 text-[10px] font-display font-black uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            !hasSubscribed ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'
          } ${
            activeGameMode === 'arena' 
              ? 'bg-brand-purple text-white shadow-md' 
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Gamepad2 className="w-3.5 h-3.5" /> CLASH ARENA
        </button>
        <button
          onClick={() => {
            if (hasSubscribed) {
              setActiveGameMode('quiz');
            }
          }}
          disabled={!hasSubscribed}
          className={`flex-1 py-1.5 text-[10px] font-display font-black uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            !hasSubscribed ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'
          } ${
            activeGameMode === 'quiz' 
              ? 'bg-brand-purple text-white shadow-md' 
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <HelpCircle className="w-3.5 h-3.5" /> ANIME QUIZ
        </button>
      </div>

      {/* GAME WRAPPER WITH ABSOLUTE CENTERING & NO OVERFLOW */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative">

        {/* Game contents container - blurred and disabled when locked */}
        <div className={`flex-1 flex flex-col min-h-0 ${!hasSubscribed ? 'blur-md select-none pointer-events-none saturate-[0.15] brightness-[0.25]' : ''}`}>

        {/* ----------------- GAME MODE 1: CLASH ARENA ----------------- */}
        {activeGameMode === 'arena' && (
          <div className="flex-1 flex flex-col min-h-0">
            
            {/* MATCHUP SELECTION GRID */}
            {gameState === 'selection' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 flex flex-col min-h-0"
              >
                <div className="flex items-center justify-between px-1 mb-2 flex-shrink-0">
                  <span className="text-[9px] font-display font-black text-brand-purple tracking-widest uppercase italic">
                    STEP 1: SELECT YOUR TARGET CLASH MATCHUP
                  </span>
                  <span className="text-[8px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono px-2 py-0.5 rounded-full flex items-center gap-1 font-bold">
                    <ShieldCheck className="w-2.5 h-2.5" /> ARENA LIVE
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto no-scrollbar pr-1 space-y-1.5">
                  {MATCHUPS.map((matchup) => {
                    const fA = FIGHTERS[matchup.fighterAId];
                    const fB = FIGHTERS[matchup.fighterBId];
                    return (
                      <motion.div
                        key={matchup.id}
                        onClick={() => selectMatchup(matchup)}
                        whileHover={{ scale: 1.012, borderColor: 'rgba(168, 85, 247, 0.35)' }}
                        whileTap={{ scale: 0.988 }}
                        className="bg-zinc-950 hover:bg-[#0c071a]/50 border border-white/5 rounded-xl p-2.5 flex items-center justify-between cursor-pointer transition-all"
                      >
                        <div className="flex items-center gap-2.5">
                          {/* SQUARE character avatar container */}
                          {renderFighterAvatar(fA, "w-8 h-8", true)}
                          
                          <div className="flex items-center gap-1.5">
                            <span className="font-display text-[10px] font-black tracking-tight text-white uppercase">{fA.name.split(' ')[0]}</span>
                            <span className="text-[8px] text-brand-purple font-black italic">VS</span>
                            <span className="font-display text-[10px] font-black tracking-tight text-zinc-300 uppercase">{fB.name.split(' ')[0]}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* SQUARE character avatar container */}
                          {renderFighterAvatar(fB, "w-8 h-8", true)}
                          <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* CHARACTER SELECTION FOR SELECTED MATCHUP */}
            {gameState === 'char-selection' && selectedMatchup && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex-1 flex flex-col justify-center space-y-3.5"
              >
                <div className="flex items-center justify-between px-1">
                  <span className="text-[9px] font-display font-black text-brand-purple tracking-widest uppercase italic">
                    STEP 2: CHOOSE YOUR CHAMPION SIDE
                  </span>
                  <button 
                    onClick={() => setGameState('selection')}
                    className="text-[9px] text-zinc-500 hover:text-white font-mono uppercase underline"
                  >
                    Back to Matchups
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3.5">
                  {/* Option Left Fighter */}
                  {(() => {
                    const f = FIGHTERS[selectedMatchup.fighterAId];
                    return (
                      <div 
                        onClick={() => selectCharacter(f.id)}
                        className="bg-gradient-to-b from-zinc-950 to-black border-2 border-white/5 hover:border-brand-purple/40 rounded-none p-3.5 flex flex-col items-center justify-center text-center cursor-pointer group transition-all hover:shadow-[0_0_15px_rgba(168,85,247,0.15)]"
                      >
                        {/* Perfect Square avatar */}
                        <div className="mb-2.5">
                          {renderFighterAvatar(f, "w-16 h-16")}
                        </div>
                        <h4 className="font-display text-xs font-black text-white uppercase tracking-tight leading-none">{f.name.split(' ')[0]}</h4>
                        <span className="text-[8px] text-zinc-500 font-mono italic mt-1 leading-none">{f.title}</span>
                        <div className="mt-3.5 bg-brand-purple/10 border border-brand-purple/20 rounded px-2.5 py-1 text-[8px] text-brand-purple-light font-bold uppercase tracking-wider group-hover:bg-brand-purple group-hover:text-white transition-all">
                          PLAY SIDE
                        </div>
                      </div>
                    );
                  })()}

                  {/* Option Right Fighter */}
                  {(() => {
                    const f = FIGHTERS[selectedMatchup.fighterBId];
                    return (
                      <div 
                        onClick={() => selectCharacter(f.id)}
                        className="bg-gradient-to-b from-zinc-950 to-black border-2 border-white/5 hover:border-brand-purple/40 rounded-none p-3.5 flex flex-col items-center justify-center text-center cursor-pointer group transition-all hover:shadow-[0_0_15px_rgba(168,85,247,0.15)]"
                      >
                        {/* Perfect Square avatar */}
                        <div className="mb-2.5">
                          {renderFighterAvatar(f, "w-16 h-16")}
                        </div>
                        <h4 className="font-display text-xs font-black text-white uppercase tracking-tight leading-none">{f.name.split(' ')[0]}</h4>
                        <span className="text-[8px] text-zinc-500 font-mono italic mt-1 leading-none">{f.title}</span>
                        <div className="mt-3.5 bg-brand-purple/10 border border-brand-purple/20 rounded px-2.5 py-1 text-[8px] text-brand-purple-light font-bold uppercase tracking-wider group-hover:bg-brand-purple group-hover:text-white transition-all">
                          PLAY SIDE
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </motion.div>
            )}

            {/* LIVE COMBAT VIEW: ABSOLUTELY FIXED STAGE AND CONTROL PANEL - NO SCROLL */}
            {gameState === 'battle' && playerFighter && enemyFighter && (
              <div className={`flex-1 flex flex-col justify-center space-y-3 min-h-0 ${screenShake ? 'animate-shake' : ''}`}>
                
                {/* Visual Arena Stage container - Height constrained to prevent overflow & scrolling */}
                <div className="relative bg-[#05030a] rounded-xl border border-brand-purple/15 overflow-hidden h-[185px] sm:h-[205px] w-full p-3 flex flex-col justify-between shadow-[0_0_20px_rgba(168,85,247,0.1)] flex-shrink-0">
                  <div className="absolute inset-0 bg-cover bg-center opacity-5 pointer-events-none" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=600')` }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none" />
                  
                  {/* FLOATING DAMAGE POPUPS */}
                  <AnimatePresence>
                    {damageIndicators.map((ind) => (
                      <motion.div
                        key={ind.id}
                        initial={{ opacity: 0, y: 15, scale: 0.7 }}
                        animate={{ opacity: 1, y: -20, scale: ind.isCritical ? 1.3 : 1 }}
                        exit={{ opacity: 0 }}
                        className={`absolute z-30 font-display font-black text-xl italic tracking-tighter ${
                          ind.isPlayer ? 'left-1/4 top-1/3 text-brand-red' : 'right-1/4 top-1/3 text-yellow-400'
                        } drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]`}
                      >
                        {typeof ind.damage === 'number' ? `-${ind.damage}` : ind.damage}
                        {ind.isCritical && typeof ind.damage === 'number' && <span className="text-[8px] block uppercase font-mono tracking-widest text-white mt-0.5">CRIT!</span>}
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Top Health Bars with smooth layout styling */}
                  <div className="flex justify-between items-start gap-2.5 z-10 relative">
                    {/* Player Side */}
                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between text-[9px] font-bold">
                        <span className="text-white font-display uppercase tracking-tight flex items-center gap-1">
                          <span className="w-1.5 h-1.5 bg-green-500 rounded-full" /> {playerFighter.name.split(' ')[0]}
                        </span>
                        <span className="text-zinc-400 font-mono text-[9px]">{playerHp}/{playerMaxHp}</span>
                      </div>
                      <div className="h-2 bg-zinc-950 border border-white/5 rounded-none overflow-hidden p-0.5">
                        <motion.div 
                          initial={{ width: '100%' }}
                          animate={{ width: `${(playerHp / playerMaxHp) * 100}%` }}
                          className="h-full bg-gradient-to-r from-brand-purple to-brand-red rounded-none shadow-[0_0_8px_rgba(168,85,247,0.4)]"
                        />
                      </div>
                    </div>

                    <div className="text-brand-purple font-display font-black italic text-[9px] pt-1 flex-shrink-0">VS</div>

                    {/* Opponent Side */}
                    <div className="flex-1 space-y-1 text-right">
                      <div className="flex justify-between text-[9px] font-bold flex-row-reverse">
                        <span className="text-white font-display uppercase tracking-tight text-brand-red flex items-center gap-1 flex-row-reverse">
                          <span className="w-1.5 h-1.5 bg-brand-red rounded-full animate-pulse" /> {enemyFighter.name.split(' ')[0]}
                        </span>
                        <span className="text-zinc-400 font-mono text-[9px]">{enemyHp}/{enemyMaxHp}</span>
                      </div>
                      <div className="h-2 bg-zinc-950 border border-white/5 rounded-none overflow-hidden p-0.5">
                        <motion.div 
                          initial={{ width: '100%' }}
                          animate={{ width: `${(enemyHp / enemyMaxHp) * 100}%` }}
                          className="h-full bg-gradient-to-l from-brand-red to-rose-600 rounded-none shadow-[0_0_8px_rgba(239,68,68,0.4)] ml-auto"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Duelists representation frames */}
                  <div className="flex justify-between items-end h-20 relative mt-auto px-2 z-10 pb-0.5">
                    {/* Player side */}
                    <motion.div
                      animate={{ 
                        x: isPlayerAttacking ? 50 : 0,
                        y: isPlayerAttacking ? -10 : 0,
                        scale: isPlayerAttacking ? 1.15 : 1,
                        rotate: isPlayerAttacking ? 6 : 0
                      }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col items-center gap-1 w-16"
                    >
                      <div className="relative">
                        {renderFighterAvatar(playerFighter, "w-12 h-12")}
                        {isPlayerAttacking && <div className="absolute inset-0 bg-brand-purple/40 rounded-xl animate-ping pointer-events-none" />}
                      </div>
                      <span className="bg-black/95 text-[8px] text-zinc-400 font-mono px-1 rounded-none border border-white/5 whitespace-nowrap leading-tight">
                        {playerFighter.energySymbol} SQUAD
                      </span>
                    </motion.div>

                    {/* PREMIUM BATTLE VFX CONTAINER */}
                    <AnimatePresence>
                      {activeVfx.type !== 'none' && (
                        <div className="absolute inset-0 z-20 pointer-events-none flex items-center justify-center overflow-hidden">
                          
                          {/* 1. SLASH VFX */}
                          {activeVfx.type === 'slash' && (
                            <motion.div
                              initial={{ 
                                rotate: activeVfx.side === 'player' ? -25 : 25, 
                                scaleX: 0, 
                                opacity: 0,
                                y: activeVfx.side === 'player' ? 10 : -10
                              }}
                              animate={{ 
                                scaleX: [0, 1.2, 0], 
                                opacity: [0, 1, 1, 0],
                                x: activeVfx.side === 'player' ? [-40, 40] : [40, -40]
                              }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 0.5, ease: "easeInOut" }}
                              className={`h-2.5 w-[130%] absolute ${activeVfx.color} rounded-full transform`}
                            />
                          )}

                          {/* 2. BLAST VFX (Energy Beam) */}
                          {activeVfx.type === 'blast' && (
                            <motion.div
                              initial={{ 
                                scaleY: 0.1, 
                                scaleX: 0, 
                                opacity: 0,
                                x: activeVfx.side === 'player' ? -80 : 80 
                              }}
                              animate={{ 
                                scaleX: [0, 1.5, 1], 
                                scaleY: [0.1, 2.5, 0.2, 0],
                                opacity: [0, 1, 1, 0],
                                x: activeVfx.side === 'player' ? [-80, 80] : [80, -80]
                              }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 0.6, ease: "easeOut" }}
                              className={`h-4 w-40 absolute rounded-full ${activeVfx.color}`}
                            />
                          )}

                          {/* 3. IMPACT VFX (Explosion/Shockwave) */}
                          {activeVfx.type === 'impact' && (
                            <div className="relative flex items-center justify-center">
                              {/* Shockwave ring */}
                              <motion.div
                                initial={{ scale: 0.1, opacity: 0, border: '2px solid rgba(255,255,255,0.8)' }}
                                animate={{ scale: [0.1, 2.5], opacity: [0, 1, 0] }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.4 }}
                                className="absolute rounded-full w-24 h-24"
                              />
                              {/* Flash sparks */}
                              <motion.div
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ scale: [0.5, 1.8, 0], opacity: [0, 1, 1, 0] }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.4 }}
                                className={`absolute w-12 h-12 rounded-full ${activeVfx.color} blur-sm`}
                              />
                            </div>
                          )}

                          {/* 4. GLOW / CINEMATIC OVERLAY */}
                          {activeVfx.type === 'glow' && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: [0, 0.75, 0] }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 0.7 }}
                              className="absolute inset-0 bg-gradient-to-r from-brand-purple/20 via-white/40 to-brand-red/20 mix-blend-color-dodge"
                            />
                          )}

                        </div>
                      )}
                    </AnimatePresence>

                    {/* Enemy side */}
                    <motion.div
                      animate={{ 
                        x: isEnemyAttacking ? -50 : 0,
                        y: isEnemyAttacking ? -10 : 0,
                        scale: isEnemyAttacking ? 1.15 : 1,
                        rotate: isEnemyAttacking ? -6 : 0
                      }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col items-center gap-1 w-16"
                    >
                      <div className="relative">
                        {renderFighterAvatar(enemyFighter, "w-12 h-12")}
                        {isEnemyAttacking && <div className="absolute inset-0 bg-brand-red/40 rounded-xl animate-ping pointer-events-none" />}
                      </div>
                      <span className="bg-black/95 text-[8px] text-brand-red-light font-mono px-1 rounded-none border border-brand-red/10 whitespace-nowrap leading-tight">
                        {enemyFighter.energySymbol} RIVAL
                      </span>
                    </motion.div>
                  </div>

                  {/* Fixed status line directly on stage */}
                  <div className="absolute bottom-1.5 inset-x-3 bg-black/85 border border-brand-purple/15 px-2 py-1 text-[8.5px] font-mono text-zinc-300 text-center rounded">
                    {battleNarratorMessage}
                  </div>
                </div>

                {/* AUTOMATIC COMBAT COMMAND CARD */}
                <div className="bg-zinc-950 border border-brand-purple/10 p-3 rounded-xl space-y-2.5 flex-1 flex flex-col min-h-0 justify-between">
                  
                  {/* Step Banner */}
                  <div className="flex justify-between items-center pb-1.5 border-b border-white/[0.04] flex-shrink-0">
                    <div className="flex gap-1.5">
                      <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded uppercase font-bold ${battleStep === 'choose-attack' ? 'bg-brand-purple text-white' : 'bg-zinc-900 text-zinc-500'}`}>
                        1. Attack Choice
                      </span>
                      <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded uppercase font-bold ${battleStep === 'choose-intensity' ? 'bg-brand-purple text-white' : 'bg-zinc-900 text-zinc-500'}`}>
                        2. Impact
                      </span>
                    </div>

                    {battleStep !== 'choose-attack' && (
                      <button 
                        onClick={() => {
                          setSelectedAttack(null);
                          setBattleStep('choose-attack');
                          setBattleNarratorMessage("Deck configuration reset. Select your next attack move!");
                        }}
                        className="text-[8px] font-mono text-zinc-500 hover:text-white uppercase transition-colors"
                      >
                        Reset deck
                      </button>
                    )}
                  </div>

                  {/* STEP 1: CHOOSE ATTACK DECK (Scrolls inside itself if needed, never scrolls the screen!) */}
                  {battleStep === 'choose-attack' && (
                    <div className="flex-1 flex flex-col min-h-0 space-y-2">
                      <span className="text-[8px] font-display font-black text-zinc-500 tracking-wider uppercase italic flex-shrink-0">
                        SELECT FIGHTER ATTACK COMMAND:
                      </span>
                      
                      <div className="flex-1 overflow-y-auto no-scrollbar pr-1 space-y-1">
                        {playerFighter.attacks.map((atk, index) => (
                          <button
                            key={index}
                            onClick={() => chooseAttackStep(atk)}
                            disabled={isPlayerAttacking || isEnemyAttacking}
                            className="w-full text-left bg-[#07050f]/60 hover:bg-[#0c071a]/70 border border-brand-purple/10 hover:border-brand-purple/30 p-1.5 rounded-lg flex items-center justify-between transition-all cursor-pointer group"
                          >
                            <div className="space-y-0.5">
                              <div className="text-[10px] font-display font-black text-white group-hover:text-brand-purple-light transition-colors uppercase italic flex items-center gap-1 leading-none">
                                <Swords className="w-2.5 h-2.5 text-brand-purple" /> {atk.name}
                              </div>
                              <p className="text-[8.5px] text-zinc-500 leading-none">{atk.description}</p>
                            </div>
                            <div className="text-[8.5px] font-mono font-bold text-brand-purple-light bg-brand-purple/10 px-1.5 py-0.5 rounded">
                              {atk.baseDmg} DMG
                            </div>
                          </button>
                        ))}
                      </div>

                      {/* CUSTOM ATTACK INPUT COMPONENT */}
                      <div className="space-y-1.5 flex-shrink-0">
                        <div className="flex gap-2 p-1.5 border border-brand-purple/15 rounded-lg bg-zinc-900/40">
                          <input 
                            type="text"
                            placeholder="Type Custom Attack Name (e.g. Kamehameha)"
                            value={customAttackText}
                            onChange={(e) => {
                              setCustomAttackText(e.target.value);
                              setCustomAttackError(null);
                            }}
                            className="flex-1 bg-black text-[10px] text-white border border-white/5 rounded px-2 py-1 focus:outline-none focus:border-brand-purple/40 placeholder-zinc-600 font-sans"
                          />
                          <button
                            onClick={handleLoadCustomAttack}
                            disabled={!customAttackText.trim() || isPlayerAttacking || isEnemyAttacking}
                            className="bg-brand-purple hover:bg-brand-purple-light disabled:opacity-50 text-white text-[9px] font-black px-3 py-1 rounded cursor-pointer uppercase tracking-wider transition-all"
                          >
                            LOAD
                          </button>
                        </div>
                        {customAttackError && (
                          <div className="text-left px-1 animate-shake">
                            <span className="text-[9.5px] text-brand-red font-black uppercase tracking-wider flex items-center gap-1">
                              ⚠️ {customAttackError}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* STEP 2: SELECT INTENSITY AND ENGAGE IMMEDIATELY */}
                  {battleStep === 'choose-intensity' && selectedAttack && (
                    <div className="flex-1 flex flex-col justify-center space-y-2">
                      <div className="flex justify-between items-center flex-shrink-0">
                        <span className="text-[8px] font-display font-black text-zinc-500 tracking-wider uppercase italic">
                          SELECT IMPACT INTENSITY (STRIKES IMMEDIATELY):
                        </span>
                        <span className="text-[9px] font-display font-black text-brand-purple uppercase italic">
                          LOADED: {selectedAttack.name}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 gap-1.5">
                        {INTENSITY_OPTIONS.map((opt, index) => (
                          <button
                            key={index}
                            onClick={() => chooseIntensityAndEngage(opt)}
                            disabled={isPlayerAttacking || isEnemyAttacking}
                            className={`w-full text-left border p-2 rounded-lg cursor-pointer transition-all flex justify-between items-center group ${opt.color} ${opt.hoverColor}`}
                          >
                            <div className="space-y-0.5">
                              <span className="text-[10px] font-display font-black uppercase tracking-wider italic flex items-center gap-1">
                                <Flame className="w-3 h-3" /> {opt.name}
                              </span>
                              <p className="text-[9px] text-zinc-400 leading-tight">{opt.description}</p>
                            </div>
                            <div className="text-right font-mono font-bold leading-tight">
                              <span className="text-[10px] block">x{opt.mult} DMG</span>
                              <span className="text-[8px] opacity-70 block">{opt.accuracy}% HIT</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

              </div>
            )}

            {/* DUEL COMPLETED END BANNER */}
            {gameState === 'ended' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-[#07040f] border border-brand-purple/20 p-4 rounded-xl text-center space-y-4 my-auto shadow-2xl flex-shrink-0"
              >
                <div className="flex justify-center">
                  {winner === 'player' ? (
                    <div className="relative">
                      <div className="absolute inset-0 bg-yellow-500/20 rounded-full blur-xl animate-ping" />
                      <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center text-zinc-950 shadow-[0_0_20px_rgba(234,179,8,0.5)]">
                        <Trophy className="w-6 h-6 fill-zinc-950/20" />
                      </div>
                    </div>
                  ) : (
                    <div className="w-12 h-12 bg-zinc-900 rounded-full flex items-center justify-center text-brand-red border border-zinc-800">
                      <ShieldAlert className="w-6 h-6 animate-bounce" />
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-sm font-display font-black italic tracking-tight uppercase leading-none">
                    {winner === 'player' ? (
                      <span className="text-yellow-400 glow-text-yellow">SUPREME CHAMPION!</span>
                    ) : (
                      <span className="text-brand-red">FIGHTER DEFEATED</span>
                    )}
                  </h3>
                  <p className="text-[10.5px] text-zinc-300 leading-relaxed px-2 font-sans">
                    {winner === 'player' 
                      ? "Your customized combat sync completely overwhelmed the rival!"
                      : "The opponent's defense held. Upgrade your skills by checking latest videos!"
                    }
                  </p>
                </div>

                <button
                  onClick={restartGame}
                  className="w-full flex items-center justify-center gap-1.5 bg-brand-purple hover:bg-brand-purple-light text-white font-display font-black text-[10px] tracking-widest py-3 px-4 rounded-lg border border-brand-purple/30 uppercase cursor-pointer transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>PLAY ANOTHER MATCHUP</span>
                </button>
              </motion.div>
            )}

          </div>
        )}

        {/* ----------------- GAME MODE 2: ANIME QUIZ ----------------- */}
        {activeGameMode === 'quiz' && (
          <div className="flex-1 flex flex-col min-h-0 space-y-3 justify-center">
            
            {/* Scoreboard banner and 8.99B Procedural engine indicator */}
            <div className="bg-[#0c071a]/40 border border-brand-purple/10 rounded-xl p-2.5 flex flex-col gap-1.5 flex-shrink-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-display font-black text-white tracking-wider flex items-center gap-1 uppercase">
                  <Sparkle className="w-3.5 h-3.5 text-brand-purple fill-brand-purple/30" /> Quiz score: <strong className="text-brand-purple ml-0.5">{quizScore} PTS</strong>
                </span>
                <button 
                  onClick={restartQuiz}
                  className="text-[8px] font-mono text-zinc-500 hover:text-white uppercase transition-colors"
                >
                  Reset score
                </button>
              </div>
              <div className="flex items-center justify-between border-t border-brand-purple/5 pt-1.5 text-[7.5px] font-mono text-zinc-400 uppercase tracking-wide">
                <span className="flex items-center gap-1">
                  <Zap className="w-2.5 h-2.5 text-amber-500 animate-pulse" /> 
                  TRIVIA ENGINE: <span className="text-brand-purple font-bold">PROCEDURAL GEN V4.2</span>
                </span>
                <span>
                  CAPACITY: <strong className="text-white">8,997,392,019 QUESTIONS</strong>
                </span>
              </div>
            </div>

            {/* Quiz Core Card */}
            <div className="bg-zinc-950 border border-brand-purple/10 p-4 rounded-xl flex-1 flex flex-col min-h-0 justify-between">
              
              <div className="space-y-2.5 min-h-0 overflow-y-auto no-scrollbar">
                {/* Question index indicator */}
                {(() => {
                  const currentQuestion = activeQuestions[currentQuizIdx] || ALL_QUIZ_QUESTIONS[0];
                  return (
                    <>
                      <div className="flex justify-between items-center text-[8.5px] font-mono text-zinc-500 uppercase tracking-widest flex-shrink-0">
                        <span>QUIZ QUESTION {currentQuizIdx + 1} OF {activeQuestions.length}</span>
                        <span className="text-brand-purple">TRIVIA CLASS</span>
                      </div>

                      {/* Question Text */}
                      <h3 className="text-xs font-display font-black tracking-wide text-zinc-100 uppercase italic leading-snug">
                        \"{currentQuestion.question}\"
                      </h3>

                      {/* Question Options */}
                      <div className="grid grid-cols-1 gap-2 pt-1">
                        {currentQuestion.options.map((opt, oIdx) => {
                          const isSelected = selectedQuizAnswerIdx === oIdx;
                          const isCorrect = oIdx === currentQuestion.correctIdx;
                          
                          let buttonStyle = "bg-zinc-900/60 border-white/5 hover:border-brand-purple/30 text-zinc-300";
                          if (selectedQuizAnswerIdx !== null) {
                            if (isCorrect) {
                              buttonStyle = "bg-emerald-500/10 border-emerald-500 text-emerald-400 font-bold";
                            } else if (isSelected) {
                              buttonStyle = "bg-brand-red/10 border-brand-red text-brand-red font-bold";
                            } else {
                              buttonStyle = "bg-zinc-950 opacity-40 border-white/5 text-zinc-600";
                            }
                          }

                          return (
                            <button
                              key={oIdx}
                              onClick={() => handleQuizAnswerSubmit(oIdx)}
                              disabled={selectedQuizAnswerIdx !== null}
                              className={`w-full text-left border p-2.5 text-[10.5px] rounded-lg transition-all flex items-center justify-between cursor-pointer ${buttonStyle}`}
                            >
                              <span>{opt}</span>
                              {selectedQuizAnswerIdx !== null && isCorrect && <span className="text-[8px] bg-emerald-500 text-white font-mono px-1.5 py-0.2 rounded font-bold">CORRECT</span>}
                              {selectedQuizAnswerIdx !== null && isSelected && !isCorrect && <span className="text-[8px] bg-brand-red text-white font-mono px-1.5 py-0.2 rounded font-bold">WRONG</span>}
                            </button>
                          );
                        })}
                      </div>
                    </>
                  );
                })()}
              </div>

              {/* Feedback Explanation popup */}
              <AnimatePresence>
                {showQuizExplanation && (() => {
                  const currentQuestion = activeQuestions[currentQuizIdx] || ALL_QUIZ_QUESTIONS[0];
                  return (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-3.5 bg-[#0c071a]/80 border border-brand-purple/15 rounded-lg p-2.5 text-left flex-shrink-0"
                    >
                      <p className="text-[10px] text-zinc-300 font-sans leading-relaxed">
                        💡 <strong className="text-brand-purple-light font-bold">Fyi:</strong> {currentQuestion.explanation}
                      </p>
                      
                      <button
                        onClick={handleNextQuizQuestion}
                        className="w-full mt-2.5 bg-brand-purple hover:bg-brand-purple-light text-white font-display font-black text-[9px] py-1.5 px-3 rounded uppercase tracking-wider text-center cursor-pointer transition-colors"
                      >
                        CONTINUE TO NEXT QUESTION →
                      </button>
                    </motion.div>
                  );
                })()}
              </AnimatePresence>

            </div>

          </div>
        )}

        </div>

        {/* Premium strict subscribe overlay */}
        {!hasSubscribed && (
          <AnimatePresence>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col justify-center items-center z-50 p-6 bg-radial from-[#0e0722] via-[#030109] to-black backdrop-blur-md"
            >
              {/* Cinematic light beams or glows in the background */}
              <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 bg-brand-purple/10 rounded-full blur-[80px] pointer-events-none animate-pulse" />
              <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-48 h-48 bg-purple-900/10 rounded-full blur-[60px] pointer-events-none" />

              <motion.div 
                initial={{ scale: 0.92, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.92, opacity: 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 20 }}
                className="relative flex flex-col items-center w-full max-w-sm text-center p-8 rounded-3xl bg-[#0c071a]/95 border-2 border-brand-purple/30 shadow-[0_0_80px_rgba(168,85,247,0.35)] overflow-hidden"
              >
                {/* Tech corner decors for cinematic anime look */}
                <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-brand-purple" />
                <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-brand-purple" />
                <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-brand-purple" />
                <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-brand-purple" />

                {/* Subtitle / Header tag */}
                <span className="text-[9px] font-display font-black tracking-[0.25em] text-brand-purple uppercase bg-brand-purple/10 border border-brand-purple/20 px-3 py-1 rounded-full mb-6 animate-pulse">
                  PREMIUM PORTAL GATED
                </span>

                {!isVerifyingSubscription ? (
                  <>
                    {/* Lock state view */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 bg-brand-purple/25 rounded-full blur-xl animate-pulse" />
                      <div className="w-20 h-20 bg-zinc-950 border-2 border-brand-purple/50 rounded-2xl flex items-center justify-center text-brand-purple shadow-[0_0_35px_rgba(168,85,247,0.6)] relative z-10 transform hover:scale-105 transition-transform duration-300">
                        <Lock className="w-10 h-10 animate-bounce text-brand-purple" />
                      </div>
                    </div>

                    <div className="space-y-3 mb-8">
                      <h2 className="font-display text-xl font-black text-white uppercase tracking-tight leading-tight glow-text-purple">
                        Aaravo Editz
                      </h2>
                      <p className="font-display text-[12px] font-bold text-zinc-300 max-w-[280px] mx-auto uppercase tracking-wide leading-relaxed">
                        Only Aaravo Editz Subscribers Can Enter Battle Arena
                      </p>
                    </div>

                    <div className="w-full space-y-4">
                      <button
                        id="btn-subscribe-now"
                        onClick={handleSubscribeToEnter}
                        className="w-full relative flex items-center justify-center gap-3 bg-brand-purple hover:bg-brand-purple-light text-white font-display font-black text-[12px] tracking-widest py-4 px-6 rounded-xl border border-brand-purple/50 shadow-[0_0_20px_rgba(168,85,247,0.5)] cursor-pointer text-center group transition-all duration-300 hover:scale-[1.03]"
                      >
                        <Youtube className="w-5 h-5 text-red-500 fill-red-500 group-hover:scale-110 transition-transform" />
                        <span className="uppercase font-black tracking-wider">Subscribe Now</span>
                      </button>

                      <p className="text-[9px] text-zinc-500 font-medium italic">
                        Battle arena will unlock automatically 15 seconds after clicking.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Verification counting state view */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 bg-brand-purple/30 rounded-full blur-2xl animate-pulse" />
                      
                      {/* Spinning verification ring */}
                      <div className="w-24 h-24 rounded-full border-4 border-zinc-900 border-t-brand-purple flex items-center justify-center relative z-10 animate-spin" />
                      
                      {/* Floating numbers / lock in center */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
                        <span className="font-display text-2xl font-black text-white tracking-tighter">
                          {subscribeCountdown}s
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3 mb-8">
                      <h3 className="font-display text-base font-black text-white uppercase tracking-wider animate-pulse flex items-center justify-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin text-brand-purple" />
                        Verifying Subscription…
                      </h3>
                      <p className="font-display text-[10px] font-black text-brand-purple tracking-widest uppercase bg-brand-purple/10 px-3 py-1 rounded-md inline-block">
                        {subscribeCountdown} seconds remaining
                      </p>
                      <p className="text-[11px] text-zinc-400 max-w-[260px] mx-auto font-medium">
                        Please subscribe to the channel while the countdown finishes. Do not close this app!
                      </p>
                    </div>

                    <div className="w-full bg-[#07040f] border border-brand-purple/20 rounded-xl p-3.5 space-y-2">
                      <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: "0%" }}
                          animate={{ width: `${((15 - subscribeCountdown) / 15) * 100}%` }}
                          transition={{ duration: 0.5, ease: "linear" }}
                          className="h-full bg-brand-purple shadow-[0_0_10px_rgba(168,85,247,0.8)]"
                        />
                      </div>
                      <div className="flex justify-between items-center text-[8px] font-mono text-zinc-500">
                        <span>ESTABLISHING CONNECTION</span>
                        <span className="animate-pulse">VERIFYING STATUS...</span>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>
            </motion.div>
          </AnimatePresence>
        )}

      </div>

    </div>
  );
}
