import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Bell, 
  Trash2, 
  ExternalLink, 
  Play, 
  Sparkles, 
  Megaphone,
  Check
} from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
}

export default function NotificationCenter({
  isOpen,
  onClose,
  notifications,
  setNotifications,
}: NotificationCenterProps) {

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const handleNotificationClick = (id: string, link: string) => {
    // Mark as read and save to dismissed to prevent repeating
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    
    const plainId = id.replace('upload-', '');
    const dismissedNotifs = JSON.parse(localStorage.getItem('aaravo_dismissed_notifications') || '[]');
    if (!dismissedNotifs.includes(plainId)) {
      dismissedNotifs.push(plainId);
      localStorage.setItem('aaravo_dismissed_notifications', JSON.stringify(dismissedNotifs));
    }
    
    window.open(link, '_blank');
  };

  const clearNotifications = () => {
    // Save all current notification IDs to dismissed storage
    const dismissedNotifs = JSON.parse(localStorage.getItem('aaravo_dismissed_notifications') || '[]');
    notifications.forEach(n => {
      const plainId = n.id.replace('upload-', '');
      if (!dismissedNotifs.includes(plainId)) {
        dismissedNotifs.push(plainId);
      }
    });
    localStorage.setItem('aaravo_dismissed_notifications', JSON.stringify(dismissedNotifs));
    setNotifications([]);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop (Inside the phone container) */}
          <motion.div
            id="notification-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 z-50 backdrop-blur-xs cursor-pointer rounded-[42px]"
          />

          {/* Drawer container (Slide-in from right/top inside bezel) */}
          <motion.div
            id="notification-drawer"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="absolute right-0 top-[44px] bottom-0 w-[300px] bg-[#07040f] border-l border-brand-purple/10 z-50 flex flex-col shadow-2xl rounded-r-[42px] overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-brand-purple/10 bg-[#07040f]/80 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-brand-purple animate-pulse" />
                  <h3 className="text-xs font-display font-black italic tracking-widest uppercase text-white">
                    ALERT CENTER
                  </h3>
                </div>
                <button
                  id="btn-close-notifications"
                  onClick={onClose}
                  className="p-1 rounded-full hover:bg-white/5 text-zinc-400 hover:text-white cursor-pointer transition-all active:scale-95"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Actions subheader */}
            {notifications.length > 0 && (
              <div className="px-4 py-2 border-b border-brand-purple/10 bg-white/5 flex justify-between items-center text-[10px]">
                <button
                  id="btn-mark-all-read"
                  onClick={markAllAsRead}
                  className="text-zinc-400 hover:text-white font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5 text-brand-purple" /> Mark all read
                </button>
                <button
                  id="btn-clear-notifications"
                  onClick={clearNotifications}
                  className="text-zinc-500 hover:text-brand-red font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear all
                </button>
              </div>
            )}

            {/* Notification feed list */}
            <div className="flex-1 overflow-y-auto no-scrollbar p-3 space-y-2">
              {notifications.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-2">
                  <div className="p-3 bg-white/5 rounded-full border border-white/5 text-zinc-600">
                    <Bell className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-zinc-400">All Quiet Here</h4>
                    <p className="text-[10px] text-zinc-500 leading-normal px-4 font-sans">
                      You are up to date! Toggle notifications in home settings to ensure you receive new upload flashes.
                    </p>
                  </div>
                </div>
              ) : (
                notifications.map((notif) => {
                  let Icon = Bell;
                  let iconColor = 'text-brand-purple bg-brand-purple/10 border-brand-purple/20';
                  
                  if (notif.type === 'upload') {
                    Icon = Play;
                    iconColor = 'text-brand-purple bg-brand-purple/15 border-brand-purple/20';
                  } else if (notif.type === 'template') {
                    Icon = Sparkles;
                    iconColor = 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
                  } else if (notif.type === 'announcement') {
                    Icon = Megaphone;
                    iconColor = 'text-blue-500 bg-blue-500/10 border-blue-500/20';
                  }

                  return (
                    <div
                      id={`notification-item-${notif.id}`}
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif.id, notif.link)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex gap-3 relative ${
                        notif.isRead 
                          ? 'bg-[#05030a] border-white/5 text-zinc-400 hover:border-white/10' 
                          : 'bg-brand-purple/5 border-brand-purple/20 hover:border-brand-purple/35 text-white shadow-ae-logo'
                      }`}
                    >
                      {/* Unread blue/red indicator dot */}
                      {!notif.isRead && (
                        <span className="absolute top-3.5 right-3 w-1.5 h-1.5 bg-brand-red rounded-full animate-pulse" />
                      )}

                      {/* Icon */}
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border flex-shrink-0 ${iconColor}`}>
                        <Icon className="w-4 h-4" />
                      </div>

                      {/* Content details */}
                      <div className="flex-1 space-y-1">
                        <p className="text-[10.5px] leading-relaxed font-semibold">
                          {notif.title}
                        </p>
                        <span className="text-[9px] text-zinc-500 font-mono block">
                          {notif.time}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Settings bottom footer */}
            <div className="p-4 bg-[#0a0a0a] border-t border-white/5 text-center">
              <span className="text-[9px] text-zinc-500 uppercase tracking-widest font-mono">
                Aaravo Push Protocol v1.0
              </span>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
