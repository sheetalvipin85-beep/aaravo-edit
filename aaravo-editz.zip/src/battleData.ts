export interface Attack {
  name: string;
  baseDmg: number;
  description: string;
}

export interface Fighter {
  id: string;
  name: string;
  title: string;
  color: string;
  borderColor: string;
  accentColor: string;
  avatar: string;
  energySymbol: string;
  attacks: Attack[];
}

export interface DuelMatchup {
  id: string;
  name: string;
  fighterAId: string;
  fighterBId: string;
}

export const FIGHTERS: Record<string, Fighter> = {
  goku: {
    id: 'goku',
    name: 'GOKU (CHIBI)',
    title: 'Universe Legend Warrior',
    color: 'from-orange-600 to-amber-500',
    borderColor: 'border-orange-500',
    accentColor: '#f97316',
    avatar: 'https://cdn.myanimelist.net/images/characters/9/496058.jpg',
    energySymbol: '⚡',
    attacks: [
      { name: 'Punch Barrage', baseDmg: 12, description: 'Rapid physical fist strikes.' },
      { name: 'Kick Combo', baseDmg: 15, description: 'High-speed kinetic leg sweep.' },
      { name: 'Energy Blast', baseDmg: 18, description: 'Chakra-infused visual energy bolts.' },
      { name: 'Teleport Strike', baseDmg: 22, description: 'Instant translocation blindside blow.' },
      { name: 'Spirit Bomb', baseDmg: 28, description: 'Accumulates celestial planetary force.' },
      { name: 'Kamehameha', baseDmg: 35, description: 'Signature supreme spatial beam surge.' },
      { name: 'Ultra Strike', baseDmg: 48, description: 'Subconscious supreme celestial visual hit.' },
      { name: 'Kaioken Rush', baseDmg: 16, description: 'Intense physical onslaught under multiplier.' },
      { name: 'Super Saiyan Aura', baseDmg: 20, description: 'Golden flame defensive and offensive shockwave.' },
      { name: 'Dragon Fist Surge', baseDmg: 32, description: 'Summons golden energy dragon pierce.' },
      { name: 'Godly Energy Wave', baseDmg: 42, description: 'Fires high-contrast divine beam from sky.' },
      { name: 'Hakai Erasure', baseDmg: 55, description: 'Celestial erasure energy wave deletes matter.' }
    ]
  },
  vegeta: {
    id: 'vegeta',
    name: 'VEGETA (CHIBI)',
    title: 'Prince of All Saiyans',
    color: 'from-blue-600 to-indigo-950',
    borderColor: 'border-blue-500',
    accentColor: '#2563eb',
    avatar: 'https://cdn.myanimelist.net/images/characters/15/285437.jpg',
    energySymbol: '👑',
    attacks: [
      { name: 'Saiyan Fist', baseDmg: 12, description: 'A continuous sequence of high-power jabs.' },
      { name: 'Dirty Fireworks', baseDmg: 16, description: 'Detonates energy directly underneath the opponent.' },
      { name: 'Double Galick Cannon', baseDmg: 19, description: 'Two-handed violet energy blast.' },
      { name: 'Final Impact', baseDmg: 22, description: 'A piercing lightning-fast strike at close range.' },
      { name: 'Galick Gun', baseDmg: 28, description: 'Fires a signature purple energy wave.' },
      { name: 'Big Bang Attack', baseDmg: 35, description: 'A massive spherical spark discharge.' },
      { name: 'Final Flash', baseDmg: 48, description: 'Colossal golden beam that can disintegrate planets.' },
      { name: 'Super Saiyan Blue', baseDmg: 15, description: 'Powers up to Blue form, blasting aura shockwaves.' },
      { name: 'Final Shine Attack', baseDmg: 25, description: 'Concentrated green energy beam from one hand.' },
      { name: 'Spirit Sword Slash', baseDmg: 32, description: 'Manifests a golden spirit blade to slash.' },
      { name: 'Royal Blue Strike', baseDmg: 42, description: 'Surges with Limit Breaker aura for an explosive smash.' },
      { name: 'Final Explosion', baseDmg: 55, description: 'Releases all life force in a massive golden explosion.' }
    ]
  },
  saitama: {
    id: 'saitama',
    name: 'SAITAMA (CHIBI)',
    title: 'One-Punch Cape',
    color: 'from-yellow-500 to-red-600',
    borderColor: 'border-yellow-500',
    accentColor: '#eab308',
    avatar: 'https://cdn.myanimelist.net/images/characters/11/294314.jpg',
    energySymbol: '👊',
    attacks: [
      { name: 'Normal Jab', baseDmg: 12, description: 'A casual left jab with surprising pop.' },
      { name: 'Consecutive Jabs', baseDmg: 16, description: 'A fast flurry of medium-weight swings.' },
      { name: 'Serious Side Hops', baseDmg: 20, description: 'Disorients opponent with visual shadow clones.' },
      { name: 'Serious Table Flip', baseDmg: 25, description: 'Launches entire arena surface upward.' },
      { name: 'Serious Headbutt', baseDmg: 30, description: 'Devastating concrete-shattering block.' },
      { name: 'Serious Punch', baseDmg: 38, description: 'Atmospheric visual wind shockwave blow.' },
      { name: 'Death Core Strike', baseDmg: 48, description: 'Cataclysmic close-quarters physical touch.' },
      { name: 'Normal Karate Chop', baseDmg: 14, description: 'A relaxed chopping blow targeting neck.' },
      { name: 'Serious Water Stream', baseDmg: 22, description: 'Mimics defensive kinetic flowing water.' },
      { name: 'Casual Backhand', baseDmg: 18, description: 'Uninterested flick sending target flying.' },
      { name: 'Omni-Directional Punch', baseDmg: 45, description: 'Surrounds foe with infinite fist images.' },
      { name: 'Maximum Serious Impact', baseDmg: 58, description: 'Splits clouds globally with raw punch kinetic force.' }
    ]
  },
  luffy: {
    id: 'luffy',
    name: 'LUFFY (CHIBI)',
    title: 'Elastic Pirate Emperor',
    color: 'from-rose-600 to-red-500',
    borderColor: 'border-red-500',
    accentColor: '#f43f5e',
    avatar: 'https://cdn.myanimelist.net/images/characters/9/310307.jpg',
    energySymbol: '🍖',
    attacks: [
      { name: 'Gum-Gum Pistol', baseDmg: 12, description: 'Elastic straight punch thrown from distance.' },
      { name: 'Gum-Gum Gatling', baseDmg: 16, description: 'Dozens of fast-stretching elastic impacts.' },
      { name: 'Gum-Gum Rocket', baseDmg: 19, description: 'Launches whole body directly into target.' },
      { name: 'Red Hawk Flare', baseDmg: 23, description: 'Flaming kinetic punch wrapped in willpower.' },
      { name: 'Giant Fist Crush', baseDmg: 28, description: 'Inflates limb to colossal crushing size.' },
      { name: 'Bajrang Force', baseDmg: 35, description: 'An island-sized fist cloaked in visual aura.' },
      { name: 'Gear 5 Laugh Strike', baseDmg: 48, description: 'Bounces on rubber space to strike hilariously.' },
      { name: 'Gum-Gum Bazooka', baseDmg: 15, description: 'Double elastic palm strike sending target back.' },
      { name: 'Gum-Gum Spear', baseDmg: 18, description: 'Stretches feet down for piercing stomp.' },
      { name: 'Snake Man Jet Culverin', baseDmg: 25, description: 'Stretching arm accelerates dynamically at angles.' },
      { name: 'Kong Gun Blast', baseDmg: 32, description: 'Compressed spring arm punches with intense pressure.' },
      { name: 'Giant Rubber Stamp', baseDmg: 42, description: 'Gigantic foot stamps down from upper sky.' }
    ]
  },
  zoro: {
    id: 'zoro',
    name: 'ZORO (CHIBI)',
    title: 'Three-Sword Style Master',
    color: 'from-emerald-700 to-zinc-900',
    borderColor: 'border-emerald-600',
    accentColor: '#10b981',
    avatar: 'https://cdn.myanimelist.net/images/characters/11/310310.jpg',
    energySymbol: '⚔️',
    attacks: [
      { name: 'Oni Giri', baseDmg: 12, description: 'A high-speed cross slash with three swords.' },
      { name: 'Tiger Trap', baseDmg: 15, description: 'A heavy downward strike that mimics tiger claws.' },
      { name: 'Leopard Spin', baseDmg: 18, description: 'A forward spinning slash that shreds defenses.' },
      { name: 'Dragon Twister', baseDmg: 22, description: 'A spinning wind hurricane slash.' },
      { name: 'Death Lion Song', baseDmg: 28, description: 'A clean drawing strike of extreme precision.' },
      { name: 'Three Thousand Worlds', baseDmg: 35, description: 'Zoro spins his swords rapidly, creating a sphere of slashes.' },
      { name: 'Ashura Silver Mist', baseDmg: 48, description: 'Manifests nine swords to deliver a devastating mist-like cut.' },
      { name: 'Purgatory Onigiri', baseDmg: 14, description: 'An ultra-powerful version of his signature cross cut.' },
      { name: 'Billion-Fold World Trichiliocosm', baseDmg: 32, description: 'Cuts massive stone obstacles with unmatched haki.' },
      { name: 'Caliber Phoenix', baseDmg: 24, description: 'Fires flying vacuum-slash projectile waves.' },
      { name: 'Black Rope Dragon', baseDmg: 42, description: 'Creates a massive black twister that sweeps the screen.' },
      { name: 'King of Hell Strike', baseDmg: 54, description: 'Coats swords in green conqueror Conquerors Haki for a fatal slash.' }
    ]
  },
  gojo: {
    id: 'gojo',
    name: 'GOJO (CHIBI)',
    title: 'Six-Eyes Honored Mentor',
    color: 'from-cyan-500 to-blue-700',
    borderColor: 'border-cyan-500',
    accentColor: '#06b6d4',
    avatar: 'https://cdn.myanimelist.net/images/characters/11/424350.jpg',
    energySymbol: '👁',
    attacks: [
      { name: 'Spatial Jab', baseDmg: 12, description: 'Swift distortion-assisted close blow.' },
      { name: 'Blue Attractor', baseDmg: 16, description: 'Gravity pull that drags opponent into collision.' },
      { name: 'Red Repulsion', baseDmg: 20, description: 'High-velocity reverse compression shockwave.' },
      { name: 'Spatial Warp Kick', baseDmg: 24, description: 'Instantly teleports above for an axe kick.' },
      { name: 'Purple Void Core', baseDmg: 30, description: 'Fuses motion and void to erase obstacle matter.' },
      { name: 'Hollow Purple Max', baseDmg: 38, description: 'Colossal visual bubble erases spatial plane.' },
      { name: 'Infinite Void Flash', baseDmg: 48, description: 'Paralyzes nervous system with infinite frames.' },
      { name: 'Infinity Shield Ramp', baseDmg: 14, description: 'Bends space to reflect incoming force.' },
      { name: 'Six Eyes Precision Strike', baseDmg: 18, description: 'Weakpoint targeted chakra knuckle tap.' },
      { name: 'Blue Spark Blitz', baseDmg: 22, description: 'Lightning-fast gravity leaps combined with fists.' },
      { name: 'Red Compression Overdrive', baseDmg: 28, description: 'Densely packed reverse energy explosion.' },
      { name: 'Domain Expansion Void', baseDmg: 52, description: 'Expands custom void trapping target in absolute data.' }
    ]
  },
  sukuna: {
    id: 'sukuna',
    name: 'SUKUNA (CHIBI)',
    title: 'Double-Face Curse King',
    color: 'from-purple-600 to-red-950',
    borderColor: 'border-purple-600',
    accentColor: '#9333ea',
    avatar: 'https://cdn.myanimelist.net/images/characters/3/430335.jpg',
    energySymbol: '💀',
    attacks: [
      { name: 'Dismantle Slash', baseDmg: 12, description: 'Fires several flying invisible cutting blades.' },
      { name: 'Cleave Slice', baseDmg: 16, description: 'Tactile skin contact cutting strike.' },
      { name: 'Spider Web Fracture', baseDmg: 19, description: 'Shatters battlefield ground under opponent.' },
      { name: 'Fire Arrow Bow', baseDmg: 23, description: 'Concentrates severe atmospheric thermal heat.' },
      { name: 'Fuga Combustion', baseDmg: 28, description: 'Furnace explosion wave leveling the stage.' },
      { name: 'Divine Box Furnace', baseDmg: 35, description: 'Incinerates surrounding vacuum completely.' },
      { name: 'Malevolent Cleave', baseDmg: 48, description: 'Millions of lethal visual slashes per second.' },
      { name: 'Shadow Blade Slices', baseDmg: 14, description: 'Quick dual cross cuts using cursed blades.' },
      { name: 'Spider Web Shockwave', baseDmg: 18, description: 'Slams ground sending shockwaves along fractures.' },
      { name: 'Finger Ingestion Surge', baseDmg: 22, description: 'Cursed aura bursts forth raising raw power.' },
      { name: 'Divine Firestorm', baseDmg: 32, description: 'Fires atmospheric solar fire arrows in rapid succession.' },
      { name: 'Malevolent Shrine Void', baseDmg: 52, description: 'Summons domain shrine to execute ultimate cuts.' }
    ]
  },
  yuji: {
    id: 'yuji',
    name: 'YUJI (CHIBI)',
    title: 'Vessel Spirit Kid',
    color: 'from-fuchsia-600 to-pink-500',
    borderColor: 'border-fuchsia-500',
    accentColor: '#d946ef',
    avatar: 'https://cdn.myanimelist.net/images/characters/12/424345.jpg',
    energySymbol: '💥',
    attacks: [
      { name: 'Claw Slash', baseDmg: 12, description: 'Fast standard animalistic slash strike.' },
      { name: 'Divergent Strike', baseDmg: 15, description: 'Double kinetic impact where energy lags.' },
      { name: 'Soul Punch', baseDmg: 18, description: 'Direct fist strike that harms target spirit.' },
      { name: 'Black Flash Strike', baseDmg: 23, description: 'Critical spark distortion multiplies force.' },
      { name: 'Black Flash Barrage', baseDmg: 29, description: 'Four consecutive black visual spark flashes.' },
      { name: 'Domain Tearing Slash', baseDmg: 35, description: 'Shatters outer barrier space to slash.' },
      { name: 'Cleave Overdrive', baseDmg: 48, description: 'Benevolent cursed domain rips enemy cells.' },
      { name: 'Kinetic Delay Strike', baseDmg: 14, description: 'Punch followed by delayed cursed energy pop.' },
      { name: 'Physical Fist Rush', baseDmg: 17, description: 'Heavy boxing combination with brute strength.' },
      { name: 'Soul Seizing Grip', baseDmg: 21, description: 'Grabs target to deal damage directly to soul.' },
      { name: 'Triple Black Flash Blitz', baseDmg: 32, description: 'Dazzling black and red lightning fist combos.' },
      { name: 'Cursed Energy Blast', baseDmg: 42, description: 'Screaming wave of pure kinetic cursed pressure.' }
    ]
  },
  megumi: {
    id: 'megumi',
    name: 'MEGUMI (CHIBI)',
    title: 'Shadow Shadow Summoner',
    color: 'from-blue-900 to-zinc-950',
    borderColor: 'border-blue-700',
    accentColor: '#3b82f6',
    avatar: 'https://cdn.myanimelist.net/images/characters/16/424346.jpg',
    energySymbol: '🐺',
    attacks: [
      { name: 'Divine Dog Bite', baseDmg: 12, description: 'Summons twin shadow hounds to tear enemy.' },
      { name: 'Nue Storm Flare', baseDmg: 15, description: 'Fires lightning feathers from electric eagle.' },
      { name: 'Toad Tongue Grab', baseDmg: 18, description: 'Shadow amphibian pulls opponent into floor.' },
      { name: 'Max Elephant Splash', baseDmg: 22, description: 'Summons colossal elephant to release torrent.' },
      { name: 'Shadow Clone Flurry', baseDmg: 28, description: 'Clones emerge from shadow floor to kick.' },
      { name: 'Mahoraga Blade Swing', baseDmg: 35, description: 'Summons hand blade of the sacred general.' },
      { name: 'Shadow Garden Burst', baseDmg: 48, description: 'Unleashes infinite shadow hands from depth.' },
      { name: 'Rabbit Escape Confusion', baseDmg: 10, description: 'Horde of paper rabbits distracts and tackles.' },
      { name: 'Serpent Binding Strike', baseDmg: 16, description: 'Colossal snake shadow traps and bites.' },
      { name: 'Elephant Torrent Flood', baseDmg: 21, description: 'Releases high-pressure water column from shadows.' },
      { name: 'Divine Dog Totality Claw', baseDmg: 32, description: 'Merged wolf shadow strikes with huge claws.' },
      { name: 'Chimera Shadow Domain', baseDmg: 45, description: 'Floods arena with deep shadow fluid and monsters.' }
    ]
  },
  nobara: {
    id: 'nobara',
    name: 'NOBARA (CHIBI)',
    title: 'Straw Doll Sorcerer',
    color: 'from-amber-700 to-stone-900',
    borderColor: 'border-amber-600',
    accentColor: '#d97706',
    avatar: 'https://cdn.myanimelist.net/images/characters/4/424347.jpg',
    energySymbol: '🔨',
    attacks: [
      { name: 'Nail Shot', baseDmg: 12, description: 'Fires cursed energy nails.' },
      { name: 'Hairpin Blast', baseDmg: 16, description: 'Causes detonating nails to explode.' },
      { name: 'Straw Doll Pierce', baseDmg: 19, description: 'Drives spike into straw doll to curse target.' },
      { name: 'Resonance Curse', baseDmg: 24, description: 'Direct soul damage linking target blood.' },
      { name: 'Black Flash Nail', baseDmg: 30, description: 'Sparking dark nail impact.' },
      { name: 'Hammer Slam', baseDmg: 36, description: 'Shatters floor with cursed sledgehammer.' },
      { name: 'Soul Resonance', baseDmg: 48, description: 'Supreme binding curse of absolute pain.' },
      { name: 'Toy Mallet Bonk', baseDmg: 14, description: 'Humorous direct bonk on head.' },
      { name: 'Nail Shower', baseDmg: 18, description: 'Launches a wave of glowing red nails.' },
      { name: 'Curse Burst', baseDmg: 22, description: 'Unleashes massive black-and-red spark aura.' },
      { name: 'Straw Clone distraction', baseDmg: 32, description: 'Swaps places with doll to avoid and strike.' },
      { name: 'Resonance Final Judgement', baseDmg: 52, description: 'Smashes giant nail to disintegrate cursed energy.' }
    ]
  },
  tanjiro: {
    id: 'tanjiro',
    name: 'TANJIRO (CHIBI)',
    title: 'Water & Sun Slayer Kid',
    color: 'from-emerald-600 to-green-700',
    borderColor: 'border-emerald-500',
    accentColor: '#10b981',
    avatar: 'https://cdn.myanimelist.net/images/characters/11/381484.jpg',
    energySymbol: '☀️',
    attacks: [
      { name: 'Water Wheel Spin', baseDmg: 12, description: 'Circular aerial sword rotating flow.' },
      { name: 'Waterfall Basin', baseDmg: 15, description: 'Heavy downward vertical cascading strike.' },
      { name: 'Fire Dance Halo', baseDmg: 18, description: 'A rapid forward flash of burning solar cuts.' },
      { name: 'Raging Sun Slash', baseDmg: 22, description: 'Two broad circular defensive flaming slashes.' },
      { name: 'Constant Flux Dragon', baseDmg: 28, description: 'Twisting water dragon charging strike.' },
      { name: 'Hinokami Strike', baseDmg: 35, description: 'Brilliant high-contrast solar fire chop.' },
      { name: 'Dragon Sun Solar', baseDmg: 48, description: 'Celestial solar dragon head visual execution.' },
      { name: 'Water Basin Cascade', baseDmg: 14, description: 'Upward water slash lifting opponent.' },
      { name: 'Piercing Rain Drop', baseDmg: 17, description: 'Rapid thrusting sword stab forward.' },
      { name: 'Fake Rainbow Flash', baseDmg: 23, description: 'Evades with solar light illusion and strikes back.' },
      { name: 'Sun Flame Wheel', baseDmg: 32, description: 'Full circular spinning slash of flame.' },
      { name: 'Tenth Form Dragon Surge', baseDmg: 44, description: 'Accumulative water dragon slash of immense power.' }
    ]
  },
  muzan: {
    id: 'muzan',
    name: 'MUZAN (CHIBI)',
    title: 'Demon Sire Chibi',
    color: 'from-zinc-800 to-red-900',
    borderColor: 'border-red-900',
    accentColor: '#b91c1c',
    avatar: 'https://cdn.myanimelist.net/images/characters/13/381489.jpg',
    energySymbol: '🩸',
    attacks: [
      { name: 'Whip Spine Blade', baseDmg: 12, description: 'Extends morphing genetic bone tendrils.' },
      { name: 'Regeneration Burst', baseDmg: 15, description: 'Sudden cellular restructuring blast.' },
      { name: 'Demon Injection Curse', baseDmg: 18, description: 'Fires high-toxicity demon blood needles.' },
      { name: 'Shockwave Scream', baseDmg: 22, description: 'Primal acoustic visual scream frequency.' },
      { name: 'Portal Void Warp', baseDmg: 28, description: 'Bends space to summon dimensional traps.' },
      { name: 'Infinity Castle Crush', baseDmg: 35, description: 'Drops sliding castle walls from above.' },
      { name: 'Demon Emperor Pulse', baseDmg: 48, description: 'Omnidirectional cellular decay pulse wave.' },
      { name: 'Bone Tendril Sweep', baseDmg: 14, description: 'Spinning spin-tendril sweep clearing space.' },
      { name: 'Blood Poison Dart', baseDmg: 17, description: 'Fast dark red darts loaded with poison.' },
      { name: 'Spatial Distortion Portals', baseDmg: 23, description: 'Pulls the enemy through violent castle voids.' },
      { name: 'Cellular Restructuring Blast', baseDmg: 32, description: 'Explosive expansion of fleshy bio-energy.' },
      { name: 'Blood Curse Obliteration', baseDmg: 45, description: 'Infects targets blood system to rupture instantly.' }
    ]
  },
  gyuu: {
    id: 'gyuu',
    name: 'GYUU (CHIBI)',
    title: 'Water Hashira Pillar',
    color: 'from-sky-700 to-slate-900',
    borderColor: 'border-sky-600',
    accentColor: '#0ea5e9',
    avatar: 'https://cdn.myanimelist.net/images/characters/10/381483.jpg',
    energySymbol: '🌊',
    attacks: [
      { name: 'Water Slash', baseDmg: 12, description: 'Swift water blade cross cut.' },
      { name: 'Water Wheel', baseDmg: 15, description: 'Spinning vertical water circle.' },
      { name: 'Flowing Dance', baseDmg: 18, description: 'Graceful twisting path strikes.' },
      { name: 'Striking Tide', baseDmg: 22, description: 'Consecutive heavy tide wave slashes.' },
      { name: 'Constant Flux', baseDmg: 28, description: 'Evolving water dragon thrust.' },
      { name: 'Dead Calm', baseDmg: 35, description: 'Eleventh form: negates and counters any hit.' },
      { name: 'Tidal Wave Crash', baseDmg: 48, description: 'Massive high-tide ocean wash.' },
      { name: 'Piercing Raindrop', baseDmg: 14, description: 'Fast single-point water thrust.' },
      { name: 'Splashing Water', baseDmg: 17, description: 'Fires water projectiles.' },
      { name: 'Waterfall Basin', baseDmg: 23, description: 'Vertical cascading water hammer.' },
      { name: 'Crimson Blade Heat', baseDmg: 32, description: 'Water blade gets hot for extra impact.' },
      { name: 'Supreme Dragon Rush', baseDmg: 52, description: 'Perfect fluid water dragon bite.' }
    ]
  },
  akaza: {
    id: 'akaza',
    name: 'AKAZA (CHIBI)',
    title: 'Upper Moon Three',
    color: 'from-pink-700 to-slate-950',
    borderColor: 'border-pink-600',
    accentColor: '#ec4899',
    avatar: 'https://cdn.myanimelist.net/images/characters/13/423180.jpg',
    energySymbol: '❄️',
    attacks: [
      { name: 'Destructive Fist', baseDmg: 12, description: 'Brutal shockwave-assisted punch.' },
      { name: 'Compass Needle', baseDmg: 16, description: 'Senses and tracks battle spirit.' },
      { name: 'Air Type Strike', baseDmg: 19, description: 'Fires physical shockwaves through the air.' },
      { name: 'Disorder Fist', baseDmg: 23, description: 'Wild erratic shockwave punch flurry.' },
      { name: 'Annihilation Type', baseDmg: 29, description: 'Ultimate dastic forward strike.' },
      { name: 'Blue Silver Flare', baseDmg: 35, description: 'Explosive ground stomp ring.' },
      { name: 'Compass Overdrive', baseDmg: 48, description: 'Absolute counter-strike zone.' },
      { name: 'Leg Type Crown', baseDmg: 14, description: 'Rising axe-kick sending shockwave.' },
      { name: 'Willow Split', baseDmg: 18, description: 'Downwards chopping punch.' },
      { name: 'Flying Planet', baseDmg: 22, description: 'Multiple spinning shockwaves.' },
      { name: 'End Style Chaotic', baseDmg: 32, description: 'Hundred chaotic shockwave punches.' },
      { name: 'Demon Core Smash', baseDmg: 52, description: 'Ground shattering absolute finality fist.' }
    ]
  },
  doma: {
    id: 'doma',
    name: 'DOMA (CHIBI)',
    title: 'Upper Moon Two',
    color: 'from-rose-800 to-indigo-950',
    borderColor: 'border-rose-700',
    accentColor: '#f43f5e',
    avatar: 'https://cdn.myanimelist.net/images/characters/4/470977.jpg',
    energySymbol: '🪭',
    attacks: [
      { name: 'Fan Slash', baseDmg: 12, description: 'Double metallic fan sweep.' },
      { name: 'Frozen Lotus', baseDmg: 15, description: 'Summons sharp ice lotus petals.' },
      { name: 'Wintry Icicles', baseDmg: 18, description: 'Drops piercing ice spears from ceiling.' },
      { name: 'Barren Hanging Garden', baseDmg: 22, description: 'Rapid circular fan shield and slashes.' },
      { name: 'Freezing Cloud', baseDmg: 28, description: 'Lethal ice mist that damages lungs.' },
      { name: 'Ice Child Summon', baseDmg: 35, description: 'Summons ice dolls to repeat his moves.' },
      { name: 'Rime Water Lily', baseDmg: 48, description: 'Colossal giant ice statue crush.' },
      { name: 'Cold Frost Wind', baseDmg: 14, description: 'Blasts icy wind from fans.' },
      { name: 'Ice Spear Barrage', baseDmg: 17, description: 'Launches frozen daggers.' },
      { name: 'Crystalline Shield', baseDmg: 23, description: 'Blocks and reflects with pure ice.' },
      { name: 'Lotus Frostbite', baseDmg: 32, description: 'Explosion of frost ice roots.' },
      { name: 'Bodhisattva Absolute', baseDmg: 52, description: 'Massive final divine ice figure blast.' }
    ]
  },
  kokushibo: {
    id: 'kokushibo',
    name: 'KOKUSHIBO (CHIBI)',
    title: 'Upper Moon One',
    color: 'from-purple-900 to-neutral-950',
    borderColor: 'border-purple-700',
    accentColor: '#8b5cf6',
    avatar: 'https://cdn.myanimelist.net/images/characters/7/496739.jpg',
    energySymbol: '🌙',
    attacks: [
      { name: 'Dark Moon Slice', baseDmg: 12, description: 'A rapid slash releasing tiny glowing crescent blades.' },
      { name: 'Evening Palace', baseDmg: 16, description: 'A horizontal sweep of dark lunar energy.' },
      { name: 'Moon-Dragon Ring', baseDmg: 19, description: 'Giant circular wind slices shaped like a crescent moon.' },
      { name: 'Cataclysmic Mirror', baseDmg: 22, description: 'Releases a dome of moon blade shockwaves.' },
      { name: 'Loathsome Moon', baseDmg: 28, description: 'Multi-directional curved blade sweeps.' },
      { name: 'Crescent Moon Vortex', baseDmg: 35, description: 'Spins his extended sword, summoning crescent storms.' },
      { name: 'Lunar Solitary Strike', baseDmg: 48, description: 'A single, supreme sword drop cutting the entire screen.' },
      { name: 'Moonlit Blade Flash', baseDmg: 14, description: 'Quick continuous horizontal sword slashes.' },
      { name: 'Six-Eyed Piercing Vision', baseDmg: 18, description: 'Uncannily predicts and avoids attacks, then counters.' },
      { name: 'Breath of the Moon', baseDmg: 24, description: 'Dark purple sword pulse wave pushing the target.' },
      { name: 'Shadow Crescent', baseDmg: 32, description: 'Extends flesh sword with multiple small branching blades.' },
      { name: 'Astral Moon Cataclysm', baseDmg: 53, description: 'The absolute final 16th form of Moon Breathing.' }
    ]
  },
  gyomei: {
    id: 'gyomei',
    name: 'GYOMEI (CHIBI)',
    title: 'Stone Hashira Pillar',
    color: 'from-yellow-700 to-stone-900',
    borderColor: 'border-yellow-600',
    accentColor: '#eab308',
    avatar: 'https://cdn.myanimelist.net/images/characters/16/382029.jpg',
    energySymbol: '🪨',
    attacks: [
      { name: 'Stone Fist', baseDmg: 12, description: 'A crushing bare-knuckle punch with natural weight.' },
      { name: 'Iron Ball Smash', baseDmg: 15, description: 'Launches a giant spiked iron ball to crush the opponent.' },
      { name: 'Serpentinite Bipolar', baseDmg: 18, description: 'Swings both his axe and spiked iron ball in a wide loop.' },
      { name: 'Stone Skin Shield', baseDmg: 22, description: 'Spins his heavy iron chain, blocking all incoming damage.' },
      { name: 'Volcanic Rock Hammer', baseDmg: 28, description: 'Brings down his heavy iron axe like a volcano eruption.' },
      { name: 'Stone Breath Wave', baseDmg: 35, description: 'Stamps the ground, releasing earth tremor shockwaves.' },
      { name: 'Earth Shatter', baseDmg: 48, description: 'Tears open the ground beneath the opponent using his heavy chain.' },
      { name: 'Heavy Chain Strike', baseDmg: 14, description: 'A rapid lashing series of iron chain strikes.' },
      { name: 'Gyomei Prayer Shield', baseDmg: 17, description: 'Prays to gain immense mental focus and static defense.' },
      { name: 'Stone Pillar Crash', baseDmg: 23, description: 'Drops a heavy stone pillar onto the target.' },
      { name: 'Stone Wall Force', baseDmg: 32, description: 'Launches debris and heavy stones using chain momentum.' },
      { name: 'Cataclysmic Mountain Smite', baseDmg: 52, description: 'Combines axe and spiked ball for a mountain-splitting crush.' }
    ]
  },
  sanemi: {
    id: 'sanemi',
    name: 'SANEMI (CHIBI)',
    title: 'Wind Hashira Pillar',
    color: 'from-teal-600 to-emerald-950',
    borderColor: 'border-teal-500',
    accentColor: '#14b8a6',
    avatar: 'https://cdn.myanimelist.net/images/characters/16/382030.jpg',
    energySymbol: '🌪️',
    attacks: [
      { name: 'Dust Whirlwind', baseDmg: 12, description: 'Charges forward enveloped in a swift dust cyclone.' },
      { name: 'Claws-Purifying Wind', baseDmg: 15, description: 'Fires several vertical claw-like wind vacuum cuts.' },
      { name: 'Clean Storm Slash', baseDmg: 18, description: 'Creates a rapid protective dome of wind slashes.' },
      { name: 'Rising Dust Storm', baseDmg: 22, description: 'An upward sweeping gust that launches the target.' },
      { name: 'Cold Toes Gale', baseDmg: 28, description: 'Fires low-sweeping crescent wind blades.' },
      { name: 'Black Wind Mountain', baseDmg: 35, description: 'A massive downward circular vortex of wind slashes.' },
      { name: 'Primary Cyclone', baseDmg: 48, description: 'Creates a gigantic raging tornado to trap and shred.' },
      { name: 'Cyclone Slash', baseDmg: 14, description: 'A rapid spinning slash that cuts through defenses.' },
      { name: 'Wind-Scythe Barrage', baseDmg: 17, description: 'Launches a flurry of vacuum wind scythe projectiles.' },
      { name: 'Shindeiru Fury', baseDmg: 23, description: 'A blood-curdling dash slash of extreme speeds.' },
      { name: 'Gale Blow Kick', baseDmg: 32, description: 'A sweeping aerial kick that launches wind gusts.' },
      { name: 'Cataclysmic Typhoon Shred', baseDmg: 52, description: 'An absolute storm of horizontal and vertical typhoon cuts.' }
    ]
  },
  naruto: {
    id: 'naruto',
    name: 'NARUTO (CHIBI)',
    title: 'Sage Toad Fox Hero',
    color: 'from-amber-500 to-yellow-600',
    borderColor: 'border-amber-500',
    accentColor: '#f59e0b',
    avatar: 'https://cdn.myanimelist.net/images/characters/9/131317.jpg',
    energySymbol: '🍥',
    attacks: [
      { name: 'Shadow Clone Kick', baseDmg: 12, description: 'Summons clones to bounce opponent in sky.' },
      { name: 'Rasengan Gale', baseDmg: 15, description: 'Swirling kinetic chakra core held in palm.' },
      { name: 'Sage Mode Punch', baseDmg: 18, description: 'Natural energy fist strikes from range.' },
      { name: 'Odama Rasengan', baseDmg: 22, description: 'Massive swirling sphere crushes battlefield.' },
      { name: 'Rasenshuriken Wind', baseDmg: 28, description: 'Throws spinning wind element chakra blades.' },
      { name: 'Tailed Beast Bomb', baseDmg: 35, description: 'Concentrated dark energy core fired instantly.' },
      { name: 'Six Paths Truthseeker', baseDmg: 48, description: 'Black matter visual rods launch into target.' },
      { name: 'Clone Body Slam', baseDmg: 11, description: 'Multi-clone airborne body slam.' },
      { name: 'Sage Energy Deflection', baseDmg: 16, description: 'Barrier of natural sage energy strikes outward.' },
      { name: 'Giant Rasengan Surge', baseDmg: 21, description: 'Expands rasengan core to envelop the opponent.' },
      { name: 'Kurama Chakra Blast', baseDmg: 32, description: 'Golden fox avatar shoots massive energy blast.' },
      { name: 'Nine-Tails Planetary Rasenshuriken', baseDmg: 52, description: 'Supreme merged wind and beast chakra collision.' }
    ]
  },
  sasuke: {
    id: 'sasuke',
    name: 'SASUKE (CHIBI)',
    title: 'Rogue Shadow Avenger',
    color: 'from-indigo-600 to-slate-900',
    borderColor: 'border-indigo-500',
    accentColor: '#6366f1',
    avatar: 'https://cdn.myanimelist.net/images/characters/9/131311.jpg',
    energySymbol: '👁️‍🗨️',
    attacks: [
      { name: 'Fireball Flare', baseDmg: 12, description: 'Spews concentrated high-temp flame cloud.' },
      { name: 'Kirin Thunder Roar', baseDmg: 15, description: 'Summons atmospheric cloud lightning dragon.' },
      { name: 'Chidori Strike', baseDmg: 18, description: 'Sprints forward with high-voltage palm blade.' },
      { name: 'Amaterasu Flare', baseDmg: 22, description: 'Conjures unquenchable black visual fire.' },
      { name: 'Susanoo Deflect', baseDmg: 28, description: 'Spectral rib cage rams into enemy.' },
      { name: 'Susanoo Giant Sword', baseDmg: 35, description: 'Vast visual energy sword slash sweep.' },
      { name: 'Indra Arrow Overdrive', baseDmg: 48, description: 'Godly atmospheric lightning arrow shot.' },
      { name: 'Chidori Senbon Needles', baseDmg: 14, description: 'Fires lightning-formed piercing needles.' },
      { name: 'Sharingan Dodge Strike', baseDmg: 17, description: 'Predicts move, slides behind, and strikes back.' },
      { name: 'Susanoo Ribcage Ram', baseDmg: 23, description: 'Shields and rams with giant armored rib cage.' },
      { name: 'Heavenly Hand Teleport', baseDmg: 30, description: 'Swaps places with target instantly to strike blindside.' },
      { name: 'Perfect Susanoo Atmospheric Cut', baseDmg: 52, description: 'Colossal giant warrior slash that cuts the battlefield.' }
    ]
  },
  itachi: {
    id: 'itachi',
    name: 'ITACHI (CHIBI)',
    title: 'Rogue Crow Master',
    color: 'from-red-950 to-zinc-950',
    borderColor: 'border-red-950',
    accentColor: '#b91c1c',
    avatar: 'https://cdn.myanimelist.net/images/characters/16/323363.jpg',
    energySymbol: '🐦',
    attacks: [
      { name: 'Crow Clone Illusion', baseDmg: 12, description: 'Disperses into crows to evade and strike.' },
      { name: 'Amaterasu Fire', baseDmg: 16, description: 'Fires black inextinguishable embers.' },
      { name: 'Tsukuyomi Mind', baseDmg: 20, description: 'Traps foe in 72 hours of illusionary torture.' },
      { name: 'Yasaka Beads', baseDmg: 24, description: 'Throws spiral energy projectile from Susanoo.' },
      { name: 'Totsuka Blade', baseDmg: 30, description: 'Spectral sealing sword pierces the target.' },
      { name: 'Izanami Loop', baseDmg: 38, description: 'Traps target in infinite physical loop.' },
      { name: 'Kotoamatsukami Force', baseDmg: 48, description: 'Absolute mind control shockwave.' },
      { name: 'Fireball Jutsu', baseDmg: 14, description: 'Launches beautiful standard fireball.' },
      { name: 'Shuriken Barrage', baseDmg: 18, description: 'Flawless bouncing shuriken trajectory hits.' },
      { name: 'Yata Mirror Block', baseDmg: 22, description: 'Invincible shield reflecting damage.' },
      { name: 'Crow Feather Storm', baseDmg: 32, description: 'Blinds enemy with flock of dark crows.' },
      { name: 'Tsukuyomi Reality Break', baseDmg: 52, description: 'Shatters reality like glass to crush spirit.' }
    ]
  },
  obito: {
    id: 'obito',
    name: 'OBITO (CHIBI)',
    title: 'Masked Reality Weaver',
    color: 'from-rose-950 to-zinc-950',
    borderColor: 'border-rose-900',
    accentColor: '#e11d48',
    avatar: 'https://cdn.myanimelist.net/images/characters/7/133501.jpg',
    energySymbol: '🌀',
    attacks: [
      { name: 'Kamui Phase', baseDmg: 12, description: 'Bends space to become completely intangible.' },
      { name: 'Fire Style Bomb', baseDmg: 15, description: 'Launches a swirling firestorm blast.' },
      { name: 'Wood Style Piercing', baseDmg: 18, description: 'Spears target with sharp, growing wood roots.' },
      { name: 'Kamui Warp', baseDmg: 22, description: 'Warp-teleports behind target for a critical smash.' },
      { name: 'Uchiha Flame Battle', baseDmg: 28, description: 'Envelops the screen in defensive flames.' },
      { name: 'Gedo Statue Summon', baseDmg: 35, description: 'Summons Gedo Mazo to release energy shockwaves.' },
      { name: 'Izanagi Rebirth', baseDmg: 48, description: 'Rewrites reality to fully heal and deal massive damage.' },
      { name: 'Ten-Tails Laser', baseDmg: 14, description: 'A bright high-power energy beam from Ten-Tails.' },
      { name: 'Six Paths Chakra', baseDmg: 17, description: 'Releases white divine energy bursts.' },
      { name: 'Truthseeker Spear', baseDmg: 23, description: 'Manifests a dark spear that ignores defenses.' },
      { name: 'Kamui Shuriken', baseDmg: 32, description: 'Throws massive shurikens that swallow space.' },
      { name: 'Infinite Tsukuyomi Spark', baseDmg: 53, description: 'Reflects moon light to deal cataclysmic mind blast.' }
    ]
  },
  madara: {
    id: 'madara',
    name: 'MADARA (CHIBI)',
    title: 'Legendary Clan Ancestor',
    color: 'from-red-900 to-neutral-950',
    borderColor: 'border-red-700',
    accentColor: '#dc2626',
    avatar: 'https://cdn.myanimelist.net/images/characters/6/172605.jpg',
    energySymbol: '☄️',
    attacks: [
      { name: 'Gunbai Shield', baseDmg: 12, description: 'Reflects attack using signature war fan.' },
      { name: 'Majestic Destroyer Flame', baseDmg: 16, description: 'Enormous wave of raging dragon fire.' },
      { name: 'Susanoo Claws', baseDmg: 20, description: 'Blue skeletal hands slash forward.' },
      { name: 'Meteor Drop', baseDmg: 25, description: 'Tengai Shinsei: drops a planet-sized meteor.' },
      { name: 'Infinite Tsukuyomi', baseDmg: 30, description: 'Traps opponent in moon dream illusion.' },
      { name: 'Perfect Susanoo', baseDmg: 38, description: 'Summons armored giant warrior to cleave mountain.' },
      { name: 'Shattered Heavens', baseDmg: 48, description: 'Double meteor cataclysmic impact.' },
      { name: 'Fire Dragon Breath', baseDmg: 14, description: 'Rapid flame bullets.' },
      { name: 'Wood Style Bind', baseDmg: 18, description: 'Spawns trees to trap and slam.' },
      { name: 'Rinnegan Pull', baseDmg: 22, description: 'Gravity pulling target into blast.' },
      { name: 'Limbo Clones', baseDmg: 32, description: 'Invisible extra-dimensional clone punches.' },
      { name: 'Godly Star Obliteration', baseDmg: 52, description: 'Collapses reality using supreme meteor burst.' }
    ]
  },
  sakura: {
    id: 'sakura',
    name: 'SAUKRA (CHIBI)',
    title: 'Cherry Blossom Medic',
    color: 'from-pink-500 to-rose-600',
    borderColor: 'border-pink-400',
    accentColor: '#ec4899',
    avatar: 'https://cdn.myanimelist.net/images/characters/16/310309.jpg',
    energySymbol: '🌸',
    attacks: [
      { name: 'Cherry Blossom Impact', baseDmg: 12, description: 'Concentrated chakra ground shattering fist.' },
      { name: 'Mitotic Regeneration', baseDmg: 15, description: 'Activates forehead seal to heal and boost.' },
      { name: 'Chakra Scalpel', baseDmg: 18, description: 'Slices muscle fibers directly.' },
      { name: 'Katsuyu Acid Splash', baseDmg: 22, description: 'Summons giant slug to spit acid.' },
      { name: 'Inner Sakura Outburst', baseDmg: 28, description: 'Inner voice rage shockwave.' },
      { name: 'Hundred Strengths Punch', baseDmg: 35, description: 'Absolute maximum power smash.' },
      { name: 'Creation Rebirth Strike', baseDmg: 48, description: 'Supreme strike with fully active seal.' },
      { name: 'Chakra Fist Scurry', baseDmg: 14, description: 'Fast moving high-power boxing jabs.' },
      { name: 'Slam Cushion', baseDmg: 17, description: 'Punches ground to throw debris at target.' },
      { name: 'Poison Gas Cloud', baseDmg: 23, description: 'Launches chemical sleeping gas capsule.' },
      { name: 'Strength of a Hundred Seal', baseDmg: 32, description: 'Burst of blue mark chakra energy.' },
      { name: 'Cherry Blossom Obliteration', baseDmg: 52, description: 'Shatters the entire continent with one ultimate punch.' }
    ]
  },
  light: {
    id: 'light',
    name: 'LIGHT (CHIBI)',
    title: 'Kira God of New World',
    color: 'from-stone-800 to-red-950',
    borderColor: 'border-red-900',
    accentColor: '#ef4444',
    avatar: 'https://cdn.myanimelist.net/images/characters/6/278838.jpg',
    energySymbol: '📓',
    attacks: [
      { name: 'Pen Stroke', baseDmg: 12, description: 'Writes name with sharp ink slash.' },
      { name: 'Deduction Snare', baseDmg: 15, description: 'Psychological setup trap.' },
      { name: 'Apple Toss', baseDmg: 18, description: 'Throws bait for the shinigami.' },
      { name: 'Shinigami Eyes', baseDmg: 22, description: 'Visual life calculation strike.' },
      { name: 'Heart Attack', baseDmg: 28, description: 'Standard notebook execution.' },
      { name: 'Kira Judgement', baseDmg: 35, description: 'Supreme notebook clean strike.' },
      { name: 'Perfect Plan', baseDmg: 48, description: 'Unveils foolproof absolute setup.' },
      { name: 'Potato Chip Snap', baseDmg: 14, description: 'Famously eats potato chip dramatically.' },
      { name: 'Matsuda Fire Blast', baseDmg: 17, description: 'Manipulates crossfire from the task force.' },
      { name: 'Ryuk Laugh Wave', baseDmg: 23, description: 'Shinigami release cackle sonic wave.' },
      { name: 'Fake Notebook Trap', baseDmg: 32, description: 'Deceives enemy with a double-agent notebook decoy.' },
      { name: 'God of New World', baseDmg: 52, description: 'Ultimate apocalyptic cleanse.' }
    ]
  },
  l: {
    id: 'l',
    name: 'L (CHIBI)',
    title: 'Legendary Detective',
    color: 'from-zinc-100 to-zinc-400',
    borderColor: 'border-zinc-300',
    accentColor: '#18181b',
    avatar: 'https://cdn.myanimelist.net/images/characters/10/242275.jpg',
    energySymbol: '☕',
    attacks: [
      { name: 'Couch Squat kick', baseDmg: 12, description: 'Unorthodox squatting defensive kick.' },
      { name: 'Sugar Rush', baseDmg: 15, description: 'Consumes sugar for extreme processing boost.' },
      { name: 'Teaspoon Flick', baseDmg: 18, description: 'Flicks high-speed metal spoon.' },
      { name: 'Deduction Percentage', baseDmg: 22, description: 'Calculates success probability.' },
      { name: 'Fingerprint Scan', baseDmg: 28, description: 'Analyses and counters physical moves.' },
      { name: 'Task Force Raid', baseDmg: 35, description: 'Calls SWAT and detectives for backup.' },
      { name: 'Justice Prevails', baseDmg: 48, description: 'Shatters deception with absolute proof.' },
      { name: 'Lolipop Spin', baseDmg: 14, description: 'Spinning candy strike.' },
      { name: 'Monologue Mind', baseDmg: 17, description: 'Stuns opponent with intense deduction logic.' },
      { name: 'Strawberry Smash', baseDmg: 23, description: 'Launches giant cake strawberry.' },
      { name: 'Wammy House Intel', baseDmg: 32, description: 'Uses advanced technology network strike.' },
      { name: 'Mastermind Checkmate', baseDmg: 52, description: 'The absolute final solving of the case.' }
    ]
  },
  ryuk: {
    id: 'ryuk',
    name: 'RYUK (CHIBI)',
    title: 'Bored Shinigami Observer',
    color: 'from-neutral-800 to-neutral-950',
    borderColor: 'border-neutral-700',
    accentColor: '#525252',
    avatar: 'https://cdn.myanimelist.net/images/characters/14/198463.jpg',
    energySymbol: '🍎',
    attacks: [
      { name: 'Apple Feast', baseDmg: 12, description: 'Gains power by eating delicious apples.' },
      { name: 'Death Flight', baseDmg: 15, description: 'Flaps black wings to dive-strike from the dark.' },
      { name: 'Shinigami Laugh', baseDmg: 18, description: 'Releases a creepy sonic laugh that stuns the target.' },
      { name: 'Pen Drop', baseDmg: 22, description: 'Drops a lethal ink pen projectile.' },
      { name: 'Notebook Steal', baseDmg: 28, description: 'Snatches weapons or spells out of mid-air.' },
      { name: 'Life Span View', baseDmg: 35, description: 'Senses lifespans to hit the absolute weakpoint.' },
      { name: 'Dimensional Travel', baseDmg: 48, description: 'Steps through dimensions to surprise slam.' },
      { name: 'Shadow Wings', baseDmg: 14, description: 'Spins in a storm of razor-sharp black feathers.' },
      { name: 'Apple Temptation', baseDmg: 17, description: 'Lures target into a direct explosive trap.' },
      { name: 'Ryuk Scratch', baseDmg: 23, description: 'Claws forward with shinigami nails.' },
      { name: 'Portal Slip', baseDmg: 32, description: 'Warp slips into shadows to avoid damage.' },
      { name: 'Final Notebook Stamp', baseDmg: 52, description: 'Applies the official mark of death to delete HP.' }
    ]
  },
  eren: {
    id: 'eren',
    name: 'EREN (CHIBI)',
    title: 'Attack Titan Avenger',
    color: 'from-yellow-950 to-red-950',
    borderColor: 'border-yellow-900',
    accentColor: '#9a3412',
    avatar: 'https://cdn.myanimelist.net/images/characters/10/216841.jpg',
    energySymbol: '🧬',
    attacks: [
      { name: 'ODM Blade Slash', baseDmg: 12, description: 'Dashes at extreme speeds slicing with dual blades.' },
      { name: 'Titan Bite', baseDmg: 16, description: 'Bites his hand, releasing a massive lightning spark.' },
      { name: 'Hardening Fist', baseDmg: 19, description: 'Smashes with a fist coated in dense diamond crystal.' },
      { name: 'Attack Titan Punch', baseDmg: 23, description: 'A colossal brute force titan boxing smash.' },
      { name: 'Warhammer Spike', baseDmg: 28, description: 'Spawns long, piercing crystal spikes from the ground.' },
      { name: 'Roar of Freedom', baseDmg: 35, description: 'An absolute titan roar that blows back any target.' },
      { name: 'Founder Command', baseDmg: 48, description: 'Summons ancient wall titans to stomp down.' },
      { name: 'Colossal Footstep', baseDmg: 15, description: 'A giant fiery foot stamps down from the sky.' },
      { name: 'Hardened Shield', baseDmg: 18, description: 'Manifests a solid wall of crystal hardening.' },
      { name: 'Steer Titan Horde', baseDmg: 25, description: 'Sends a wave of running titans to trample the field.' },
      { name: 'Founding Titan Skeletal Spike', baseDmg: 32, description: 'Shoots long skeletal rib spikes forward.' },
      { name: 'Rumbling Apocalypse', baseDmg: 56, description: 'The absolute rumbling sweeps across the entire earth.' }
    ]
  },
  levi: {
    id: 'levi',
    name: 'LEVI (CHIBI)',
    title: 'Humanitys Strongest Soldier',
    color: 'from-slate-700 to-zinc-900',
    borderColor: 'border-slate-500',
    accentColor: '#64748b',
    avatar: 'https://cdn.myanimelist.net/images/characters/2/241417.jpg',
    energySymbol: '💨',
    attacks: [
      { name: 'Twin Blade Spin', baseDmg: 12, description: 'A rapid circular twin blade rotating cut.' },
      { name: '3D Maneuver Hook', baseDmg: 15, description: 'Shoots steel wire hooks into the target to swing-kick them.' },
      { name: 'Reverse Grip Slash', baseDmg: 18, description: 'A signature high-speed downward rolling slice.' },
      { name: 'Blindside Evade', baseDmg: 22, description: 'Flashes behind the opponent with gas thrust boost.' },
      { name: 'Thunder Spear Blast', baseDmg: 28, description: 'Launches exploding rocket spears onto the enemy.' },
      { name: 'Ackerman Fury', baseDmg: 35, description: 'Delivers dozens of sword slashes in a split second.' },
      { name: 'Levi Beyblade Spin', baseDmg: 48, description: 'The legendary spinning roll of blades that shreds armor.' },
      { name: 'Gas Thrust Kick', baseDmg: 14, description: 'Launches a flying direct boot kick powered by compressed gas.' },
      { name: 'Blade Shower', baseDmg: 17, description: 'Thows a hand of razor-sharp broken blades.' },
      { name: 'Precise Achilles Cut', baseDmg: 23, description: 'Hits the tendons to paralyze and deal heavy damage.' },
      { name: 'Squad Assist', baseDmg: 32, description: 'Special ops team members dash in for cross-slash support.' },
      { name: 'Supreme Titan Shredder', baseDmg: 53, description: 'The absolute pinnacle of high-speed ODM combat slashes.' }
    ]
  },
  lelouch: {
    id: 'lelouch',
    name: 'LELOUCH (CHIBI)',
    title: 'Zero Rebellion Mastermind',
    color: 'from-purple-950 to-neutral-950',
    borderColor: 'border-purple-800',
    accentColor: '#a855f7',
    avatar: 'https://cdn.myanimelist.net/images/characters/11/283488.jpg',
    energySymbol: '♟️',
    attacks: [
      { name: 'Geass Command', baseDmg: 12, description: 'Red absolute command eye spark flashes.' },
      { name: 'Absolute Obedience', baseDmg: 16, description: 'Triggers absolute obedience mind shatter.' },
      { name: 'Shinkiro Laser', baseDmg: 19, description: 'Fires liquid crystal prism lasers from his Knightmare.' },
      { name: 'Strategy Shift', baseDmg: 23, description: 'Sacrifices temporary shields for a massive tactical check.' },
      { name: 'Knightmare Call', baseDmg: 28, description: 'Summons Guren to punch with radiation wave hand.' },
      { name: 'Zero Requiem', baseDmg: 35, description: 'Stops time briefly to execute a perfect sacrifice strike.' },
      { name: 'Geass Absolute Sovereign', baseDmg: 48, description: 'Forces the opponent to attack themselves with full force.' },
      { name: 'Chessmaster Bait', baseDmg: 14, description: 'Deceives enemy with fake weakpoint, then counters.' },
      { name: 'Royal Decree', baseDmg: 17, description: 'Summons the Black Knights for a massive visual shootout.' },
      { name: 'Hadron Cannon', baseDmg: 25, description: 'Fires dual red high-energy laser cannons.' },
      { name: 'Absolute Defense', baseDmg: 32, description: 'Shields in Shinkiros hexagonal prism barrier.' },
      { name: 'Rebel Rally Blast', baseDmg: 54, description: 'Fires the Freija absolute nuclear warhead.' }
    ]
  }
};

// Compile VALID_CUSTOM_ATTACKS from our FIGHTERS record dynamically for robust safety!
export const VALID_CUSTOM_ATTACKS: Record<string, string[]> = {};
Object.keys(FIGHTERS).forEach(key => {
  VALID_CUSTOM_ATTACKS[key] = FIGHTERS[key].attacks.map(att => att.name.toUpperCase());
});

const requestedMatches: DuelMatchup[] = [
  // User Requested Fights:
  { id: 'req1', name: 'Megumi VS Itachi', fighterAId: 'megumi', fighterBId: 'itachi' },
  { id: 'req2', name: 'Itachi VS Obito', fighterAId: 'itachi', fighterBId: 'obito' },
  { id: 'req3', name: 'Goku VS Itachi', fighterAId: 'goku', fighterBId: 'itachi' },
  { id: 'req4', name: 'Itachi VS Gojo', fighterAId: 'itachi', fighterBId: 'gojo' },
  { id: 'req5', name: 'Gyomei VS Sanemi', fighterAId: 'gyomei', fighterBId: 'sanemi' },
  { id: 'req6', name: 'Kokushibo VS Yuji', fighterAId: 'kokushibo', fighterBId: 'yuji' },
  
  // High Profile Examples & Classical Matches:
  { id: 'ex1', name: 'Gojo VS Itachi', fighterAId: 'gojo', fighterBId: 'itachi' },
  { id: 'ex2', name: 'Sukuna VS Madara', fighterAId: 'sukuna', fighterBId: 'madara' },
  { id: 'ex3', name: 'Naruto VS Goku', fighterAId: 'naruto', fighterBId: 'goku' },
  { id: 'ex4', name: 'Luffy VS Yuji', fighterAId: 'luffy', fighterBId: 'yuji' },
  { id: 'ex5', name: 'Tanjiro VS Sasuke', fighterAId: 'tanjiro', fighterBId: 'sasuke' },
  { id: 'ex6', name: 'Light VS Lelouch', fighterAId: 'light', fighterBId: 'lelouch' },
  { id: 'ex7', name: 'Levi VS Obito', fighterAId: 'levi', fighterBId: 'obito' },
  { id: 'ex8', name: 'Saitama VS Goku', fighterAId: 'saitama', fighterBId: 'goku' },
  { id: 'ex9', name: 'Gojo VS Sukuna', fighterAId: 'gojo', fighterBId: 'sukuna' },
  { id: 'ex10', name: 'Tanjiro VS Muzan', fighterAId: 'tanjiro', fighterBId: 'muzan' },
  { id: 'ex11', name: 'Eren VS Levi', fighterAId: 'eren', fighterBId: 'levi' },
  { id: 'ex12', name: 'Luffy VS Zoro', fighterAId: 'luffy', fighterBId: 'zoro' },
  { id: 'ex13', name: 'Goku VS Vegeta', fighterAId: 'goku', fighterBId: 'vegeta' },
  { id: 'ex14', name: 'Sasuke VS Naruto', fighterAId: 'sasuke', fighterBId: 'naruto' },
  { id: 'ex15', name: 'Muzan VS Kokushibo', fighterAId: 'muzan', fighterBId: 'kokushibo' },
  { id: 'ex16', name: 'L VS Light', fighterAId: 'l', fighterBId: 'light' },
  { id: 'ex17', name: 'Yuji VS Megumi', fighterAId: 'yuji', fighterBId: 'megumi' },
  { id: 'ex18', name: 'Akaza VS Doma', fighterAId: 'akaza', fighterBId: 'doma' },
  { id: 'ex19', name: 'Nobara VS Sakura', fighterAId: 'nobara', fighterBId: 'sakura' },
  { id: 'ex20', name: 'Ryuk VS Light', fighterAId: 'ryuk', fighterBId: 'light' }
];

const generateMatchups = (): DuelMatchup[] => {
  const result = [...requestedMatches];
  const seenPairs = new Set<string>();

  // Initialize seen pairs
  result.forEach(m => {
    const key = [m.fighterAId, m.fighterBId].sort().join('-');
    seenPairs.add(key);
  });

  const keys = Object.keys(FIGHTERS);
  let idCounter = 1;

  // Let's iterate over keys to build out a full list of exactly 200 matchups
  for (let i = 0; i < keys.length; i++) {
    for (let j = 0; j < keys.length; j++) {
      if (i === j) continue;
      if (result.length >= 200) break;

      const fAId = keys[i];
      const fBId = keys[j];
      const key = [fAId, fBId].sort().join('-');

      if (!seenPairs.has(key)) {
        seenPairs.add(key);
        
        // Grab nice short names
        const nameA = FIGHTERS[fAId].name.replace(' (CHIBI)', '');
        const nameB = FIGHTERS[fBId].name.replace(' (CHIBI)', '');
        
        result.push({
          id: `m_gen_${idCounter++}`,
          name: `${nameA} VS ${nameB}`,
          fighterAId: fAId,
          fighterBId: fBId
        });
      }
    }
    if (result.length >= 200) break;
  }

  // Double check if we need more padding to reach exactly 200 (if roster combo allows)
  return result.slice(0, 200);
};

export const MATCHUPS: DuelMatchup[] = generateMatchups();
