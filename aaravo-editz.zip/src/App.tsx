import { useState, useEffect } from 'react';
import PhoneShell from './components/PhoneShell';
import HomeTab from './components/HomeTab';
import VideosTab from './components/VideosTab';
import AboutTab from './components/AboutTab';
import GameTab from './components/GameTab';
import NotificationCenter from './components/NotificationCenter';
import { ActiveTab, NotificationItem } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [logoUrl, setLogoUrl] = useState<string>('https://yt3.googleusercontent.com/vz3yGgm23APspUhDRBYfsEJ2_HhP9kDATIERxLi6SvcLStrVHAKjIgxcVYY_vWvfAgK1W2WkZQ=s900-c-k-c0x00ffffff-no-rj');
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);

  // Fetch the official logo and live video upload notifications dynamically
  useEffect(() => {
    // 1. Fetch channel logo
    fetch('/api/channel-logo')
      .then(res => res.json())
      .then(data => {
        if (data.logoUrl) {
          setLogoUrl(data.logoUrl);
        }
      })
      .catch(err => {
        console.warn('Failed to fetch official channel logo, using default fallback.', err);
      });

    // 2. Fetch live videos to trigger upload notification only when content is actually uploaded
    fetch('/api/youtube-videos')
      .then(res => res.json())
      .then(data => {
        if (data.videos && data.videos.length > 0) {
          const latestVideo = data.videos[0];
          
          // Show notifications only for genuinely fresh uploads (Today, Yesterday, or recently uploaded)
          const isFreshUpload = latestVideo.releaseDate === "Today" || 
                                latestVideo.releaseDate === "Yesterday" || 
                                latestVideo.releaseDate === "Recently uploaded" ||
                                latestVideo.releaseDate === "Just now";
          
          // Also check localStorage so we don't spam the notification again once read/dismissed
          const dismissedNotifs = JSON.parse(localStorage.getItem('aaravo_dismissed_notifications') || '[]');
          
          if (isFreshUpload && !dismissedNotifs.includes(latestVideo.id)) {
            const newNotif: NotificationItem = {
              id: `upload-${latestVideo.id}`,
              title: `🔥 NEW CINEMATIC UPLOAD: "${latestVideo.title}" is now online! Watch, like, and subscribe!`,
              time: latestVideo.releaseDate || "Just now",
              isRead: false,
              type: "upload",
              link: latestVideo.youtubeUrl || `https://www.youtube.com/shorts/${latestVideo.id}`,
            };
            setNotifications([newNotif]);
          } else {
            setNotifications([]);
          }
        } else {
          // Empty state for notifications if no live content is loaded
          setNotifications([]);
        }
      })
      .catch(err => {
        console.warn('Failed to load live video notifications, setting empty:', err);
        setNotifications([]);
      });
  }, []);

  const toggleNotifications = () => {
    setIsNotificationsOpen(prev => !prev);
  };

  return (
    <PhoneShell
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      notifications={notifications}
      setNotifications={setNotifications}
      toggleNotificationsOpen={toggleNotifications}
      logoUrl={logoUrl}
    >
      {/* Dynamic Tab Switcher */}
      {activeTab === 'home' && (
        <HomeTab
          onLearnMore={() => setActiveTab('about')}
          onGoToVideos={() => setActiveTab('videos')}
          onPlayGame={() => setActiveTab('game')}
          logoUrl={logoUrl}
        />
      )}

      {activeTab === 'videos' && (
        <VideosTab logoUrl={logoUrl} />
      )}

      {activeTab === 'game' && (
        <GameTab logoUrl={logoUrl} />
      )}

      {activeTab === 'about' && (
        <AboutTab />
      )}

      {/* Floating notifications panel overlay */}
      <NotificationCenter
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        setNotifications={setNotifications}
      />
    </PhoneShell>
  );
}
