import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

// Initialize Gemini SDK lazily to prevent crash if key is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY environment variable is not set. AI Assistant features will use fallback mock data.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Initialize Firestore
let db: any = null;

async function initFirestore() {
  try {
    const configPath = path.join(process.cwd(), "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
      const { Firestore } = await import("@google-cloud/firestore");
      const tempDb = new Firestore({
        projectId: config.projectId,
        databaseId: config.firestoreDatabaseId || "(default)",
      });
      
      // Silent probe to test read permissions
      try {
        await tempDb.collection("stats").doc("probe").get();
        db = tempDb;
        console.log("Firestore initialized and verified successfully on backend.");
      } catch (probeErr: any) {
        console.log("Firestore connection probe failed or lacks read permissions. Utilizing clean in-memory cache fallbacks.");
        db = null;
      }
    } else {
      console.warn("firebase-applet-config.json not found. Firestore will use memory fallback.");
    }
  } catch (err) {
    console.log("Failed to initialize Firestore, using memory fallback.");
  }
}

initFirestore().catch(err => console.log("initFirestore error caught."));

// Robust self-healing Firestore permission handler
function checkFirestoreError(err: any, context: string) {
  const errMsg = err instanceof Error ? err.message : String(err);
  const isPermissionDenied = errMsg.includes("PERMISSION_DENIED") || (err && (err.code === 7 || err.status === 7));
  
  if (isPermissionDenied) {
    console.log(`[Firestore Service] Read/Write permission disabled for ${context}. Falling back cleanly to memory storage.`);
    db = null;
  } else {
    console.error(`Firestore error in ${context}:`, err);
  }
}

// Global stats fallbacks
let memorySubscribeClicks = 342;
let cachedSubscribers = "43";
let lastSubscriberFetchTime = 0;
let cachedVideosList: any[] = [];
let lastVideosFetchTime = 0;

// Helper to format numbers cleanly
function formatCount(count: number): string {
  if (count >= 1000000) {
    return (count / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }
  if (count >= 1000) {
    return (count / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  }
  return count.toString();
}

function formatSubscribers(count: number): string {
  if (count >= 1000000) {
    return (count / 1000000).toFixed(2).replace(/\.00$/, '') + 'M';
  }
  if (count >= 1000) {
    return (count / 1000).toFixed(2).replace(/\.00$/, '') + 'K';
  }
  return count.toString();
}

// ISO 8601 duration parser
function parseISO8601Duration(durationStr: string) {
  const match = durationStr.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) {
    return { formatted: "0:30", totalSeconds: 30 };
  }
  const hours = parseInt(match[1]) || 0;
  const minutes = parseInt(match[2]) || 0;
  const seconds = parseInt(match[3]) || 0;
  
  const totalSeconds = hours * 3600 + minutes * 60 + seconds;
  
  let formatted = "";
  if (hours > 0) {
    formatted += hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
  } else {
    formatted += minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
  }
  return { formatted, totalSeconds };
}

// Firestore operations
async function getSubscribeClicks(): Promise<number> {
  if (db) {
    try {
      const docRef = db.collection("stats").doc("global");
      const doc = await docRef.get();
      if (doc.exists) {
        const data = doc.data();
        if (data && typeof data.subscribeClicks === "number") {
          return data.subscribeClicks;
        }
      } else {
        await docRef.set({ subscribeClicks: 342 }, { merge: true });
        return 342;
      }
    } catch (err) {
      checkFirestoreError(err, "getSubscribeClicks");
    }
  }
  return memorySubscribeClicks;
}

async function incrementSubscribeClicks(): Promise<number> {
  if (db) {
    try {
      const docRef = db.collection("stats").doc("global");
      let clicks = 342;
      await db.runTransaction(async (transaction: any) => {
        const doc = await transaction.get(docRef);
        if (!doc.exists) {
          transaction.set(docRef, { subscribeClicks: 343 }, { merge: true });
          clicks = 343;
        } else {
          const currentClicks = doc.data().subscribeClicks || 342;
          clicks = currentClicks + 1;
          transaction.update(docRef, { subscribeClicks: clicks });
        }
      });
      memorySubscribeClicks = clicks;
      return clicks;
    } catch (err) {
      checkFirestoreError(err, "incrementSubscribeClicks");
    }
  }
  memorySubscribeClicks += 1;
  return memorySubscribeClicks;
}

// Dynamically resolve YouTube Channel ID
async function resolveChannelId(apiKey?: string): Promise<string> {
  const handle = "sheetalsharma9569";
  if (apiKey) {
    try {
      const url = `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=${handle}&key=${apiKey}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          return data.items[0].id;
        }
      }
    } catch (err) {
      console.warn("Failed to resolve channel ID using API key:", err);
    }
  }

  // Fallback to scraping HTML for channelId meta tag
  try {
    const channelUrl = `https://www.youtube.com/@${handle}`;
    const response = await fetch(channelUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      }
    });
    if (response.ok) {
      const html = await response.text();
      const metaMatch = html.match(/itemprop="channelId"\s+content="(UC[A-Za-z0-9_-]{22})"/i) || 
                        html.match(/content="(UC[A-Za-z0-9_-]{22})"\s+itemprop="channelId"/i);
      if (metaMatch && metaMatch[1]) {
        return metaMatch[1];
      }
      const linkMatch = html.match(/href="https:\/\/www\.youtube\.com\/channel\/(UC[A-Za-z0-9_-]{22})"/i);
      if (linkMatch && linkMatch[1]) {
        return linkMatch[1];
      }
      const jsonMatch = html.match(/"externalId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"/i) || 
                        html.match(/"channelId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"/i);
      if (jsonMatch && jsonMatch[1]) {
        return jsonMatch[1];
      }
    }
  } catch (err) {
    console.warn("Error scraping channel page for ID:", err);
  }

  return "UCF4m_R68jG6fH4hP7B636tQ"; // Default fallback ID
}

// Live subscriber count retrieval with multi-tier caching
async function getLiveSubscribers(apiKey?: string, channelId?: string): Promise<string> {
  const now = Date.now();
  // Cache in memory for 10 minutes to protect API quota
  if (now - lastSubscriberFetchTime < 10 * 60 * 1000 && cachedSubscribers !== "43") {
    return cachedSubscribers;
  }

  try {
    if (apiKey && channelId) {
      const url = `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${channelId}&key=${apiKey}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          const count = parseInt(data.items[0].statistics.subscriberCount) || 0;
          cachedSubscribers = formatSubscribers(count);
          lastSubscriberFetchTime = now;
          
          if (db) {
            try {
              await db.collection("stats").doc("global").set({
                cachedSubscribers,
                lastUpdatedSubscribers: now
              }, { merge: true });
            } catch (err) {
              checkFirestoreError(err, "getLiveSubscribers - set cache 1");
            }
          }
          return cachedSubscribers;
        }
      }
    }

    // Scraping fallback
    const handle = "sheetalsharma9569";
    const channelUrl = `https://www.youtube.com/@${handle}`;
    const response = await fetch(channelUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      }
    });
    if (response.ok) {
      const html = await response.text();
      const subCountMatch = html.match(/"subscriberCountText"\s*:\s*\{\s*"accessibility"\s*:\s*\{\s*"label"\s*:\s*"([^"]+)"/i) ||
                           html.match(/"subscriberCountText"\s*:\s*\{\s*"simpleText"\s*:\s*"([^"]+)"/i);
      if (subCountMatch && subCountMatch[1]) {
        let subs = subCountMatch[1].replace(' subscribers', '').trim();
        cachedSubscribers = subs;
        lastSubscriberFetchTime = now;

        if (db) {
          try {
            await db.collection("stats").doc("global").set({
              cachedSubscribers,
              lastUpdatedSubscribers: now
            }, { merge: true });
          } catch (err) {
            checkFirestoreError(err, "getLiveSubscribers - set cache 2");
          }
        }
        return cachedSubscribers;
      }
    }
  } catch (err) {
    console.error("Error fetching live subscriber count:", err);
  }

  // Retrieve from Firestore cache as ultimate fallback if available
  if (db) {
    try {
      const doc = await db.collection("stats").doc("global").get();
      if (doc.exists && doc.data().cachedSubscribers) {
        cachedSubscribers = doc.data().cachedSubscribers;
        return cachedSubscribers;
      }
    } catch (err) {
      checkFirestoreError(err, "getLiveSubscribers - get fallback");
    }
  }

  return cachedSubscribers;
}

// Smart classification for YouTube Shorts using HEAD redirection checks cached in Firestore
async function isYouTubeShort(videoId: string): Promise<boolean> {
  if (db) {
    try {
      const doc = await db.collection("video_types").doc(videoId).get();
      if (doc.exists) {
        return doc.data().isShort;
      }
    } catch (err) {
      checkFirestoreError(err, "isYouTubeShort - read cache");
    }
  }

  let isShort = false;
  try {
    const res = await fetch(`https://www.youtube.com/shorts/${videoId}`, {
      method: 'HEAD',
      redirect: 'manual'
    });
    isShort = res.status === 200;

    if (db) {
      try {
        await db.collection("video_types").doc(videoId).set({ isShort }, { merge: true });
      } catch (err) {
        checkFirestoreError(err, "isYouTubeShort - write cache");
      }
    }
  } catch (err) {
    console.warn(`Failed to HEAD check YouTube Shorts for ${videoId}:`, err);
  }
  return isShort;
}

// Live videos and shorts retriever with multi-layer Firestore caching
async function getYouTubeVideos(apiKey?: string, channelId?: string): Promise<any[]> {
  const now = Date.now();
  // Cache videos list in memory for 10 minutes to protect resources and response time
  if (now - lastVideosFetchTime < 10 * 60 * 1000 && cachedVideosList.length > 0) {
    return cachedVideosList;
  }

  try {
    if (apiKey && channelId) {
      // 1. Get channel uploads playlist ID
      const channelUrl = `https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${channelId}&key=${apiKey}`;
      const channelRes = await fetch(channelUrl);
      if (channelRes.ok) {
        const channelData = await channelRes.json();
        if (channelData.items && channelData.items.length > 0) {
          const uploadsPlaylistId = channelData.items[0].contentDetails.relatedPlaylists.uploads;
          
          // 2. Fetch playlist items (latest 50 uploads)
          const playlistUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId=${uploadsPlaylistId}&maxResults=50&key=${apiKey}`;
          const playlistRes = await fetch(playlistUrl);
          if (playlistRes.ok) {
            const playlistData = await playlistRes.json();
            const playlistItems = playlistData.items || [];
            
            if (playlistItems.length > 0) {
              const videoIds = playlistItems.map((item: any) => item.contentDetails.videoId);
              
              // 3. Fetch full details including stats and durations to classify shorts/videos accurately
              const detailsUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${videoIds.join(',')}&key=${apiKey}`;
              const detailsRes = await fetch(detailsUrl);
              if (detailsRes.ok) {
                const detailsData = await detailsRes.json();
                const detailsItems = detailsData.items || [];
                const detailsMap = new Map(detailsItems.map((item: any) => [item.id, item]));

                const mappedVideos = playlistItems.map((item: any) => {
                  const videoId = item.contentDetails.videoId;
                  const details: any = detailsMap.get(videoId);
                  
                  const title = item.snippet.title || "Epic Anime Edit | Aaravo Editz";
                  const description = item.snippet.description || "";
                  const publishedAt = item.snippet.publishedAt || new Date().toISOString();
                  
                  let duration = "0:30";
                  let isShort = true;
                  let viewsCount = 0;
                  let likesCount = 0;

                  if (details) {
                    const durationStr = details.contentDetails.duration;
                    const parsed = parseISO8601Duration(durationStr);
                    duration = parsed.formatted;
                    isShort = parsed.totalSeconds <= 61;
                    viewsCount = parseInt(details.statistics.viewCount) || 0;
                    likesCount = parseInt(details.statistics.likeCount) || 0;
                  } else {
                    isShort = title.toLowerCase().includes('#shorts') || description.toLowerCase().includes('#shorts');
                  }

                  const dateObj = new Date(publishedAt);
                  const diffMs = Date.now() - dateObj.getTime();
                  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
                  let releaseDate = "Recently uploaded";
                  if (diffDays === 0) {
                    releaseDate = "Today";
                  } else if (diffDays === 1) {
                    releaseDate = "Yesterday";
                  } else if (diffDays > 1) {
                    releaseDate = `${diffDays} days ago`;
                  }

                  // Style tag classification
                  let styleTag = "Velocity Ramp";
                  if (title.toLowerCase().includes("phonk")) styleTag = "Phonk Overdrive";
                  else if (title.toLowerCase().includes("amv")) styleTag = "Anime MV";
                  else if (title.toLowerCase().includes("drift")) styleTag = "Drift Style";
                  else if (title.toLowerCase().includes("aesthetic")) styleTag = "Cinematic CC";
                  else if (isShort) styleTag = "Beat Sync";

                  return {
                    id: videoId,
                    title: title,
                    type: isShort ? "shorts" : "latest",
                    duration: duration,
                    thumbnail: item.snippet.thumbnails?.maxres?.url || item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.medium?.url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
                    views: formatCount(viewsCount) + " views",
                    likes: formatCount(likesCount) + " likes",
                    releaseDate: releaseDate,
                    styleTag: styleTag,
                    description: description.slice(0, 150) || "A premium, dynamic edit from the official Aaravo Editz live channel feed. High-intensity audio sync and cinematic grading.",
                    transitionGuide: "Custom velocity flow mapped frame-by-frame with precise screen shakes.",
                    audioTrack: "Original synchronized background audio",
                    colorLUT: "Aaravo Custom Grade",
                    youtubeUrl: isShort ? `https://www.youtube.com/shorts/${videoId}` : `https://www.youtube.com/watch?v=${videoId}`,
                    publishedAt: publishedAt
                  };
                });

                cachedVideosList = mappedVideos;
                lastVideosFetchTime = now;

                if (db) {
                  try {
                    await db.collection("cached_videos").doc("list").set({ videos: mappedVideos, lastUpdated: now }, { merge: true });
                  } catch (err) {
                    checkFirestoreError(err, "getYouTubeVideos - set API cache");
                  }
                }
                return mappedVideos;
              }
            }
          }
        }
      }
    }

    // RSS Fallback when API key is not present or quota exceeded
    const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId || "UCF4m_R68jG6fH4hP7B636tQ"}`;
    const rssRes = await fetch(rssUrl);
    if (rssRes.ok) {
      const xmlText = await rssRes.text();
      const entryRegex = /<entry>([\s\S]*?)<\/entry>/g;
      let match;
      const parsedVideos: any[] = [];

      while ((match = entryRegex.exec(xmlText)) !== null) {
        const entryContent = match[1];
        const idMatch = entryContent.match(/<yt:videoId>([^<]+)<\/yt:videoId>/i);
        const videoId = idMatch ? idMatch[1].trim() : null;
        
        const titleMatch = entryContent.match(/<title>([^<]+)<\/title>/i);
        let title = titleMatch ? titleMatch[1].trim() : "Epic Anime Edit | Aaravo Editz";
        title = title.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");

        const publishedMatch = entryContent.match(/<published>([^<]+)<\/published>/i);
        const publishedAt = publishedMatch ? publishedMatch[1].trim() : new Date().toISOString();

        if (videoId) {
          const isShort = await isYouTubeShort(videoId);

          const dateObj = new Date(publishedAt);
          const diffMs = Date.now() - dateObj.getTime();
          const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
          let releaseDate = "Recently uploaded";
          if (diffDays === 0) {
            releaseDate = "Today";
          } else if (diffDays === 1) {
            releaseDate = "Yesterday";
          } else if (diffDays > 1) {
            releaseDate = `${diffDays} days ago`;
          }

          let styleTag = "Velocity Ramp";
          if (title.toLowerCase().includes("phonk")) styleTag = "Phonk Overdrive";
          else if (title.toLowerCase().includes("amv")) styleTag = "Anime MV";
          else if (title.toLowerCase().includes("drift")) styleTag = "Drift Style";
          else if (isShort) styleTag = "Beat Sync";

          parsedVideos.push({
            id: videoId,
            title: title,
            type: isShort ? "shorts" : "latest",
            duration: isShort ? "0:30" : "3:30",
            thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
            views: "Live views",
            likes: "Live likes",
            releaseDate: releaseDate,
            styleTag: styleTag,
            description: "A premium, dynamic edit from the official Aaravo Editz live channel feed. High-intensity audio sync and cinematic grading.",
            transitionGuide: "Custom velocity flow mapped frame-by-frame with precise screen shakes.",
            audioTrack: "Original synchronized background audio",
            colorLUT: "Aaravo Custom Grade",
            youtubeUrl: isShort ? `https://www.youtube.com/shorts/${videoId}` : `https://www.youtube.com/watch?v=${videoId}`,
            publishedAt: publishedAt
          });
        }
      }

      if (parsedVideos.length > 0) {
        cachedVideosList = parsedVideos;
        lastVideosFetchTime = now;

        if (db) {
          try {
            await db.collection("cached_videos").doc("list").set({ videos: parsedVideos, lastUpdated: now }, { merge: true });
          } catch (err) {
            checkFirestoreError(err, "getYouTubeVideos - set RSS cache");
          }
        }
        return parsedVideos;
      }
    }
  } catch (err) {
    console.error("Error fetching live videos:", err);
  }

  // Firestore Backup Cache Fallback (ultimate resilience)
  if (db) {
    try {
      const doc = await db.collection("cached_videos").doc("list").get();
      if (doc.exists && doc.data().videos) {
        cachedVideosList = doc.data().videos;
        return cachedVideosList;
      }
    } catch (err) {
      checkFirestoreError(err, "getYouTubeVideos - get fallback");
    }
  }

  return cachedVideosList;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  const PORT = 3000;
  const isProd = process.env.NODE_ENV === "production";

  // Endpoint to fetch official YouTube channel logo/avatar directly
  app.get("/api/channel-logo", async (req, res) => {
    res.json({ logoUrl: "https://yt3.googleusercontent.com/vz3yGgm23APspUhDRBYfsEJ2_HhP9kDATIERxLi6SvcLStrVHAKjIgxcVYY_vWvfAgK1W2WkZQ=s900-c-k-c0x00ffffff-no-rj" });
  });

  // Endpoint to record subscription click (increments Firestore counter)
  app.post("/api/subscribe-click", async (req, res) => {
    try {
      const clicks = await incrementSubscribeClicks();
      res.json({ success: true, clicks });
    } catch (err) {
      console.error("subscribe-click endpoint error:", err);
      res.json({ success: false, clicks: memorySubscribeClicks });
    }
  });

  // Endpoint to fetch real YouTube subscriber count and website subscribe clicks
  app.get("/api/growth-stats", async (req, res) => {
    try {
      const apiKey = process.env.YOUTUBE_API_KEY;
      const channelId = await resolveChannelId(apiKey);
      const subscribers = await getLiveSubscribers(apiKey, channelId);
      const websiteClicks = await getSubscribeClicks();
      res.json({ subscribers, websiteClicks });
    } catch (err) {
      console.error("growth-stats endpoint error:", err);
      res.json({ subscribers: "43", websiteClicks: memorySubscribeClicks });
    }
  });

  // Live YouTube Fetcher endpoint
  app.get("/api/youtube-videos", async (req, res) => {
    try {
      const apiKey = process.env.YOUTUBE_API_KEY;
      const channelId = await resolveChannelId(apiKey);
      const videos = await getYouTubeVideos(apiKey, channelId);
      res.json({ videos });
    } catch (err) {
      console.error("youtube-videos endpoint error:", err);
      res.status(500).json({ error: "Failed to fetch live videos" });
    }
  });

  // AI Endpoint for Edit Storyboard Recipe
  app.post("/api/gemini/generate-recipe", async (req, res) => {
    const { style, prompt } = req.body;
    
    if (!style) {
      return res.status(400).json({ error: "Style is required" });
    }

    const client = getGeminiClient();

    if (!client) {
      // Fallback Mock Data if API Key is missing or invalid
      const mockRecipes: Record<string, any> = {
        "Tokyo Drift Street Style": {
          title: "Tokyo Drift Neon Speed",
          audioPlan: {
            track: "Phonk Drift Anthem (140 BPM)",
            sfx: "Turbo blow-off, tire screech, engine rev on drops, heavy sub-bass slide"
          },
          storyboard: [
            { timestamp: "00:00 - 00:02", visual: "Establishing slow-pan shot of a matte black sports car under flashing Tokyo streetlights.", technique: "Speed ramp from 0.5x to 2.0x, vignette fade-in, rich cinematic LUT." },
            { timestamp: "00:02 - 00:04", visual: "Macro detail of the spinning wheel rim, followed by a sudden gear shift.", technique: "Jolt zoom transition, motion blur overlay, visual shutter glitch on the beat." },
            { timestamp: "00:04 - 00:07", visual: "The drift action: smoke bellowing from rear tires as the car slides sideways in slow-motion.", technique: "Ultra slow-mo (0.25x optical flow), glowing red particle overlay, camera shake effect on impact." },
            { timestamp: "00:07 - 00:10", visual: "Fast transition showing the headlights shining bright through smoke, fading to the channel logo.", technique: "Zoom warp out, white exposure flash, chromatic aberration pulse." }
          ],
          viralTips: [
            "Place the main bass drop exactly at the gear shift (00:03).",
            "Use the high-contrast Neon Red & Teal color grading to pop on mobile screens.",
            "Add a high-energy overlay text showing 'Wait for the slide...🔥' in the first 2 seconds."
          ]
        },
        "Anime Phonk Overdrive": {
          title: "Neo-Tokyo Cyber Awakening",
          audioPlan: {
            track: "Hype Phonk Beat with Aggressive Bass (150 BPM)",
            sfx: "Lightning sparks, metallic swords clashing, vocal chanting, echo reverb on drops"
          },
          storyboard: [
            { timestamp: "00:00 - 00:03", visual: "Character standing in shadows, eyes slowly glowing neon white with visual lightning trails.", technique: "Mask overlay, slow zoom, subtle neon-glow keyframing." },
            { timestamp: "00:03 - 00:05", visual: "Rapid, hyper-paced compilation of action sequences and combat clashes.", technique: "Frame-by-frame flash transitions, twitch effect, directional blur." },
            { timestamp: "00:05 - 00:08", visual: "Ultimate strike scene with slow-mo impact and shockwave ripples centered on screen.", technique: "Sclera flash, screen shake, neon particle explosion, speed curve deceleration." },
            { timestamp: "00:08 - 00:10", visual: "Dark screen with character smirk, transitioning to glowing red Subscribe button.", technique: "Cross-fade glitch, red CRT scanline overlay, dramatic focus pull." }
          ],
          viralTips: [
            "Sync character strike frames with the heavy snare beats.",
            "Apply the custom Alight Motion CC 'Midnight Glow' for deeper blacks.",
            "End with a loops-perfect hook to increase watch time loop metrics."
          ]
        },
        "Lo-Fi Cinematic Rainy Aesthetic": {
          title: "Aesthetic Raindrops & Coffee",
          audioPlan: {
            track: "Mellow Lo-Fi Lounge Track (80 BPM)",
            sfx: "Soft rain patter, coffee dripping, vinyl crackle, gentle hum"
          },
          storyboard: [
            { timestamp: "00:00 - 00:03", visual: "Close-up of raindrops trickling down a window pane with blurred city lights outside.", technique: "Extreme shallow depth of field, warm vintage LUT with brown tones, grain overlay." },
            { timestamp: "00:03 - 00:06", visual: "Pouring steaming coffee into a ceramic mug, with vapor trails rising gracefully.", technique: "Cinematic slow-mo (0.5x), light leaks overlay, soft cross-dissolve transition." },
            { timestamp: "00:06 - 00:08", visual: "A person writing in a journal under a warm desk lamp.", technique: "Smooth slider camera pan, cozy glow grading, dust scratches effect." },
            { timestamp: "00:08 - 00:10", visual: "Cozy mug steaming next to the window, aesthetic text fade in.", technique: "Soft fade-out, minimalist typography overlay, warm vignette." }
          ],
          viralTips: [
            "Use a seamless loop audio to keep viewers watching repeatedly.",
            "Include a calm, reflective text question to encourage comments.",
            "Stick to natural, warm lighting presets with high grain density (15%)."
          ]
        },
        "Glitch Pop Cyber": {
          title: "Cyberpunk Glitch Protocol",
          audioPlan: {
            track: "Synthwave Electro Pop (125 BPM)",
            sfx: "Digital glitch buzz, cyber holographic chime, bass swoosh, computer typing"
          },
          storyboard: [
            { timestamp: "00:00 - 00:02", visual: "Holographic grid loading in neon red, displaying Aaravo Editz mainframe.", technique: "CRT overlay, digital noise glitch, scanline filter, slide-in transition." },
            { timestamp: "00:02 - 00:05", visual: "Fast switching neon signs and cyberpunk cityscape shots under virtual rain.", technique: "Whip pan transitions, strobe-light flashing, high-frequency glitch jumps." },
            { timestamp: "00:05 - 00:08", visual: "Abstract glowing wireframe avatar turning and glitching in sync with synth pulses.", technique: "Displacement mapping, RGB split glow, chromatic aberration pulses." },
            { timestamp: "00:08 - 00:10", visual: "Grid crash visual, showing terminal text asking the user to subscribe.", technique: "Matrix rain fade, neon text-glow animation, power-off TV glitch." }
          ],
          viralTips: [
            "Sync glitch spikes exactly to the electro-synth pop stabs.",
            "Utilize high chromatic aberration on the corners to give a digital VR feel.",
            "Add animated soundwave overlays in neon white and neon red."
          ]
        }
      };

      const fallbackRecipe = mockRecipes[style] || {
        title: `${style} Custom Edit`,
        audioPlan: {
          track: "High Energy Cinematic Theme (120 BPM)",
          sfx: "Sub-drop, transition swooshes, dynamic impacts on beat cuts"
        },
        storyboard: [
          { timestamp: "00:00 - 00:03", visual: `Starting scene based on user prompt: "${prompt || "Cinematic showcase"}".`, technique: "Slow zoom, warm cinematic lighting LUT, smooth keyframed movement." },
          { timestamp: "00:03 - 00:06", visual: "Rapid build-up with staggered close-ups and quick cuts.", technique: "Velocity curves, whip pan transition, glowing edges overlay." },
          { timestamp: "00:06 - 00:08", visual: "The peak action climax shot matching the high point of the audio track.", technique: "Screen shake, directional blur, contrast expansion, color splash." },
          { timestamp: "00:08 - 00:10", visual: "Smooth finish transitioning into the Aaravo Editz Subscribe logo.", technique: "Glitch dissolve, glow decay, elegant black vignette pull." }
        ],
        viralTips: [
          "Cut your clips precisely on the 4/4 drum beats of your audio track.",
          "Use custom neon red glow accents on key highlights to make them stand out on TikTok.",
          "Prompt the viewer with a poll or question at the end to boost video comments."
        ]
      };

      // Simulate 1.2s lag for realistic AI generation feel
      await new Promise(resolve => setTimeout(resolve, 1200));
      return res.json(fallbackRecipe);
    }

    try {
      const userPrompt = prompt 
        ? `User specifications: "${prompt}"` 
        : `Create a cinematic editing recipe for the theme/style: "${style}".`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are Aaravo, the professional video editor and creator of Aaravo Editz on YouTube. 
Your signature brand style is ultra-premium, cinematic, high-energy, with a dark theme, black backgrounds, and red/white neon glowing accents.

Create an elite, highly detailed editing storyboard and visual recipe for the editing style: "${style}".
${userPrompt}

You MUST return a JSON response adhering strictly to the following schema:
{
  "title": "A highly creative video edit title name fitting this style",
  "audioPlan": {
    "track": "Specify the genre/track description and BPM (e.g., Aggressive Phonk, Cinematic Orchestral, Chill Synthwave, 130 BPM)",
    "sfx": "List specific Sound FX required to make the edit punchy (e.g., bass slides, riser swooshes, metallic impacts, engine revs)"
  },
  "storyboard": [
    {
      "timestamp": "Timestamp range, e.g., '00:00 - 00:03'",
      "visual": "A detailed visual scene description",
      "technique": "Detailed CapCut / Alight Motion / Premiere Pro technique (e.g., velocity speed ramps, glowing masks, keyframed camera shakes, chromatic glitch, 3D tracking)"
    }
  ],
  "viralTips": [
    "List 3 highly actionable, elite editing tips to make this edit go viral on YouTube Shorts/Reels"
  ]
}

Ensure the storyboard has exactly 4 chronological entries from 00:00 to 00:10 (standard viral Shorts duration). Do not output any text other than the clean JSON object. Do not wrap the JSON in markdown codeblocks.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            required: ["title", "audioPlan", "storyboard", "viralTips"],
            properties: {
              title: { type: Type.STRING },
              audioPlan: {
                type: Type.OBJECT,
                required: ["track", "sfx"],
                properties: {
                  track: { type: Type.STRING },
                  sfx: { type: Type.STRING }
                }
              },
              storyboard: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ["timestamp", "visual", "technique"],
                  properties: {
                    timestamp: { type: Type.STRING },
                    visual: { type: Type.STRING },
                    technique: { type: Type.STRING }
                  }
                }
              },
              viralTips: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            }
          }
        }
      });

      const resultText = response.text || "{}";
      const recipeData = JSON.parse(resultText);
      res.json(recipeData);
    } catch (error: any) {
      console.error("Gemini Generation Error:", error);
      res.status(500).json({ error: "Failed to generate cinematic recipe. Please try again." });
    }
  });

  // Serve frontend assets
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
});
