// Standalone client-side script for Aaravo Editz Static Site

// 1. Initial State Data & Video List
const SAMPLE_VIDEOS = [
  {
    id: "RzKSUYnHbL0",
    title: "🎬 Epic Anime Edit | Aaravo Editz",
    type: "trending",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/RzKSUYnHbL0/maxresdefault.jpg",
    views: "1.5M+",
    likes: "120K+",
    releaseDate: "Trending now",
    styleTag: "Velocity Ramp",
    description: "A custom high-intensity visual sync edit showcasing elite transition flow and synchronized beat timing. Every frame is hand-crafted to match the high-octane soundtrack perfectly.",
    transitionGuide: "Custom velocity curves with seamless slide-pans and hand-keyframed lens flares.",
    audioTrack: "Aggressive Phonk & Bass-Boost Beats",
    colorLUT: "Aaravo Custom Red Glow - high contrast shadows with scarlet highlights",
    youtubeUrl: "https://www.youtube.com/shorts/RzKSUYnHbL0",
  },
  {
    id: "ISeIIZzWySs",
    title: "⚡ Cinematic Anime Short | Aaravo Editz",
    type: "latest",
    duration: "0:25",
    thumbnail: "https://img.youtube.com/vi/ISeIIZzWySs/maxresdefault.jpg",
    views: "890K+",
    likes: "75K+",
    releaseDate: "Latest upload",
    styleTag: "Motion Sync",
    description: "An immersive editing display featuring butter-smooth frame interpolation, masking, and high-frequency shake curves.",
    transitionGuide: "Optical flow velocity ramp blended with chromatic aberration and high-speed whip pans.",
    audioTrack: "Cinematic Sub-Drop & Hyper Phonk Override",
    colorLUT: "Cyber Cold Blue - desaturated shadows with glowing sapphire highlights",
    youtubeUrl: "https://www.youtube.com/shorts/ISeIIZzWySs",
  },
  {
    id: "H5WMEZ4tN9c",
    title: "🎬 Compiled Anime Editz Special | Aaravo Editz",
    type: "latest",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/H5WMEZ4tN9c/maxresdefault.jpg",
    views: "Live view",
    likes: "Live likes",
    releaseDate: "Yesterday",
    styleTag: "Flow Sync",
    description: "A compilation of the two finest anime flow edits, perfectly synchronized. Features clean velocity ramps, custom lighting keyframes, and smooth color grading.",
    transitionGuide: "Slide transitions and seamless rotoscoping masks combined with directional blur overlays.",
    audioTrack: "High-Octane Phonk Beats & Bass Boost",
    colorLUT: "Neon Cyberpunk Red & Sapphire",
    youtubeUrl: "https://www.youtube.com/shorts/H5WMEZ4tN9c"
  },
  {
    id: "eLswRW4VL1Q",
    title: "⚡ Dynamic Result Anticipation Edit | Aaravo Editz",
    type: "latest",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/eLswRW4VL1Q/maxresdefault.jpg",
    views: "Live view",
    likes: "Live likes",
    releaseDate: "Yesterday",
    styleTag: "Velocity Sync",
    description: "An intense mood edit perfectly reflecting high-stakes focus and cinematic character moments. Pure visual energy with matching frame-cuts.",
    transitionGuide: "Fast whip-pans and seamless frame blending.",
    audioTrack: "Dramatic Cinematic Bass Drops",
    colorLUT: "High-Contrast Onyx & Gold",
    youtubeUrl: "https://www.youtube.com/shorts/eLswRW4VL1Q"
  },
  {
    id: "hhcAbQNUfZc",
    title: "⚡ Cosmic Big Bang Masterpiece | Aaravo Editz",
    type: "latest",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/hhcAbQNUfZc/maxresdefault.jpg",
    views: "Live view",
    likes: "Live likes",
    releaseDate: "3 days ago",
    styleTag: "Impact Shake",
    description: "An explosive, ultra-impact anime visual sequence focusing on the sheer weight of cinematic power. Clean motion blur highlights.",
    transitionGuide: "High-frequency shake keyframing and lens flares.",
    audioTrack: "Colossal Bass-Boost & Impact Beats",
    colorLUT: "Cyber Violet glow with deep black levels",
    youtubeUrl: "https://www.youtube.com/shorts/hhcAbQNUfZc"
  },
  {
    id: "0UjWOtePZJc",
    title: "🎬 Ultimate Combat Flow Edit | Aaravo Editz",
    type: "latest",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/0UjWOtePZJc/maxresdefault.jpg",
    views: "Live view",
    likes: "Live likes",
    releaseDate: "4 days ago",
    styleTag: "Optical Flow",
    description: "Seamless motion flow tracking highlighting intense battle dynamics. High-speed action rendered in smooth 60fps style keyframes.",
    transitionGuide: "Optical flow velocity ramps and whip pan camera shakes.",
    audioTrack: "Aggressive Phonk Override",
    colorLUT: "Warm Crimson Glow & Dark Shadows",
    youtubeUrl: "https://www.youtube.com/shorts/0UjWOtePZJc"
  },
  {
    id: "sNHNUZgqJqc",
    title: "🎬 Unstoppable Motivation Edit | Aaravo Editz",
    type: "latest",
    duration: "0:30",
    thumbnail: "https://img.youtube.com/vi/sNHNUZgqJqc/maxresdefault.jpg",
    views: "Live view",
    likes: "Live likes",
    releaseDate: "Recently uploaded",
    styleTag: "Glow & Shakes",
    description: "A tribute to sheer focus and drive. Beautiful high-contrast grading combined with synchronized action timing.",
    transitionGuide: "Rotoscoped overlay transitions with color shifts.",
    audioTrack: "Epic Orchestral Trap Sync",
    colorLUT: "Aaravo Signature Amber Glow",
    youtubeUrl: "https://www.youtube.com/shorts/sNHNUZgqJqc"
  }
];

const BULLETINS = [
  {
    id: "n1",
    title: "🔥 NEW CINEMATIC UPLOAD: Epic Anime Edit is now online! Watch, like, and subscribe!",
    time: "Just now",
    link: "https://www.youtube.com/shorts/RzKSUYnHbL0"
  },
  {
    id: "n2",
    title: "⚡ NEW RELEASE: Check out our latest Cinematic Anime Short!",
    time: "2 hours ago",
    link: "https://www.youtube.com/shorts/ISeIIZzWySs"
  }
];

let videos = [...SAMPLE_VIDEOS];
let selectedVideo = videos[0];
let localLikes = 0;
let likedVideoIds = {};

// 2. DOM Elements Selection
const navBtnHome = document.getElementById("nav-btn-home");
const navBtnVideos = document.getElementById("nav-btn-videos");
const navBtnGame = document.getElementById("nav-btn-game");
const navBtnAbout = document.getElementById("nav-btn-about");

const tabHome = document.getElementById("tab-home");
const tabVideos = document.getElementById("tab-videos");
const tabGame = document.getElementById("tab-game");
const tabAbout = document.getElementById("tab-about");

const notiToggleBtn = document.getElementById("noti-toggle-btn");
const notiPanel = document.getElementById("noti-panel");
const notiCloseBtn = document.getElementById("noti-close-btn");
const notificationsList = document.getElementById("notifications-list");

const likeCtaBtn = document.getElementById("like-cta-btn");
const heartIcon = document.querySelector("#like-cta-btn i");
const likeSubtext = document.getElementById("like-subtext");
const likeCounter = document.getElementById("like-counter");
const likeAlert = document.getElementById("like-alert");

const featuredPlayerContainer = document.getElementById("featured-player-container");
const uploadsFeedList = document.getElementById("uploads-feed-list");
const videosShortcutCard = document.getElementById("videos-shortcut-card");
const goToVideosLink = document.getElementById("go-to-videos-link");

// 3. Tab Switching Navigation Logic
function switchTab(targetTabId) {
  // Update nav buttons active classes
  [navBtnHome, navBtnVideos, navBtnGame, navBtnAbout].forEach(btn => {
    if (btn) btn.classList.remove("active");
  });
  // Hide all sections
  [tabHome, tabVideos, tabGame, tabAbout].forEach(sec => {
    if (sec) {
      sec.classList.add("hidden");
      sec.classList.remove("active");
    }
  });

  if (targetTabId === 'home') {
    navBtnHome.classList.add("active");
    tabHome.classList.remove("hidden");
    tabHome.classList.add("active");
  } else if (targetTabId === 'videos') {
    navBtnVideos.classList.add("active");
    tabVideos.classList.remove("hidden");
    tabVideos.classList.add("active");
    renderVideosTab();
  } else if (targetTabId === 'game') {
    navBtnGame.classList.add("active");
    tabGame.classList.remove("hidden");
    tabGame.classList.add("active");
  } else if (targetTabId === 'about') {
    navBtnAbout.classList.add("active");
    tabAbout.classList.remove("hidden");
    tabAbout.classList.add("active");
  }
  
  // Scroll to top of viewport
  if (tabHome && tabHome.parentElement) {
    tabHome.parentElement.scrollTop = 0;
  }
}

// 4. Like / Support Button Click Handler
function handleLikeClick() {
  localLikes += 1;
  likeCounter.textContent = localLikes;
  likeCounter.classList.remove("hidden");
  
  // Update texts
  likeSubtext.textContent = `You left ${localLikes} squad likes! Smash more!`;
  
  // Trigger scale bounce effect on the heart
  heartIcon.classList.remove("fill-transparent");
  heartIcon.classList.add("fill-pink-500", "scale-125");
  
  // Show dynamic banner check
  likeAlert.classList.remove("hidden");
  
  setTimeout(() => {
    heartIcon.classList.remove("scale-125");
  }, 300);
}

// 5. Notifications Panel Toggle
function toggleNotifications() {
  const isHidden = notiPanel.classList.contains("-translate-y-full");
  if (isHidden) {
    notiPanel.classList.remove("-translate-y-full", "opacity-0", "pointer-events-none");
  } else {
    notiPanel.classList.add("-translate-y-full", "opacity-0", "pointer-events-none");
  }
}

// 6. Dynamic RSS / Video Fetching Logic with Fallbacks
async function fetchLiveFeed() {
  try {
    const response = await fetch("/api/youtube-videos");
    if (!response.ok) throw new Error("API Offline / CORS constraint");
    const data = await response.json();
    if (data.videos && data.videos.length > 0) {
      videos = data.videos;
      selectedVideo = videos[0];
      renderVideosTab();
    }
  } catch (err) {
    console.log("Failed to load from local API, trying rss2json client fallback...", err);
    try {
      const rss2jsonUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent('https://www.youtube.com/feeds/videos.xml?channel_id=UCIi3LSZD-EindAYccqv_rxA')}`;
      const response = await fetch(rss2jsonUrl);
      if (!response.ok) throw new Error("rss2json proxy failed");
      const data = await response.json();
      if (data.status === 'ok' && data.items && data.items.length > 0) {
        const mappedVideos = data.items.map(item => {
          const videoId = item.guid.replace('yt:video:', '');
          return {
            id: videoId,
            title: item.title,
            type: 'latest',
            duration: '0:30',
            thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
            views: 'Live view',
            likes: 'Live likes',
            releaseDate: item.pubDate ? new Date(item.pubDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recently',
            styleTag: 'Velocity Ramp',
            description: 'A premium, dynamic edit from the official Aaravo Editz live channel feed. High-intensity audio sync and cinematic grading.',
            transitionGuide: 'Custom velocity flow mapped frame-by-frame with precise screen shakes.',
            audioTrack: 'Original synchronized background audio',
            colorLUT: 'Aaravo Custom Grade',
            youtubeUrl: `https://www.youtube.com/shorts/${videoId}`
          };
        });
        videos = mappedVideos;
        selectedVideo = mappedVideos[0];
        renderVideosTab();
      }
    } catch (rssErr) {
      console.log("Using pre-compiled high-quality static video feed mapping: ", rssErr);
    }
  }
}

// 7. Video Thumbnail Error Fallback Resolver
function handleThumbnailError(imgElement) {
  if (imgElement.src.includes('maxresdefault.jpg')) {
    imgElement.src = imgElement.src.replace('maxresdefault.jpg', 'hqdefault.jpg');
  } else if (imgElement.src.includes('hqdefault.jpg')) {
    imgElement.src = imgElement.src.replace('hqdefault.jpg', '0.jpg');
  }
}

// 8. Render Videos Tab Template Curation
function renderVideosTab() {
  if (!featuredPlayerContainer || !uploadsFeedList) return;

  // Render active selection
  if (selectedVideo) {
    featuredPlayerContainer.innerHTML = `
      <div class="relative aspect-video w-full bg-black border-b border-white/5 overflow-hidden group">
        <img 
          src="${selectedVideo.thumbnail}" 
          alt="${selectedVideo.title}"
          class="w-full h-full object-cover opacity-80 group-hover:scale-102 transition-all duration-700"
          onerror="handleThumbnailError(this)"
        />
        <div class="absolute inset-0 bg-black/30 flex items-center justify-center transition-colors group-hover:bg-black/15">
          <a 
            href="${selectedVideo.youtubeUrl}"
            target="_blank"
            rel="noopener noreferrer"
            class="w-14 h-14 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.6)] cursor-pointer hover:scale-110 active:scale-95 transition-all"
          >
            <i data-lucide="play" class="w-6 h-6 fill-white ml-1 text-white"></i>
          </a>
        </div>
        <span class="absolute bottom-2 right-2 bg-black/85 text-white font-mono text-[10px] font-bold py-0.5 px-2 rounded-md border border-white/10">
          ${selectedVideo.duration}
        </span>
        <span class="absolute top-2 left-2 bg-red-600 text-white font-sans text-[9px] font-black tracking-wider uppercase py-0.5 px-2 rounded-md shadow-md">
          ${selectedVideo.styleTag}
        </span>
      </div>

      <div class="px-3.5 space-y-2">
        <div class="space-y-1">
          <h3 class="text-xs font-black text-white leading-snug uppercase tracking-tight italic">
            ${selectedVideo.title}
          </h3>
          <p class="text-[11px] text-zinc-400 font-sans leading-normal">
            ${selectedVideo.description}
          </p>
        </div>

        <div class="flex gap-2 pt-1">
          <a 
            href="${selectedVideo.youtubeUrl}"
            target="_blank"
            rel="noopener noreferrer"
            class="flex-1 flex items-center justify-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-display font-black text-[10.5px] tracking-wider py-2.5 px-3 rounded-lg border border-red-500/20 hover:scale-[1.02] active:scale-95 transition-all text-center uppercase"
          >
            <div class="flex items-center justify-center bg-white rounded px-1 flex-shrink-0">
              <div class="w-4 h-2.5 bg-red-600 rounded flex items-center justify-center">
                <div class="w-0 h-0 border-t-[2px] border-t-transparent border-b-[2px] border-b-transparent border-l-[3.5px] border-l-white ml-[0.2px]"></div>
              </div>
            </div>
            <span>WATCH ON YOUTUBE</span>
          </a>

          <button 
            id="featured-like-toggle"
            class="px-4.5 py-2.5 rounded-lg border flex items-center justify-center gap-1.5 font-display font-bold text-[10.5px] tracking-wider transition-all cursor-pointer ${
              likedVideoIds[selectedVideo.id]
                ? 'bg-pink-600 border-pink-400 text-white shadow-[0_0_15px_rgba(219,39,119,0.4)]'
                : 'bg-zinc-900 border-white/5 text-zinc-300 hover:border-pink-500/25'
            }"
          >
            <i data-lucide="heart" class="w-4 h-4 ${likedVideoIds[selectedVideo.id] ? 'fill-white text-white' : 'text-pink-500'}"></i>
            <span>${likedVideoIds[selectedVideo.id] ? "LIKED!" : "LIKE IT"}</span>
          </button>
        </div>

        <div class="bg-[#111111] rounded-xl p-2.5 border border-white/5 space-y-1.5 text-[10px]">
          <div class="flex justify-between border-b border-white/5 pb-1">
            <span class="text-zinc-500">Color LUT Curve:</span>
            <span class="text-red-400 font-mono font-medium">${selectedVideo.colorLUT}</span>
          </div>
          <div class="flex justify-between border-b border-white/5 pb-1">
            <span class="text-zinc-500">Audio Sync:</span>
            <span class="text-zinc-300 font-sans font-medium">${selectedVideo.audioTrack}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-zinc-500">Editing Technique:</span>
            <span class="text-zinc-300 font-sans font-medium">${selectedVideo.transitionGuide}</span>
          </div>
        </div>
      </div>
    `;

    // Hook like button inside featured template
    document.getElementById("featured-like-toggle").addEventListener("click", () => {
      likedVideoIds[selectedVideo.id] = !likedVideoIds[selectedVideo.id];
      renderVideosTab();
    });
  }

  // Render rest in side-list
  uploadsFeedList.innerHTML = "";
  videos.forEach(v => {
    const isLiked = !!likedVideoIds[v.id];
    const isSelected = selectedVideo?.id === v.id;
    const cardId = `video-card-${v.id}`;

    const cardElement = document.createElement("div");
    cardElement.id = cardId;
    cardElement.className = `p-2.5 rounded-2xl border transition-all cursor-pointer flex gap-3 group relative ${
      isSelected 
        ? 'bg-white/5 border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.05)]' 
        : 'bg-[#0b0b0b] border-white/5 hover:border-white/10'
    }`;
    
    cardElement.innerHTML = `
      <div class="w-24 h-16 rounded-xl overflow-hidden relative bg-zinc-950 border border-white/5 flex-shrink-0">
        <img 
          src="${v.thumbnail}" 
          alt="${v.title}" 
          class="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
          onerror="handleThumbnailError(this)"
        />
        <div class="absolute inset-0 bg-black/10 flex items-center justify-center">
          <div class="w-7 h-7 bg-red-600 rounded-full flex items-center justify-center shadow-md">
            <i data-lucide="play" class="w-3.5 h-3.5 text-white fill-white ml-0.5"></i>
          </div>
        </div>
        <span class="absolute bottom-1 right-1 bg-black/85 text-white font-mono text-[8px] font-black px-1 rounded-sm leading-none">
          ${v.duration}
        </span>
      </div>

      <div class="flex-1 flex flex-col justify-center space-y-1">
        <span class="text-[8px] bg-red-950 text-red-400 font-bold px-1.5 py-0.5 rounded-md w-fit leading-none uppercase">
          ${v.styleTag}
        </span>
        <h4 class="text-[11px] font-black text-white leading-tight uppercase tracking-tight line-clamp-1 group-hover:text-red-500 transition-colors">
          ${v.title}
        </h4>
        
        <div class="flex items-center justify-between text-[9px] text-zinc-500">
          <span class="font-mono">${v.releaseDate}</span>
          
          <div class="flex items-center gap-2">
            <button class="list-like-btn p-1 rounded hover:bg-white/5 transition-colors ${isLiked ? 'text-pink-500' : 'text-zinc-600'}">
              <i data-lucide="heart" class="w-3.5 h-3.5 ${isLiked ? 'fill-pink-500' : ''}"></i>
            </button>
            <a 
              href="${v.youtubeUrl}" 
              target="_blank" 
              rel="noopener noreferrer" 
              class="text-zinc-400 hover:text-red-500 transition-colors"
            >
              <i data-lucide="external-link" class="w-3 h-3"></i>
            </a>
          </div>
        </div>
      </div>
    `;

    // Click on entire card selects video
    cardElement.addEventListener("click", (e) => {
      // Ignore click if it's trigger elements
      if (e.target.closest('button') || e.target.closest('a')) return;
      selectedVideo = v;
      renderVideosTab();
    });

    // Hook list like click explicitly
    cardElement.querySelector('.list-like-btn').addEventListener("click", (e) => {
      e.stopPropagation();
      likedVideoIds[v.id] = !likedVideoIds[v.id];
      renderVideosTab();
    });

    uploadsFeedList.appendChild(cardElement);
  });

  // Re-run Lucide creation for newly injected templates
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// 9. Notifications dynamic list populations
function renderNotifications() {
  if (!notificationsList) return;
  notificationsList.innerHTML = "";
  BULLETINS.forEach(b => {
    const item = document.createElement("a");
    item.href = b.link;
    item.target = "_blank";
    item.rel = "noopener noreferrer";
    item.className = "block p-3 bg-white/[0.02] border border-white/5 rounded-xl hover:bg-white/5 transition-colors";
    item.innerHTML = `
      <div class="flex items-start gap-2.5 text-xs">
        <i data-lucide="bell" class="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5"></i>
        <div class="space-y-0.5 flex-1">
          <p class="font-bold text-white leading-tight">${b.title}</p>
          <span class="text-[9px] text-zinc-500 font-mono block">${b.time}</span>
        </div>
      </div>
    `;
    notificationsList.appendChild(item);
  });
}

// 10. Core Initializations & Listeners Hooking
document.addEventListener("DOMContentLoaded", () => {
  // Lucide loader injection
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Hook Tab Switching
  navBtnHome.addEventListener("click", () => switchTab('home'));
  navBtnVideos.addEventListener("click", () => switchTab('videos'));
  if (navBtnGame) {
    navBtnGame.addEventListener("click", () => switchTab('game'));
  }
  navBtnAbout.addEventListener("click", () => switchTab('about'));

  // Shortcut redirections
  if (videosShortcutCard) {
    videosShortcutCard.addEventListener("click", () => switchTab('videos'));
  }
  if (goToVideosLink) {
    goToVideosLink.addEventListener("click", () => switchTab('videos'));
  }

  // Support interaction button
  if (likeCtaBtn) {
    likeCtaBtn.addEventListener("click", handleLikeClick);
  }

  // Notifications toggles
  if (notiToggleBtn) {
    notiToggleBtn.addEventListener("click", toggleNotifications);
  }
  if (notiCloseBtn) {
    notiCloseBtn.addEventListener("click", toggleNotifications);
  }

  // Render lists and run feeds
  renderNotifications();
  fetchLiveFeed();
  initGame();
});

// Expose handleThumbnailError to global context for inline attributes fallback compatibility
window.handleThumbnailError = handleThumbnailError;

// ==========================================
// ANIME BATTLE ARENA MINI-GAME LOGIC (STATIC)
// ==========================================

const FIGHTERS = [
  {
    id: 'goku',
    name: 'GOKU',
    title: 'Super Saiyan God',
    specialMove: 'KAMEHAMEHA',
    specialPower: 45,
    baseAttack: 15,
    health: 120,
    color: 'from-amber-500 to-orange-600',
    borderColor: 'border-amber-500',
    avatar: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=300',
    energySymbol: '⚡'
  },
  {
    id: 'naruto',
    name: 'NARUTO',
    title: 'Nine-Tails Sage',
    specialMove: 'RASENGAN',
    specialPower: 40,
    baseAttack: 18,
    health: 110,
    color: 'from-orange-500 to-yellow-500',
    borderColor: 'border-orange-500',
    avatar: 'https://images.unsplash.com/photo-1541562232579-512a21360020?auto=format&fit=crop&q=80&w=300',
    energySymbol: '🌀'
  },
  {
    id: 'luffy',
    name: 'LUFFY',
    title: 'Gear 5 Emperor',
    specialMove: 'GUM-GUM RED HAWK',
    specialPower: 42,
    baseAttack: 16,
    health: 115,
    color: 'from-red-500 to-rose-600',
    borderColor: 'border-red-500',
    avatar: 'https://images.unsplash.com/photo-1560169897-fc0cdbdfa4d5?auto=format&fit=crop&q=80&w=300',
    energySymbol: '🍖'
  },
  {
    id: 'zoro',
    name: 'ZORO',
    title: 'Demon Swordsman',
    specialMove: 'DRAGON TWISTER',
    specialPower: 50,
    baseAttack: 14,
    health: 105,
    color: 'from-emerald-500 to-teal-700',
    borderColor: 'border-emerald-500',
    avatar: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=300',
    energySymbol: '⚔️'
  },
  {
    id: 'saitama',
    name: 'SAITAMA',
    title: 'One-Punch Hero',
    specialMove: 'SERIOUS PUNCH',
    specialPower: 55,
    baseAttack: 12,
    health: 100,
    color: 'from-red-600 to-yellow-500',
    borderColor: 'border-red-600',
    avatar: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=300',
    energySymbol: '👊'
  }
];

let playerFighter = null;
let enemyFighter = null;
let playerHp = 100;
let enemyHp = 100;
let playerMaxHp = 100;
let enemyMaxHp = 100;
let playerEnergy = 0;
let isPlayerAttacking = false;
let isEnemyAttacking = false;

const gameIntroScreen = document.getElementById("game-intro-screen");
const gameSubscribeScreen = document.getElementById("game-subscribe-screen");
const gameSelectionScreen = document.getElementById("game-selection-screen");
const gameBattleScreen = document.getElementById("game-battle-screen");
const gameEndScreen = document.getElementById("game-end-screen");

const fightersSelectionList = document.getElementById("fighters-selection-list");
const gameLogsBox = document.getElementById("game-logs-box");

const pName = document.getElementById("p-name");
const pHpText = document.getElementById("p-hp-text");
const pHpBar = document.getElementById("p-hp-bar");
const pEnergyBar = document.getElementById("p-energy-bar");
const pEnergyText = document.getElementById("p-energy-text");

const eName = document.getElementById("e-name");
const eHpText = document.getElementById("e-hp-text");
const eHpBar = document.getElementById("e-hp-bar");

const pAvatarImg = document.getElementById("p-avatar-img");
const eAvatarImg = document.getElementById("e-avatar-img");
const pAvatarFrame = document.getElementById("p-avatar-frame");
const eAvatarFrame = document.getElementById("e-avatar-frame");

const combatStrikeBtn = document.getElementById("combat-strike-btn");
const combatSpecialBtn = document.getElementById("combat-special-btn");
const specialBtnText = document.getElementById("special-btn-text");
const damagePopupText = document.getElementById("damage-popup-text");

const gamePlayBtn = document.getElementById("game-play-btn");
const gameContinueBtn = document.getElementById("game-continue-btn");
const gameRestartBtn = document.getElementById("game-restart-btn");

const goToGameLink = document.getElementById("go-to-game-link");
const gameShortcutCard = document.getElementById("game-shortcut-card");

function initGame() {
  // Show subscribe gate modal when Play Game is clicked
  if (gamePlayBtn) {
    gamePlayBtn.addEventListener("click", () => {
      gameIntroScreen.classList.add("hidden");
      gameSubscribeScreen.classList.remove("hidden");
    });
  }

  // Handle Continue to Game Click
  if (gameContinueBtn) {
    gameContinueBtn.addEventListener("click", () => {
      gameSubscribeScreen.classList.add("hidden");
      gameSelectionScreen.classList.remove("hidden");
      populateFightersSelection();
    });
  }

  // Handle Restart
  if (gameRestartBtn) {
    gameRestartBtn.addEventListener("click", () => {
      gameEndScreen.classList.add("hidden");
      gameSelectionScreen.classList.remove("hidden");
    });
  }

  // Setup Home shortcut clicks
  if (goToGameLink) {
    goToGameLink.addEventListener("click", () => switchTab('game'));
  }
  if (gameShortcutCard) {
    gameShortcutCard.addEventListener("click", () => switchTab('game'));
  }

  // Strike click
  if (combatStrikeBtn) {
    combatStrikeBtn.addEventListener("click", handleStrikeAttack);
  }

  // Ultimate click
  if (combatSpecialBtn) {
    combatSpecialBtn.addEventListener("click", handleUltimateAttack);
  }
}

function addGameLog(text) {
  if (!gameLogsBox) return;
  const div = document.createElement("div");
  div.className = "border-b border-white/[0.02] pb-0.5";
  div.innerHTML = text;
  gameLogsBox.appendChild(div);
  gameLogsBox.scrollTop = gameLogsBox.scrollHeight;
}

function populateFightersSelection() {
  if (!fightersSelectionList) return;
  fightersSelectionList.innerHTML = "";
  FIGHTERS.forEach(fighter => {
    const div = document.createElement("div");
    div.className = "bg-gradient-to-r from-zinc-900 to-zinc-950 border border-white/5 hover:border-red-500/20 rounded-xl p-3 flex items-center gap-3 cursor-pointer transition-all hover:scale-[1.01]";
    div.innerHTML = `
      <div class="w-10 h-10 rounded-lg overflow-hidden border border-zinc-800 flex-shrink-0 bg-black">
        <img src="${fighter.avatar}" alt="${fighter.name}" class="w-full h-full object-cover object-top filter grayscale hover:grayscale-0 transition-all" />
      </div>
      <div class="flex-1 space-y-0.5">
        <div class="flex justify-between items-center">
          <span class="font-display text-sm font-black tracking-tight text-white">${fighter.name}</span>
          <span class="text-[8px] text-zinc-500 font-mono italic">${fighter.title}</span>
        </div>
        <div class="flex items-center gap-2 text-[9px] text-zinc-400">
          <span>❤️ HP: ${fighter.health}</span>
          <span>⚡ Special: ${fighter.specialMove}</span>
        </div>
      </div>
      <div class="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center text-xs border border-white/10 text-zinc-400">
        ${fighter.energySymbol}
      </div>
    `;
    div.addEventListener("click", () => selectFighterStatic(fighter));
    fightersSelectionList.appendChild(div);
  });
}

function selectFighterStatic(fighter) {
  playerFighter = fighter;
  playerHp = fighter.health;
  playerMaxHp = fighter.health;
  playerEnergy = 0;

  // Select a random opponent that is not the player
  const rivals = FIGHTERS.filter(f => f.id !== fighter.id);
  enemyFighter = rivals[Math.floor(Math.random() * rivals.length)];
  enemyHp = enemyFighter.health;
  enemyMaxHp = enemyFighter.health;

  // Switch screens
  gameSelectionScreen.classList.add("hidden");
  gameBattleScreen.classList.remove("hidden");

  // Render elements
  pName.textContent = playerFighter.name;
  eName.textContent = enemyFighter.name;
  pAvatarImg.src = playerFighter.avatar;
  eAvatarImg.src = enemyFighter.avatar;

  updateBattleHpBars();

  // Reset logs
  gameLogsBox.innerHTML = "";
  addGameLog(`⚔️ BATTLE START! ${playerFighter.name} VS ${enemyFighter.name}!`);
}

function updateBattleHpBars() {
  pHpText.textContent = `${playerHp}/${playerMaxHp}`;
  eHpText.textContent = `${enemyHp}/${enemyMaxHp}`;

  const playerPercent = (playerHp / playerMaxHp) * 100;
  const enemyPercent = (enemyHp / enemyMaxHp) * 100;

  pHpBar.style.width = `${playerPercent}%`;
  eHpBar.style.width = `${enemyPercent}%`;

  pEnergyBar.style.width = `${playerEnergy}%`;
  pEnergyText.textContent = `${playerEnergy}%`;

  if (playerEnergy >= 100) {
    combatSpecialBtn.disabled = false;
    combatSpecialBtn.className = "flex flex-col items-center justify-center p-2.5 bg-red-600 hover:bg-red-700 text-white border border-red-400/40 rounded-xl text-center cursor-pointer uppercase transition-all shadow-[0_0_15px_rgba(239,68,68,0.4)]";
    specialBtnText.textContent = playerFighter.specialMove;
  } else {
    combatSpecialBtn.disabled = true;
    combatSpecialBtn.className = "flex flex-col items-center justify-center p-2.5 bg-zinc-950 border border-white/5 text-zinc-600 rounded-xl text-center cursor-not-allowed uppercase transition-all";
    specialBtnText.textContent = "ULTIMATE";
  }
}

function spawnStaticDamagePopup(dmg, isCritical, isPlayerSide) {
  damagePopupText.textContent = `-${dmg}`;
  if (isCritical) {
    damagePopupText.textContent += " CRIT!";
    damagePopupText.className = "font-display font-black text-xl italic text-yellow-400 animate-bounce drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]";
  } else {
    damagePopupText.className = "font-display font-black text-base italic text-red-500 animate-bounce drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]";
  }

  damagePopupText.classList.remove("hidden");
  setTimeout(() => {
    damagePopupText.classList.add("hidden");
  }, 900);
}

function handleStrikeAttack() {
  if (isPlayerAttacking || isEnemyAttacking) return;
  isPlayerAttacking = true;

  // Player animations - forward thrust effect
  pAvatarFrame.classList.add("translate-x-8", "scale-105");

  setTimeout(() => {
    pAvatarFrame.classList.remove("translate-x-8", "scale-105");

    const base = playerFighter.baseAttack;
    const isCrit = Math.random() < 0.25;
    const dmg = Math.round(base * (isCrit ? 1.5 : 1) + Math.floor(Math.random() * 5));

    enemyHp = Math.max(0, enemyHp - dmg);
    playerEnergy = Math.min(100, playerEnergy + 25);

    updateBattleHpBars();
    spawnStaticDamagePopup(dmg, isCrit, false);
    addGameLog(`💥 ${playerFighter.name} deals ${dmg} damage${isCrit ? ' (CRIT!)' : ''}!`);

    if (enemyHp === 0) {
      endBattleStatic('player');
    } else {
      setTimeout(enemyTurnStatic, 800);
    }
    isPlayerAttacking = false;
  }, 300);
}

function handleUltimateAttack() {
  if (isPlayerAttacking || isEnemyAttacking || playerEnergy < 100) return;
  isPlayerAttacking = true;

  pAvatarFrame.classList.add("translate-x-12", "scale-110");
  const arenaBox = document.getElementById("game-arena-box");
  arenaBox.classList.add("ring-2", "ring-red-500", "shadow-[0_0_25px_rgba(239,68,68,0.5)]");

  setTimeout(() => {
    pAvatarFrame.classList.remove("translate-x-12", "scale-110");
    arenaBox.classList.remove("ring-2", "ring-red-500", "shadow-[0_0_25px_rgba(239,68,68,0.5)]");

    const dmg = Math.round(playerFighter.specialPower + Math.floor(Math.random() * 8));

    enemyHp = Math.max(0, enemyHp - dmg);
    playerEnergy = 0;

    updateBattleHpBars();
    spawnStaticDamagePopup(dmg, true, false);
    addGameLog(`🔥 ULTIMATE: ${playerFighter.name} unleashes ${playerFighter.specialMove}!`);
    addGameLog(`💥 Massive ${dmg} elemental burst damage!`);

    if (enemyHp === 0) {
      endBattleStatic('player');
    } else {
      setTimeout(enemyTurnStatic, 900);
    }
    isPlayerAttacking = false;
  }, 450);
}

function enemyTurnStatic() {
  if (enemyHp === 0 || playerHp === 0) return;
  isEnemyAttacking = true;

  eAvatarFrame.classList.add("-translate-x-8", "scale-105");

  setTimeout(() => {
    eAvatarFrame.classList.remove("-translate-x-8", "scale-105");

    const base = enemyFighter.baseAttack;
    const useSpecial = Math.random() < 0.3;
    let dmg = 0;

    if (useSpecial) {
      dmg = Math.round(enemyFighter.specialPower + Math.floor(Math.random() * 5));
      addGameLog(`⚡ ENEMY COMBO: ${enemyFighter.name} channels ${enemyFighter.specialMove}!`);
    } else {
      const isCrit = Math.random() < 0.2;
      dmg = Math.round(base * (isCrit ? 1.4 : 1) + Math.floor(Math.random() * 4));
    }

    playerHp = Math.max(0, playerHp - dmg);
    updateBattleHpBars();
    spawnStaticDamagePopup(dmg, useSpecial, true);
    addGameLog(`⚔️ ${enemyFighter.name} strikes for ${dmg} damage.`);

    if (playerHp === 0) {
      endBattleStatic('enemy');
    }
    isEnemyAttacking = false;
  }, 400);
}

function endBattleStatic(winner) {
  setTimeout(() => {
    gameBattleScreen.classList.add("hidden");
    gameEndScreen.classList.remove("hidden");

    const winnerTitle = document.getElementById("game-winner-title");
    const winnerDesc = document.getElementById("game-winner-desc");

    if (winner === 'player') {
      winnerTitle.innerHTML = "CHAMPION VICTORY!";
      winnerTitle.className = "text-base font-display font-black italic tracking-tight uppercase leading-none text-yellow-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.4)]";
      winnerDesc.textContent = `Excellent job! Your ${playerFighter.name} dominated the arena! Subscribe to Sheetal on YouTube for final powers!`;
    } else {
      winnerTitle.innerHTML = "DEFEATED IN BATTLE";
      winnerTitle.className = "text-base font-display font-black italic tracking-tight uppercase leading-none text-red-500";
      winnerDesc.textContent = `Your ${playerFighter.name} was overcome by ${enemyFighter.name}. Upgrade your skills by subscribing to Aaravo Editz!`;
    }
  }, 800);
}
